// ZIP mínimo (sem dependências): grava com compressão "deflate" e lê arquivos
// gravados por este módulo ou por compactadores comuns (store/deflate, sem ZIP64).
import zlib from 'node:zlib';

const TABELA = new Uint32Array(256).map((_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
export function crc32(buf) {
  let c = 0xffffffff;
  for (const b of buf) c = TABELA[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function dataDos(d) {
  const t = ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xffff;
  const dt = (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xffff;
  return { t, dt };
}

/** entradas: [{ nome, dados: Buffer, data?: Date }] → Buffer do .zip */
export function criarZip(entradas) {
  const locais = []; const centrais = []; let pos = 0;
  for (const e of entradas) {
    const nome = Buffer.from(e.nome.replace(/\\/g, '/'), 'utf8');
    const crua = Buffer.isBuffer(e.dados) ? e.dados : Buffer.from(e.dados);
    const comp = zlib.deflateRawSync(crua, { level: 9 });
    const usa = comp.length < crua.length;
    const corpo = usa ? comp : crua;
    const crc = crc32(crua);
    const { t, dt } = dataDos(e.data ?? new Date());
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(usa ? 8 : 0, 8);
    lh.writeUInt16LE(t, 10); lh.writeUInt16LE(dt, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(corpo.length, 18);
    lh.writeUInt32LE(crua.length, 22); lh.writeUInt16LE(nome.length, 26); lh.writeUInt16LE(0, 28);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(usa ? 8 : 0, 10);
    ch.writeUInt16LE(t, 12); ch.writeUInt16LE(dt, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(corpo.length, 20); ch.writeUInt32LE(crua.length, 24);
    ch.writeUInt16LE(nome.length, 28); ch.writeUInt32LE(pos, 42);
    locais.push(lh, nome, corpo); centrais.push(ch, nome);
    pos += 30 + nome.length + corpo.length;
  }
  const central = Buffer.concat(centrais);
  const fim = Buffer.alloc(22);
  fim.writeUInt32LE(0x06054b50, 0); fim.writeUInt16LE(entradas.length, 8); fim.writeUInt16LE(entradas.length, 10);
  fim.writeUInt32LE(central.length, 12); fim.writeUInt32LE(pos, 16);
  return Buffer.concat([...locais, central, fim]);
}

/** Buffer do .zip → [{ nome, dados }] (pastas ignoradas). Confere o CRC de cada arquivo. */
export function lerZip(buf) {
  let fim = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { fim = i; break; }
  if (fim < 0) throw new Error('Arquivo não é um .zip válido.');
  const total = buf.readUInt16LE(fim + 10);
  let p = buf.readUInt32LE(fim + 16);
  const saida = [];
  for (let n = 0; n < total; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Índice do .zip corrompido.');
    const metodo = buf.readUInt16LE(p + 10); const crc = buf.readUInt32LE(p + 16);
    const tamComp = buf.readUInt32LE(p + 20); const lenNome = buf.readUInt16LE(p + 28);
    const lenExtra = buf.readUInt16LE(p + 30); const lenCom = buf.readUInt16LE(p + 32); const off = buf.readUInt32LE(p + 42);
    const nome = buf.subarray(p + 46, p + 46 + lenNome).toString('utf8');
    p += 46 + lenNome + lenExtra + lenCom;
    if (nome.endsWith('/')) continue;
    const ini = off + 30 + buf.readUInt16LE(off + 26) + buf.readUInt16LE(off + 28);
    const corpo = buf.subarray(ini, ini + tamComp);
    let dados;
    if (metodo === 0) dados = Buffer.from(corpo);
    else if (metodo === 8) dados = zlib.inflateRawSync(corpo);
    else throw new Error(`Compressão não suportada em ${nome}.`);
    if (crc32(dados) !== crc) throw new Error(`Arquivo corrompido dentro do backup: ${nome}.`);
    saida.push({ nome, dados });
  }
  return saida;
}
