// Backup e restauração da pasta de dados (todas as versões).
// Automático: um por semana, guardando os 8 mais recentes, em <pasta do sistema>/backups.
import { promises as fs } from 'node:fs';
import path from 'node:path';
import * as db from './db.js';
import * as licenca from './licenca.js';
import { criarZip, lerZip } from './zip.js';
import { VERSAO } from './versao.js';

export const PASTA = process.env.ES_NFSE_BACKUPS ?? path.join(path.dirname(db.DATA_DIR), 'backups');
const MANTER_AUTO = 8;
const SEMANA = 7 * 864e5;
const IGNORAR = (rel) => rel === '_sessoes.json' || rel.endsWith('.tmp');
const NOME_OK = /^ESNFSe-backup-[\w-]+\.zip$/;

async function listarDados(dir = db.DATA_DIR, base = '') {
  let itens = [];
  let entradas = [];
  try { entradas = await fs.readdir(dir, { withFileTypes: true }); } catch { return []; }
  for (const e of entradas) {
    const rel = base ? `${base}/${e.name}` : e.name;
    if (e.isDirectory()) itens = itens.concat(await listarDados(path.join(dir, e.name), rel));
    else if (e.isFile() && !IGNORAR(rel)) itens.push(rel);
  }
  return itens;
}

const leiaMe = (admin) => `BACKUP DO ES NFS-e — gerado em ${new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })} (versão ${VERSAO})

Contém a pasta "dados": empresas, certificados A1 (protegidos pela .chave-mestra), notas, XML, tomadores,
serviços, modelos, usuários e configurações.${admin ? '\nInclui a CHAVE DE ADMINISTRADOR (.licenca-admin.key): nunca envie este arquivo a ninguém.' : ''}

COMO RESTAURAR
- Pelo sistema: barra lateral → Backup → Restaurar backup → escolha este arquivo.
- À mão: instale o ES NFS-e, feche-o, cole %LOCALAPPDATA%\\ESNFSe no Explorador de Arquivos e troque a pasta
  "dados" pela pasta "dados" deste arquivo.

Guarde uma cópia fora do computador (pendrive, HD externo ou nuvem pessoal).
`;

/** Gera o .zip do backup em memória. */
export async function gerar() {
  const admin = licenca.ehAdmin();
  const arquivos = (await listarDados()).filter((r) => admin || r !== '.licenca-admin.key');
  const empresas = (await db.listar('empresas')).map((e) => ({ cnpj: e.cnpj, razaoSocial: e.razaoSocial }));
  const entradas = [
    { nome: 'LEIA-ME.txt', dados: Buffer.from(leiaMe(admin)) },
    { nome: 'backup.json', dados: Buffer.from(JSON.stringify({ sistema: 'ES NFS-e', versao: VERSAO, criadoEm: new Date().toISOString(), arquivos: arquivos.length, empresas }, null, 2)) },
  ];
  for (const rel of arquivos) entradas.push({ nome: `dados/${rel}`, dados: await fs.readFile(path.join(db.DATA_DIR, ...rel.split('/'))) });
  return criarZip(entradas);
}

const carimbo = () => new Intl.DateTimeFormat('sv-SE', { timeZone: 'America/Sao_Paulo', dateStyle: 'short', timeStyle: 'short' }).format(new Date()).replace(' ', '_').replace(':', '');

/** Grava um backup na pasta de backups. tipo: 'auto' | 'manual' | 'antes-de-restaurar' */
export async function salvarNaPasta(tipo = 'manual') {
  await fs.mkdir(PASTA, { recursive: true });
  const nome = `ESNFSe-backup-${tipo === 'manual' ? '' : `${tipo}-`}${carimbo()}.zip`;
  await fs.writeFile(path.join(PASTA, nome), await gerar());
  if (tipo === 'auto') {
    const autos = (await listar()).filter((b) => b.nome.includes('-auto-'));
    for (const velho of autos.slice(MANTER_AUTO)) await fs.unlink(path.join(PASTA, velho.nome)).catch(() => {});
  }
  return nome;
}

export async function listar() {
  let nomes = [];
  try { nomes = await fs.readdir(PASTA); } catch { return []; }
  const lista = [];
  for (const nome of nomes.filter((n) => NOME_OK.test(n))) {
    const st = await fs.stat(path.join(PASTA, nome));
    lista.push({ nome, tamanho: st.size, criadoEm: st.mtime.toISOString(), tipo: nome.includes('-auto-') ? 'automático' : nome.includes('-antes-de-restaurar-') ? 'antes de restaurar' : 'manual' });
  }
  return lista.sort((a, b) => b.criadoEm.localeCompare(a.criadoEm));
}

export async function ler(nome) {
  if (!NOME_OK.test(nome)) throw Object.assign(new Error('Backup não encontrado.'), { status: 404, usuario: true });
  return fs.readFile(path.join(PASTA, nome));
}

/** Backup semanal automático: grava se o último automático tiver mais de 7 dias. */
export async function automatico() {
  const ultimo = (await listar()).find((b) => b.tipo === 'automático');
  if (ultimo && Date.now() - Date.parse(ultimo.criadoEm) < SEMANA) return null;
  if (!(await listarDados()).some((r) => r === 'empresas.json')) return null; // nada para guardar ainda
  return salvarNaPasta('auto');
}

/** Restaura um backup: guarda antes um backup do estado atual e troca a pasta de dados. */
export async function restaurar(buf) {
  let itens;
  try { itens = lerZip(buf); } catch (e) { throw Object.assign(new Error(`Arquivo inválido: ${e.message}`), { usuario: true }); }
  const dados = itens.filter((i) => i.nome.startsWith('dados/') && !IGNORAR(i.nome.slice(6)));
  const rels = dados.map((i) => i.nome.slice(6));
  if (!rels.includes('empresas.json') && !rels.includes('usuarios.json')) throw Object.assign(new Error('Este arquivo não é um backup do ES NFS-e.'), { usuario: true });
  if (rels.some((r) => r.split('/').some((p) => p === '..' || p === '' ) || path.isAbsolute(r))) throw Object.assign(new Error('Backup com caminhos inválidos.'), { usuario: true });

  const seguranca = await salvarNaPasta('antes-de-restaurar');
  // A liberação e o relógio confiável nunca voltam no tempo com um backup antigo.
  const relogioAtual = await db.mapaObter('_config', 'relogio');
  const licencasAtual = await db.mapaObter('_config', 'licencas');
  const atuais = await listarDados();
  await db.esperarGravacoes();
  for (const rel of atuais) if (!rels.includes(rel)) await fs.unlink(path.join(db.DATA_DIR, ...rel.split('/'))).catch(() => {});
  for (const i of dados) {
    const destino = path.join(db.DATA_DIR, ...i.nome.slice(6).split('/'));
    await fs.mkdir(path.dirname(destino), { recursive: true });
    await fs.writeFile(destino, i.dados);
  }
  db.limparCache();
  licenca.limparCacheAdmin();
  if (relogioAtual) await db.mapaAtualizar('_config', 'relogio', (r = {}) => ({ ...r, servidor: Math.max(r.servidor ?? 0, relogioAtual.servidor ?? 0) }));
  if (licencasAtual?.arquivo) {
    await db.mapaAtualizar('_config', 'licencas', (l) => {
      const novo = Date.parse(licencasAtual.arquivo?.conteudo?.emitidoEm ?? 0) || 0;
      const velho = Date.parse(l?.arquivo?.conteudo?.emitidoEm ?? 0) || 0;
      return novo >= velho ? licencasAtual : l;
    });
  }
  return { arquivos: dados.length, seguranca };
}
