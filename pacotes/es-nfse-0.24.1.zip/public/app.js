// ES NFS-e — interface (JavaScript puro, sem build).
import { AJUDA } from './ajuda.js';
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const so = (s) => String(s ?? '').replace(/\D/g, '');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const moeda = (v) => (v == null ? '—' : Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
const dataBr = (iso) => (iso ? new Date(iso).toLocaleDateString('pt-BR') : '—');
const hoje = () => new Date().toLocaleDateString('sv-SE'); // AAAA-MM-DD local
function docFmt(d) {
  d = so(d);
  if (d.length === 14) return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  if (d.length === 11) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  return d;
}
const REGIMES = { 1: 'Não optante', 2: 'MEI', 3: 'ME/EPP (Simples)' };

const memo = {
  get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* sem storage */ } },
};

const estado = { sistema: null, empresas: [], empresa: null, tomadores: [], servicos: [] };

async function api(metodo, url, corpo) {
  const r = await fetch(url, {
    method: metodo,
    headers: corpo ? { 'content-type': 'application/json' } : {},
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  if (r.status === 204) return null;
  const dados = await r.json().catch(() => ({}));
  if (r.status === 401 && !url.startsWith('/api/auth/')) { mostrarLogin(); }
  if (!r.ok) {
    const e = new Error(dados.erro ?? `Erro ${r.status}`);
    e.detalhes = dados.detalhes ?? [];
    throw e;
  }
  return dados;
}

let toastTimer;
function toast(msg, erro = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = `toast${erro ? ' erro' : ''}`;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 4500);
}
const falha = (e) => toast(e.detalhes?.length ? `${e.message} ${e.detalhes.join('; ')}` : e.message, true);

async function ocupado(botao, fn) {
  botao.disabled = true;
  try { return await fn(); } finally { botao.disabled = false; }
}

// ------------------------------------------------------------------ modal
function modal(html, aoConfirmar, { travarConfirmar = 0 } = {}) {
  const dlg = $('#modal');
  const form = $('#formModal');
  form.onclick = null;
  form.onkeydown = null;
  form.innerHTML = html;
  dlg.showModal();
  if (travarConfirmar) {
    // Confirmação sensível: Enter não confirma, o foco fica em Cancelar e o botão só libera após alguns segundos.
    const ok = form.querySelector('button[value=ok]'); const rotulo = ok.textContent;
    form.querySelector('button[value=cancelar]')?.focus();
    form.onkeydown = (ev) => { if (ev.key === 'Enter') ev.preventDefault(); };
    let n = travarConfirmar; ok.disabled = true; ok.textContent = `${rotulo} (${n})`;
    const t = setInterval(() => { n -= 1; if (n <= 0 || !dlg.open) { clearInterval(t); ok.disabled = false; ok.textContent = rotulo; } else ok.textContent = `${rotulo} (${n})`; }, 1000);
  }
  return new Promise((resolve) => {
    form.onsubmit = async (ev) => {
      const acao = ev.submitter?.value;
      if (acao !== 'ok') { resolve(null); return; }
      if (!aoConfirmar) { resolve(true); return; }
      ev.preventDefault();
      try {
        const r = await ocupado(ev.submitter, () => aoConfirmar(form));
        dlg.close();
        resolve(r ?? true);
      } catch (e) { falha(e); }
    };
    dlg.onclose = () => resolve(null);
  });
}
const rodapeModal = (ok = 'Salvar', classe = 'pri') =>
  `<div class="rodape"><button class="btn sec" value="cancelar" formnovalidate>Cancelar</button><button class="btn ${classe}" value="ok">${ok}</button></div>`;
const valorCampo = (form, nome) => form.elements[nome]?.value?.trim() ?? '';

// Ícones (traço 2px, 24x24) para os botões de ação das tabelas.
const ICONES = {
  recibo: '<path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><path d="M9 7h6"/><path d="M9 11h6"/><path d="M9 15h4"/>',
  ver: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  baixar: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>',
  xml: '<path d="m8 8-4 4 4 4"/><path d="m16 8 4 4-4 4"/><path d="m14 4-4 16"/>',
  modelo: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
  substituir: '<path d="M3 12a9 9 0 0 1 15.5-6.2L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.2L3 16"/><path d="M3 21v-5h5"/>',
  cancelar: '<circle cx="12" cy="12" r="9"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',
  editar: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  excluir: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/>',
  emitir: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/><path d="M12 18v-6"/><path d="m9 15 3-3 3 3"/>',
  desativar: '<circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/>',
  reativar: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  calendario: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4"/><path d="M8 3v4"/><path d="M3 10h18"/><path d="M12 13v5"/><path d="M9.5 15.5h5"/>',
  favorito: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3l-5.6 2.9 1.1-6.2L3 9.6l6.2-.9z"/>',
  anexo: '<path d="m21 11-8.6 8.6a5 5 0 0 1-7-7l8.6-8.6a3.3 3.3 0 0 1 4.7 4.7l-8.6 8.6a1.7 1.7 0 0 1-2.4-2.4l8-8"/>',
};
const svg = (nome) => `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONES[nome]}</svg>`;
/** Botão só com ícone; a dica aparece ao passar o mouse. `attrs` vai direto no elemento. */
const ico = (nome, dica, attrs, classe = '') => `<button type="button" class="ico ${classe}" data-dica="${esc(dica)}" aria-label="${esc(dica)}" ${attrs}>${svg(nome)}</button>`;
const icoLink = (nome, dica, href, extra = '') => `<a class="ico" data-dica="${esc(dica)}" aria-label="${esc(dica)}" href="${href}" ${extra}>${svg(nome)}</a>`;

// ------------------------------------------------------------------ empresas
async function carregarEmpresas() {
  [estado.empresas, estado.instalacao] = await Promise.all([api('GET', '/api/empresas'), api('GET', '/api/instalacao')]);
  aplicarEdicao();
  const sel = $('#seletorEmpresa');
  sel.innerHTML = estado.empresas.length
    ? estado.empresas.map((e) => `<option value="${e.id}">${esc(e.razaoSocial)}</option>`).join('')
    : '<option value="">Cadastre uma empresa</option>';
  const salvo = memo.get('empresaId');
  const escolhida = estado.empresas.find((e) => e.id === (estado.empresa?.id ?? salvo)) ?? estado.empresas[0];
  if (escolhida) sel.value = escolhida.id;
  await trocarEmpresa(escolhida);
}

async function trocarEmpresa(empresa) {
  estado.empresa = empresa ?? null;
  if (empresa) memo.set('empresaId', empresa.id);
  const faixa = $('#faixaAmbiente');
  if (!empresa) {
    estado.bloqueado = false; aplicarLicenca();
    $('#infoEmpresa').textContent = '';
    faixa.className = 'faixa-ambiente simulacao';
    faixa.textContent = 'Nenhuma empresa cadastrada';
    return;
  }
  $('#infoEmpresa').innerHTML = `<span class="mono">${docFmt(empresa.cnpj)}</span><br>${REGIMES[empresa.opSimpNac]} · série ${esc(empresa.serie)}`;
  faixa.className = `faixa-ambiente ${empresa.ambiente}`;
  faixa.textContent = {
    simulacao: 'MODO SIMULAÇÃO — nada é enviado à Receita',
    producao_restrita: 'PRODUÇÃO RESTRITA (homologação) — notas sem valor fiscal',
    producao: 'PRODUÇÃO — as notas emitidas têm valor fiscal',
  }[empresa.ambiente];
  const mei = empresa.opSimpNac === '2';
  $('#campoAliq').hidden = mei;
  $('#dicaAliq').textContent = mei
    ? 'MEI não informa alíquota de ISS: o recolhimento é pelo DAS-MEI.'
    : 'Deixe a alíquota vazia quando o município for conveniado ao Sistema Nacional e parametrizar a alíquota; para optante do Simples, informe a alíquota efetiva do ISS da faixa do Anexo.';
  aplicarLicenca();
  if (estado.bloqueado) { estado.tomadores = []; estado.servicos = []; return; }
  [estado.tomadores, estado.servicos] = await Promise.all([
    api('GET', `/api/empresas/${empresa.id}/tomadores`),
    api('GET', `/api/empresas/${empresa.id}/servicos`),
  ]);
  $('#listaTomadores').innerHTML = estado.tomadores
    .map((t) => `<option value="${esc(t.nome)} · ${docFmt(t.documento)}"></option>`).join('');
  $('#favorito').innerHTML = '<option value="">— escolher —</option>' +
    estado.servicos.map((s) => `<option value="${s.id}">${esc(s.apelido)} (${esc(s.cTribNac)})</option>`).join('');
  atualizarContDesc();
  preencherIbs();
}

const exigeEmpresa = () => {
  if (!estado.empresa) { toast('Cadastre e selecione uma empresa primeiro.', true); location.hash = '#empresas'; return false; }
  return true;
};

// ------------------------------------------------------------------ emissão
function coletarEntrada() {
  const semTomador = $('#semTomador').checked;
  const cep = so($('#eCep').value);
  return {
    dataCompetencia: $('#dComp').value || hoje(),
    salvarTomador: !semTomador && $('#salvarTomador').checked,
    tomador: semTomador ? null : {
      documento: so($('#tDoc').value),
      nome: $('#tNome').value.trim(),
      email: $('#tEmail').value.trim(),
      fone: $('#tFone').value.trim(),
      inscricaoMunicipal: $('#tIm').value.trim(),
      ...(cep ? { endereco: {
        cep, codMunicipio: so($('#eIbge').value), logradouro: $('#eLgr').value.trim(), numero: $('#eNro').value.trim(),
        bairro: $('#eBairro').value.trim(), complemento: $('#eCpl').value.trim(), cidade: $('#eCidade').value.trim(),
      } } : {}),
    },
    servico: {
      cTribNac: so($('#sTrib').value), cNBS: so($('#sNbs').value), cTribMun: $('#sTribMun').value.trim(),
      descricao: $('#sDesc').value.trim(), codMunicipioPrestacao: so($('#sMun').value),
      ...(estado.assistente ? { assistente: estado.assistente } : {}),
    },
    valores: { vServ: $('#vServ').value.replace(/\./g, '').replace(',', '.'), aliqIss: $('#aliq').value.replace(',', '.'), tpRetISSQN: $('#ret').value },
    ibscbs: coletarIbs(),
  };
}

const valorBr = (v) => (v === '' || v == null ? '' : Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2 }));

function preencherTomador(t) {
  $('#semTomador').checked = !t;
  $('#blocoTomador').hidden = !t;
  if (!t) return;
  $('#tDoc').value = docFmt(t.documento);
  $('#tNome').value = t.nome ?? '';
  $('#tEmail').value = t.email ?? '';
  $('#tFone').value = t.fone ?? '';
  $('#tIm').value = t.inscricaoMunicipal ?? '';
  const e = t.endereco ?? {};
  $('#eCep').value = e.cep ?? ''; $('#eLgr').value = e.logradouro ?? ''; $('#eNro').value = e.numero ?? '';
  $('#eBairro').value = e.bairro ?? ''; $('#eCpl').value = e.complemento ?? ''; $('#eCidade').value = e.cidade ?? '';
  $('#eIbge').value = e.codMunicipio ?? '';
  carregarMunicipios().then(() => { if (so($('#eIbge').value)) sincronizarMunicipio($('#eCidade'), $('#eIbge')); });
  $('#detEndereco').open = Boolean(e.cep);
}

function preencherServicoValores(entrada) {
  const s = entrada.servico ?? {};
  const v = entrada.valores ?? {};
  $('#sTrib').value = s.cTribNac ?? ''; $('#sNbs').value = s.cNBS ?? ''; $('#sTribMun').value = s.cTribMun ?? '';
  definirDescricao(semBanco(s.descricao ?? '')); $('#sMun').value = s.codMunicipioPrestacao ?? '';
  carregarMunicipios().then(() => sincronizarMunicipio($('#sMunNome'), $('#sMun')));
  estado.assistente = s.assistente ?? assistenteDeTexto(s.descricao) ?? null;
  estado.assistenteDeNotaAnterior = Boolean(estado.assistente);
  $('#vServ').value = valorBr(v.vServ); $('#aliq').value = v.aliqIss ? String(v.aliqIss).replace('.', ',') : '';
  $('#ret').value = v.tpRetISSQN ?? '1';
  preencherIbs(s.ibscbs, entrada.ibscbs);
}

function mostrarOrigem(texto) {
  const a = $('#avisoOrigem');
  a.classList.remove('subst');
  a.hidden = !texto;
  a.innerHTML = texto ? `<span>${texto}</span><button type="button" class="btn mini sec" id="desfazerOrigem">Limpar</button>` : '';
  if (texto) $('#desfazerOrigem').onclick = () => limparEmissao(false);
}

function sairSubstituicao() {
  estado.substituindo = null;
  $('#blocoSubst').hidden = true;
  $('#btnEmitir').textContent = 'Emitir NFS-e';
  $('#btnPrevia').hidden = false;
}

function limparEmissao(sugerir = false) {
  sairSubstituicao();
  $('#formEmissao').reset();
  preencherTomador({});
  $('#tDoc').value = '';
  estado.ultimoDocTomador = '';
  $('#detEndereco').open = false;
  $('#dComp').value = hoje();
  estado.assistente = null; estado.assistenteDeNotaAnterior = false;
  atualizarContDesc();
  preencherIbs();
  $('#sugCodigos').hidden = true; $('#sBusca').value = ''; estado.ctSugerido = null;
  $('#resultado').innerHTML = '';
  mostrarOrigem('');
  if (sugerir) sugerirUltima(false);
}

/** Abre a tela já com serviço/valores da última nota (sem tomador). */
async function sugerirUltima(completa) {
  if (!estado.empresa) return;
  const s = await api('GET', `/api/empresas/${estado.empresa.id}/sugestao`);
  if (!s.origem) { if (completa) toast('Esta empresa ainda não tem nota autorizada.'); return; }
  preencherServicoValores(s.entrada);
  if (completa) preencherTomador(s.entrada.tomador);
  mostrarOrigem(`${completa ? 'Nota repetida' : 'Serviço e valores preenchidos'} a partir da última NFS-e emitida: nº <b>${esc(s.nota.numero)}</b> de ${dataBr(s.nota.dhProc)} para ${esc(s.nota.tomadorNome)}.`);
}

async function aoEscolherTomador(doc) {
  const t = estado.tomadores.find((x) => so(x.documento) === so(doc));
  if (t) preencherTomador(t);
  const s = await api('GET', `/api/empresas/${estado.empresa.id}/sugestao?tomador=${so(doc)}&somenteTomador=1`);
  if (s.origem === 'tomador') {
    preencherServicoValores(s.entrada);
    if (!t && s.entrada.tomador) preencherTomador(s.entrada.tomador);
    mostrarOrigem(`Preenchido a partir da última nota deste tomador: nº <b>${esc(s.nota.numero)}</b> de ${dataBr(s.nota.dhProc)} · ${moeda(s.nota.vServ)}. Confira valor e competência.`);
  } else if (t) {
    mostrarOrigem('Tomador do cadastro. Ainda não há nota emitida para ele.');
  } else if (so(doc).length === 14) {
    // Tomador novo: busca os dados na Receita.
    try {
      const d = await consultarCnpj(doc);
      preencherTomador({ documento: so(doc), nome: d.razaoSocial, email: d.email, fone: d.fone, endereco: d.endereco });
      mostrarOrigem(`Tomador novo: dados trazidos do cadastro da Receita (${esc(d.situacao || 'situação não informada')}). Confira o e-mail.${avisoSituacao(d.situacao)}`);
    } catch (e) { toast(e.message, true); }
  }
}

async function buscarCep() {
  const cep = so($('#eCep').value);
  if (cep.length !== 8) return;
  try {
    const r = await (await fetch(`https://viacep.com.br/ws/${cep}/json/`)).json();
    if (r.erro) return toast('CEP não encontrado.', true);
    $('#eLgr').value ||= r.logradouro ?? ''; $('#eBairro').value ||= r.bairro ?? '';
    $('#eCidade').value = `${r.localidade}/${r.uf}`; $('#eIbge').value = r.ibge ?? '';
    carregarMunicipios().then(() => sincronizarMunicipio($('#eCidade'), $('#eIbge')));
  } catch { /* sem internet: preencha à mão */ }
}

// ------------------------------------------------------------------ consulta CNPJ
// BrasilAPI (dados abertos da Receita) direto do navegador; IBGE pelo ViaCEP se faltar.
const cacheCnpj = new Map();
const titulo = (s) => String(s ?? '').toLowerCase().replace(/(^|\s)\S/g, (c) => c.toUpperCase());

async function consultarCnpj(cnpj) {
  cnpj = so(cnpj);
  if (cnpj.length !== 14) return null;
  if (cacheCnpj.has(cnpj)) return cacheCnpj.get(cnpj);
  let r;
  try { r = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpj}`); } catch { throw new Error('Sem internet para consultar o CNPJ; preencha à mão.'); }
  if (r.status === 404 || r.status === 400) throw new Error('CNPJ não encontrado na base da Receita.');
  if (!r.ok) throw new Error('Consulta de CNPJ indisponível agora; preencha à mão.');
  const d = await r.json();
  const cep = so(d.cep);
  let ibge = d.codigo_municipio_ibge ? String(d.codigo_municipio_ibge) : '';
  if (!ibge && cep.length === 8) {
    try { ibge = (await (await fetch(`https://viacep.com.br/ws/${cep}/json/`)).json()).ibge ?? ''; } catch { /* segue sem IBGE */ }
  }
  const tipo = d.descricao_tipo_de_logradouro ?? '';
  const lgr = d.logradouro ?? '';
  const cidade = d.municipio ? `${titulo(d.municipio)}/${d.uf}` : '';
  const dados = {
    razaoSocial: d.razao_social ?? '',
    situacao: d.descricao_situacao_cadastral ?? '',
    codMunicipio: ibge,
    municipio: cidade,
    // MEI → 2; Simples → 3; fora do Simples → 1; sem informação → não mexe
    opSimpNac: d.opcao_pelo_mei ? '2' : d.opcao_pelo_simples ? '3' : d.opcao_pelo_simples === false ? '1' : '',
    email: String(d.email ?? '').toLowerCase(),
    fone: so(d.ddd_telefone_1),
    endereco: cep ? {
      cep, codMunicipio: ibge, cidade, bairro: titulo(d.bairro), complemento: titulo(d.complemento),
      logradouro: titulo(tipo && !lgr.toUpperCase().startsWith(tipo.toUpperCase()) ? `${tipo} ${lgr}` : lgr),
      numero: d.numero || 'S/N',
    } : undefined,
  };
  cacheCnpj.set(cnpj, dados);
  return dados;
}

const avisoSituacao = (s) => (s && s.toUpperCase() !== 'ATIVA' ? ` <b style="color:var(--erro)">Atenção: situação cadastral ${esc(s)}.</b>` : '');

function renderResultado(r) {
  const el = $('#resultado');
  if (r.status === 'autorizada') {
    const n = r.nota;
    el.innerHTML = `<div class="resultado ok"><h2>NFS-e nº ${esc(n.numero)} autorizada${n.substituiu ? ` — substitui a nº ${esc(n.substituiu)}, que foi cancelada` : ''}</h2>
      <p>${esc(n.tomadorNome)} · ${moeda(n.vServ)} · líquido ${moeda(n.vLiq)}</p>
      <p class="mono">Chave: ${esc(n.chaveAcesso)}</p>
      ${n.alertas?.length ? `<ul>${n.alertas.map((a) => `<li>${esc(a)}</li>`).join('')}</ul>` : ''}
      <div class="acoes"><a class="btn pri" href="/api/notas/${n.id}/pdf" target="_blank">Ver DANFSe (PDF)</a>
      <a class="btn sec" href="/api/notas/${n.id}/pdf?baixar=1" download>Baixar PDF</a>
      <a class="btn sec" href="/api/notas/${n.id}/xml">Baixar XML</a>
      <button class="btn sec" type="button" id="salvarFavorito">Cadastrar como serviço favorito</button>
      <button class="btn sec" type="button" id="novaNota">Nova nota</button></div></div>`;
    $('#novaNota').onclick = () => limparEmissao();
    $('#salvarFavorito').onclick = () => servicoDaNota(n.id).catch(falha);
  } else if (r.status === 'rejeitada') {
    el.innerHTML = `<div class="resultado erro"><h2>Rejeitada pela Receita</h2><ul>${r.mensagens.map((m) => `<li>${esc(m)}</li>`).join('')}</ul>
      <p class="dica">O número da DPS foi consumido. Corrija e emita de novo; a rejeição fica registrada no histórico.</p></div>`;
  } else if (r.status === 'pendente') {
    el.innerHTML = `<div class="resultado pend"><h2>Envio pendente</h2><p>A Receita não respondeu (${esc(r.nota.erro)}). A DPS assinada foi guardada e será reenviada automaticamente a cada 3 minutos, sem risco de duplicar a nota.</p></div>`;
  }
  el.scrollIntoView({ behavior: 'smooth' });
}

async function emitir(ev) {
  ev.preventDefault();
  // Só emite pelo clique no botão "Emitir NFS-e" (Enter num campo não envia a nota).
  if (ev.submitter?.id !== 'btnEmitir') return;
  if (!exigeEmpresa()) return;
  // Recarrega a empresa: o ambiente pode ter sido alterado em outra janela.
  const atual = (await api('GET', '/api/empresas')).find((x) => x.id === estado.empresa.id);
  if (atual && atual.ambiente !== estado.empresa.ambiente) {
    await carregarEmpresas();
    toast('O ambiente desta empresa mudou em outra janela. Tela atualizada: confira e clique em Emitir de novo.', true);
    return;
  }
  const entrada = coletarEntrada();
  const corpo = { ...entrada };
  if (estado.empresa.ambiente === 'producao') {
    const ok = await modal(`<h2>${estado.substituindo ? `Confirmar substituição da NFS-e nº ${esc(estado.substituindo.numero)}` : 'Confirmar emissão em Produção'}</h2>
      ${estado.substituindo ? '<p>A nota original será <b>cancelada</b> pelo Sistema Nacional e substituída por esta.</p>' : ''}
      <p>Esta nota terá <b>valor fiscal</b>. Emitente: <b>${esc(estado.empresa.razaoSocial)}</b>.</p>
      <p>Tomador: <b>${esc(entrada.tomador?.nome || 'não identificado')}</b>${entrada.tomador?.documento ? ` · ${esc(docFmt(so(entrada.tomador.documento)))}` : ''} · Valor: <b>${moeda(entrada.valores.vServ)}</b></p>
      <p>Serviço (${esc(entrada.servico.cTribNac ? fmtTrib(entrada.servico.cTribNac) : '')}): ${esc(entrada.servico.descricao)}</p>
      <p class="dica">Confira os dados. Depois de emitida, a nota só pode ser corrigida por substituição ou cancelamento.</p>${rodapeModal('Emitir nota', 'perigo')}`, null, { travarConfirmar: 2 });
    if (!ok) return;
    corpo.confirmar = true;
  }
  const subst = estado.substituindo;
  if (subst) {
    corpo.cMotivo = $('#cMotivo').value;
    corpo.xMotivo = $('#xMotivo').value.trim();
  }
  await ocupado($('#btnEmitir'), async () => {
    try {
      const r = subst
        ? await api('POST', `/api/notas/${subst.id}/substituir`, corpo)
        : await api('POST', `/api/empresas/${estado.empresa.id}/emitir`, corpo);
      if (subst && r.status === 'autorizada') { sairSubstituicao(); r.nota.substituiu = subst.numero; }
      renderResultado(r);
      if (r.status === 'autorizada') { mostrarOrigem(''); await trocarEmpresa(estado.empresa); }
    } catch (e) {
      $('#resultado').innerHTML = `<div class="resultado erro"><h2>${esc(e.message)}</h2>${e.detalhes.length ? `<ul>${e.detalhes.map((d) => `<li>${esc(d)}</li>`).join('')}</ul>` : ''}<p class="dica">Nada foi enviado e nenhum número de DPS foi consumido.</p></div>`;
    }
  });
}

async function previa() {
  if (!exigeEmpresa()) return;
  await ocupado($('#btnPrevia'), async () => {
    try {
      const r = await api('POST', `/api/empresas/${estado.empresa.id}/emitir?previa=1`, coletarEntrada());
      const bonito = r.xmlDps.replace(/></g, '>\n<');
      await modal(`<h2>Prévia da DPS${r.semAssinatura ? '' : ' assinada'}</h2><p class="dica">Leiaute ${r.leiaute === 'nt009' ? 'da NT 009' : 'da NT 004'}, validada contra o XSD oficial${r.semAssinatura ? ' (simulação: sem assinatura)' : ' e assinada'}, mas não enviada. IBS/CBS: ${r.ibscbs ? `informado — CST ${esc(r.ibscbs.CST)}, cClassTrib ${esc(r.ibscbs.cClassTrib)}${r.ibscbs.cIndOp ? `, cIndOp ${esc(r.ibscbs.cIndOp)}` : ''}` : 'não informado nesta nota'}.</p><pre class="xml">${esc(bonito)}</pre><div class="rodape"><button class="btn pri" value="cancelar">Fechar</button></div>`);
    } catch (e) { falha(e); }
  });
}

// ------------------------------------------------------------------ municípios (IBGE)
// Lista oficial embutida (public/municipios.json: [código IBGE, nome, UF]); funciona sem internet.
let MUNICIPIOS = null;
async function carregarMunicipios() {
  if (!MUNICIPIOS) MUNICIPIOS = (await (await fetch('/municipios.json')).json()).map((m) => ({ cod: m[0], nome: m[1], uf: m[2], chave: semAcento(`${m[1]} ${m[2]}`) }));
  return MUNICIPIOS;
}
const semAcento = (s = '') => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
const rotuloMun = (m, sep) => `${m.nome}${sep}${m.uf}`;
const municipioPorCodigo = (cod) => MUNICIPIOS?.find((m) => m.cod === so(cod));
/** Busca por nome (sem acento; aceita "campina grande pb", "campina/pb", "sao mamede"). */
function buscarMunicipios(texto, limite = 25) {
  const t = semAcento(texto).replace(/[/-]/g, ' ').replace(/\s+/g, ' ');
  if (t.length < 2) return [];
  const ini = []; const meio = [];
  for (const m of MUNICIPIOS ?? []) {
    if (m.chave.startsWith(t)) ini.push(m); else if (m.chave.includes(t)) meio.push(m);
    if (ini.length >= limite) break;
  }
  return [...ini, ...meio].slice(0, limite);
}
/**
 * Liga um campo de nome de cidade ao campo de código IBGE: ao digitar o nome aparecem
 * sugestões; ao escolher, o código é preenchido. Digitar o código também mostra o nome.
 * `sep` define o formato do nome guardado (" - " na emissão, "/" no cadastro da empresa).
 */
function ligarMunicipio(campoNome, campoCodigo, { sep = ' - ', aoEscolher } = {}) {
  if (!campoNome || !campoCodigo || campoNome.dataset.municipio) return;
  campoNome.dataset.municipio = '1';
  const lista = document.createElement('datalist');
  lista.id = `mun-${Math.random().toString(36).slice(2, 9)}`;
  document.body.append(lista);
  campoNome.setAttribute('list', lista.id);
  campoNome.setAttribute('autocomplete', 'off');
  const casar = () => {
    const v = campoNome.value.trim();
    const m = (MUNICIPIOS ?? []).find((x) => rotuloMun(x, ' - ') === v || rotuloMun(x, '/') === v);
    if (m) {
      campoCodigo.value = m.cod;
      campoNome.value = rotuloMun(m, sep);
      campoNome.classList.remove('invalido');
      aoEscolher?.(m);
    }
    return m;
  };
  campoNome.addEventListener('input', async () => {
    await carregarMunicipios();
    if (casar()) return;
    lista.innerHTML = buscarMunicipios(campoNome.value).map((m) => `<option value="${esc(rotuloMun(m, ' - '))}">${m.cod}</option>`).join('');
    if (!campoNome.value.trim()) campoCodigo.value = '';
  });
  campoNome.addEventListener('change', async () => {
    await carregarMunicipios();
    if (casar() || !campoNome.value.trim()) return;
    const [unico] = buscarMunicipios(campoNome.value, 2).length === 1 ? buscarMunicipios(campoNome.value, 1) : [];
    if (unico) { campoNome.value = rotuloMun(unico, ' - '); casar(); } else campoNome.classList.add('invalido');
  });
  campoCodigo.addEventListener('input', async () => { await carregarMunicipios(); sincronizarMunicipio(campoNome, campoCodigo, sep); });
  carregarMunicipios().then(() => sincronizarMunicipio(campoNome, campoCodigo, sep));
}
/** Depois de preencher o código por programa, mostra o nome correspondente. */
function sincronizarMunicipio(campoNome, campoCodigo, sep = ' - ') {
  if (!campoNome || !campoCodigo) return;
  const m = municipioPorCodigo(campoCodigo.value);
  if (m) { campoNome.value = rotuloMun(m, sep); campoNome.classList.remove('invalido'); } else if (!so(campoCodigo.value) && campoNome.id === 'sMunNome') campoNome.value = '';
}

// ------------------------------------------------------------------ Lista Nacional de Serviços e sugestões (Anexos B, VII e VIII)
let TABELAS = null;
const carregarTabelas = async () => { if (!TABELAS) TABELAS = await fetch('/tabelas-nfse.json').then((r) => r.json()); return TABELAS; };
const fmtTrib = (c) => `${c.slice(0, 2)}.${c.slice(2, 4)}.${c.slice(4, 6)}`;
const fmtNbs = (n) => `${n.slice(0, 1)}.${n.slice(1, 5)}.${n.slice(5, 7)}.${n.slice(7, 9)}`;
function buscarServicos(texto, max = 15) {
  const termos = semAcento(texto).split(/\s+/).filter(Boolean);
  const dig = so(texto);
  if (!termos.length) return [];
  return TABELAS.servicos.filter(([c, d]) => (dig.length >= 2 && c.startsWith(dig)) || termos.every((t) => semAcento(d).includes(t))).slice(0, max);
}
function ligarBuscaServico() {
  const campo = $('#sBusca');
  const lista = document.createElement('datalist');
  lista.id = 'listaServicosNac'; document.body.append(lista); campo.setAttribute('list', lista.id);
  const rotulo = ([c, d]) => `${fmtTrib(c)} — ${d}`;
  const casar = () => TABELAS.servicos.find((s) => rotulo(s) === campo.value.trim());
  campo.addEventListener('input', async () => {
    await carregarTabelas();
    const s = casar();
    if (s) { escolherServicoNacional(s[0]); return; }
    lista.innerHTML = buscarServicos(campo.value).map((x) => `<option value="${esc(rotulo(x))}"></option>`).join('');
  });
  campo.addEventListener('change', async () => {
    await carregarTabelas();
    const s = casar() ?? (buscarServicos(campo.value, 2).length === 1 ? buscarServicos(campo.value, 1)[0] : null);
    if (s) escolherServicoNacional(s[0]);
  });
  $('#sTrib').addEventListener('input', async () => {
    const c = so($('#sTrib').value);
    if (c.length !== 6) { $('#sugCodigos').hidden = true; return; }
    await carregarTabelas();
    sugerirCodigos(c, { sobrescrever: false });
  });
}
/** Escolha explícita na busca: troca o código e as sugestões que dependem dele. */
function escolherServicoNacional(c) {
  $('#sTrib').value = c;
  const s = TABELAS.servicos.find((x) => x[0] === c);
  $('#sBusca').value = s ? `${fmtTrib(c)} — ${s[1]}` : '';
  sugerirCodigos(c, { sobrescrever: true });
}
function sugerirCodigos(cTrib, { sobrescrever }) {
  const caixa = $('#sugCodigos');
  const serv = TABELAS.servicos.find((x) => x[0] === cTrib);
  const item = `${cTrib.slice(0, 2)}.${cTrib.slice(2, 4)}`;
  const nbs = TABELAS.itens[item] ?? {};
  const lista = Object.entries(nbs);
  if (!serv) { caixa.hidden = false; caixa.innerHTML = `<p class="sug-aviso">O código <b class="mono">${esc(fmtTrib(cTrib))}</b> não está na Lista Nacional de Serviços (a Receita rejeita com E0310). Use a busca acima.</p>`; return; }
  if (!lista.length) { caixa.hidden = false; caixa.innerHTML = `<p class="sug-aviso"><b>${esc(fmtTrib(cTrib))}</b> ${esc(serv[1])} — sem correlação de NBS/IBS-CBS na tabela oficial.</p>`; return; }
  // escolhe a NBS: a que já está no campo (se for desta lista) ou a primeira
  const atualNbs = so($('#sNbs').value);
  const nbsSel = lista.find(([n]) => n === atualNbs)?.[0] ?? lista[0][0];
  const [, ops, cts] = nbs[nbsSel];
    if (sobrescrever || !atualNbs || !nbs[atualNbs]) $('#sNbs').value = nbsSel;
  if (sobrescrever || !ops.includes(so($('#iIndOp').value))) $('#iIndOp').value = ops[0];
  // cClassTrib: preenche se vazio ou se o valor atual veio de uma sugestão anterior (nunca troca a configuração da empresa)
  const ctAtual = so($('#iClass').value);
  if ((!ctAtual || ctAtual === estado.ctSugerido) && !cts.includes(ctAtual)) { $('#iClass').value = cts[0]; $('#iCst').value = cts[0].slice(0, 3); estado.ctSugerido = cts[0]; }
  atualizarStatusIbs();
  const chip = (attr, valor, cod, desc, ativo) => `<button type="button" class="chip${ativo ? ' ativo' : ''}" ${attr}="${valor}" title="${esc(desc)}"><b class="mono">${esc(cod)}</b> ${esc(desc.length > 70 ? `${desc.slice(0, 68)}…` : desc)}</button>`;
  const desenhar = () => {
    const nAt = so($('#sNbs').value); const oAt = so($('#iIndOp').value); const cAt = so($('#iClass').value);
    const [, opsN, ctsN] = nbs[nAt] ?? nbs[nbsSel];
    caixa.innerHTML = `<div class="sug-cab">Sugestões das tabelas oficiais para <b class="mono">${esc(fmtTrib(cTrib))}</b> ${esc(serv[1])} <small>(Anexo VIII v1.02 · confira antes de emitir)</small></div>
      <div class="sug-grupo"><span>NBS</span>${lista.map(([n, [d]]) => chip('data-sug-nbs', n, fmtNbs(n), d, n === nAt)).join('')}</div>
      <div class="sug-grupo"><span>Indicador da operação (cIndOp)</span>${opsN.map((o) => chip('data-sug-op', o, o, TABELAS.indop[o]?.[1] ?? '', o === oAt)).join('')}</div>
      <div class="sug-grupo"><span>CST / cClassTrib</span>${ctsN.map((c) => chip('data-sug-ct', c, `${c.slice(0, 3)} / ${c}`, TABELAS.classTrib[c]?.[1] ?? '', c === cAt)).join('')}</div>
      ${cAt && !ctsN.includes(cAt) ? `<p class="sug-aviso">A classificação atual (<span class="mono">${esc(cAt)}</span>, da configuração da empresa) não está entre as da tabela para esta NBS. Empresas do Simples Nacional: siga a orientação do contador.</p>` : ''}`;
  };
  caixa.onclick = (ev) => {
    const b = ev.target.closest('.chip'); if (!b) return;
    if (b.dataset.sugNbs) { $('#sNbs').value = b.dataset.sugNbs; const [, o2] = nbs[b.dataset.sugNbs]; if (!o2.includes(so($('#iIndOp').value))) $('#iIndOp').value = o2[0]; }
    if (b.dataset.sugOp) $('#iIndOp').value = b.dataset.sugOp;
    if (b.dataset.sugCt) { $('#iClass').value = b.dataset.sugCt; $('#iCst').value = b.dataset.sugCt.slice(0, 3); estado.ctSugerido = b.dataset.sugCt; }
    atualizarStatusIbs(); desenhar();
  };
  caixa.hidden = false;
  desenhar();
}

// ------------------------------------------------------------------ IBS/CBS na emissão
const ITENS_MARCO_2027 = ['0103', '0105', '0109', '1601'];
const inicioIbsPadrao = (cTrib = '') => (ITENS_MARCO_2027.includes(so(cTrib).slice(0, 4)) ? '2027-03-01' : '2027-01-01');

/** Põe nos campos da emissão a configuração IBS/CBS (empresa < serviço < nota). */
function preencherIbs(...fontes) {
  const base = Object.assign({}, estado.empresa?.ibscbs ?? {}, ...fontes.map((f) => Object.fromEntries(Object.entries(f ?? {}).filter(([, v]) => v !== '' && v != null))));
  estado.ibsRegra = { modo: base.modo || 'auto', inicio: base.inicio || '' };
  $('#iCst').value = base.CST ?? ''; $('#iClass').value = base.cClassTrib ?? '';
  $('#iIndOp').value = base.cIndOp ?? ''; $('#iIndFinal').value = base.indFinal ?? '';
  atualizarStatusIbs();
}
function coletarIbs() {
  const r = { ...(estado.ibsRegra ?? {}), CST: so($('#iCst').value), cClassTrib: so($('#iClass').value), cIndOp: so($('#iIndOp').value), indFinal: $('#iIndFinal').value };
  return Object.fromEntries(Object.entries(r).filter(([, v]) => v !== ''));
}
function atualizarStatusIbs() {
  const el = $('#statusIbs');
  if (!el) return;
  const { modo = 'auto', inicio } = estado.ibsRegra ?? {};
  const ini = inicio || inicioIbsPadrao($('#sTrib').value);
  const comp = $('#dComp').value || hoje();
  const cst = so($('#iCst').value); const ct = so($('#iClass').value);
  let txt; let cls = '';
  if (modo === 'nunca') txt = 'não informar';
  else if (modo === 'auto' && comp < ini) txt = `não vai nesta nota (obrigatório a partir de ${dataBr(`${ini}T12:00`)})`;
  else if (cst.length === 3 && ct.length === 6) {
    const perfil = { sn_puro: ' · Simples puro', sn_hibrido: ' · Simples híbrido' }[estado.empresa?.ibscbs?.perfil] ?? '';
    txt = `vai na nota · CST ${cst} · ${ct}${perfil}`; cls = 'sim';
  }
  else { txt = 'obrigatório: falta CST/cClassTrib'; cls = 'falta'; }
  el.textContent = txt; el.className = `status-ibs ${cls}`;
  if (cls === 'falta') $('#detIbs').open = true;
}

// ------------------------------------------------------------------ descrição: banco, modelos e assistente saúde
const MARCA_BANCO = 'DADOS PARA PAGAMENTO:';

function blocoBancario(e = estado.empresa) {
  if (!e || !(e.pix || e.conta)) return '';
  const linhas = [MARCA_BANCO];
  if (e.banco) linhas.push(`Banco: ${e.banco}`);
  const ag = [e.agencia && `Agência: ${e.agencia}`, e.conta && `${e.tipoConta || 'Conta corrente'}: ${e.conta}`].filter(Boolean).join(' | ');
  if (ag) linhas.push(ag);
  if (e.pix) linhas.push(`Chave PIX: ${e.pix}`);
  linhas.push(`Favorecido: ${e.favorecido || e.razaoSocial} - ${e.cnpj?.length === 11 ? 'CPF' : 'CNPJ'} ${docFmt(e.cnpj)}`);
  return linhas.join('\n');
}
/** Tira o bloco bancário (do marcador até o fim), para não duplicar ao reaproveitar texto. */
const semBanco = (t = '') => { const i = t.indexOf(MARCA_BANCO); return (i >= 0 ? t.slice(0, i) : t).trimEnd(); };
const comBanco = (t = '') => { const b = blocoBancario(); return b ? `${semBanco(t)}\n\n${b}`.trim() : t; };

function atualizarContDesc() {
  const n = $('#sDesc').value.length;
  $('#contDesc').textContent = `${n}/2000`;
  $('#contDesc').classList.toggle('cheio', n > 1900);
  const e = estado.empresa;
  $('#dicaDesc').textContent = !e ? '' : e.incluirBanco && blocoBancario()
    ? 'Os dados bancários da empresa entram automaticamente no fim da descrição.'
    : blocoBancario() ? 'Use "Dados bancários" para incluir banco, agência, conta e PIX no fim da descrição.'
      : 'Cadastre banco/PIX em Empresas para incluí-los na descrição.';
}
function definirDescricao(texto) {
  $('#sDesc').value = estado.empresa?.incluirBanco ? comBanco(texto) : texto;
  atualizarContDesc();
}

// --- número por extenso (1 a 99), no gênero da unidade
function extenso(n, fem = false) {
  const u = ['zero', fem ? 'uma' : 'um', fem ? 'duas' : 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez',
    'onze', 'doze', 'treze', 'quatorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'];
  const d = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
  if (n < 20) return u[n];
  if (n < 100) return d[Math.floor(n / 10)] + (n % 10 ? ` e ${u[n % 10]}` : '');
  return String(n);
}
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

const AREAS_SAUDE = {
  psicologia: { nome: 'Psicologia', servico: 'atendimento psicológico', unidade: ['sessão', 'sessões'], fem: true, de: 'de psicoterapia', atividade: 'Sessão com o paciente', titulo: 'Psicólogo(a) responsável', conselho: 'CRP' },
  fisioterapia: { nome: 'Fisioterapia', servico: 'fisioterapia', unidade: ['sessão', 'sessões'], fem: true, de: 'de fisioterapia', atividade: 'Sessão de fisioterapia', titulo: 'Fisioterapeuta responsável', conselho: 'CREFITO' },
  fonoaudiologia: { nome: 'Fonoaudiologia', servico: 'fonoaudiologia', unidade: ['sessão', 'sessões'], fem: true, de: 'de terapia fonoaudiológica', atividade: 'Sessão de fonoterapia', titulo: 'Fonoaudiólogo(a) responsável', conselho: 'CRFa' },
  terapia_ocupacional: { nome: 'Terapia ocupacional', servico: 'terapia ocupacional', unidade: ['sessão', 'sessões'], fem: true, de: 'de terapia ocupacional', atividade: 'Sessão de terapia ocupacional', titulo: 'Terapeuta ocupacional responsável', conselho: 'CREFITO' },
  nutricao: { nome: 'Nutrição', servico: 'atendimento nutricional', unidade: ['consulta', 'consultas'], fem: true, de: 'de acompanhamento nutricional', atividade: 'Consulta nutricional', titulo: 'Nutricionista responsável', conselho: 'CRN' },
  medicina: { nome: 'Medicina', servico: 'atendimento médico', unidade: ['consulta', 'consultas'], fem: true, de: 'médicas', atividade: 'Consulta médica', titulo: 'Médico(a) responsável', conselho: 'CRM' },
  odontologia: { nome: 'Odontologia', servico: 'atendimento odontológico', unidade: ['atendimento', 'atendimentos'], fem: false, de: 'odontológicos', atividade: 'Atendimento odontológico', titulo: 'Cirurgião(ã)-dentista responsável', conselho: 'CRO' },
};

/** Texto no formato usado pelos profissionais da saúde (cabeçalho, discriminação, responsável). */
function textoSaude(p) {
  const a = AREAS_SAUDE[p.area] ?? AREAS_SAUDE.psicologia;
  const sessoes = p.sessoes.filter((s) => s.data).sort((x, y) => (x.data + x.hora).localeCompare(y.data + y.hora));
  const n = sessoes.length;
  const [ano, mes] = (p.mes || '').split('-').map(Number);
  const de = a.de.startsWith('de ') ? a.de : (n === 1 ? a.de.replace(/s$/, '') : a.de);
  const linhas = [
    `Prestação de serviços de ${a.servico}, referente a ${n} (${extenso(n, a.fem)}) ${n === 1 ? a.unidade[0] : a.unidade[1]} ${de} realizad${a.fem ? 'a' : 'o'}${n === 1 ? '' : 's'}${mes ? ` em ${MESES[mes - 1]} de ${ano}` : ''}${p.contrato ? ', conforme contrato de prestação de serviços' : ''}.`,
  ];
  if (p.paciente) linhas.push(`Paciente: ${p.paciente}`);
  if (n) {
    linhas.push('', `Discriminação ${a.fem ? 'das' : 'dos'} ${a.unidade[1]}:`);
    for (const s of sessoes) {
      const [aa, mm, dd] = s.data.split('-');
      linhas.push(`${dd}/${mm}/${aa}${s.hora ? ` às ${s.hora.replace(':', 'h')}` : ''} – ${s.atividade || a.atividade}`);
    }
  }
  if (p.observacao) linhas.push('', p.observacao);
  if (p.profissional || p.conselho) {
    linhas.push('');
    if (p.profissional) linhas.push(`${a.titulo}: ${p.profissional}`);
    if (p.conselho) linhas.push(`Conselho: ${p.conselho}`);
  }
  return linhas.join('\n');
}

/** Todas as datas do mês (aaaa-mm) que caem no dia da semana indicado (0=domingo). */
function datasDoMes(mes, diaSemana) {
  const [a, m] = mes.split('-').map(Number);
  const out = [];
  for (let d = 1; d <= 31; d++) {
    const dt = new Date(a, m - 1, d);
    if (dt.getMonth() !== m - 1) break;
    if (dt.getDay() === Number(diaSemana)) out.push(`${a}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`);
  }
  return out;
}
const mesSeguinte = (mes) => { const [a, m] = mes.split('-').map(Number); return m === 12 ? `${a + 1}-01` : `${a}-${String(m + 1).padStart(2, '0')}`; };
function mesPadrao() {
  const h = new Date();
  const d = h.getDate() <= 15 ? new Date(h.getFullYear(), h.getMonth() - 1, 1) : h;
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}
/**
 * Repete no mês novo o padrão semanal do mês anterior: cada dia da semana atendido
 * volta com o horário e a atividade da sessão mais recente naquele dia.
 */
function repetirPadrao(sessoes, mesNovo) {
  const vistos = new Map();
  const ordenadas = sessoes.filter((s) => s.data).sort((x, y) => (x.data + x.hora).localeCompare(y.data + y.hora));
  for (const s of ordenadas) {
    const ds = new Date(`${s.data}T12:00`).getDay();
    const atual = vistos.get(ds);
    vistos.set(ds, { ds, hora: s.hora || atual?.hora || '', atividade: s.atividade });
  }
  return [...vistos.values()].flatMap((p) => datasDoMes(mesNovo, p.ds).map((data) => ({ data, hora: p.hora, atividade: p.atividade })))
    .sort((x, y) => (x.data + x.hora).localeCompare(y.data + y.hora));
}

/** Reconstrói os dados do assistente a partir do texto de uma nota antiga (ex.: importada do portal). */
function assistenteDeTexto(texto = '') {
  const t = semBanco(texto);
  const sessoes = [];
  const re = /(\d{2})\/(\d{2})\/(\d{4})(?:\s*(?:às|as|a|-|–)?\s*(\d{1,2})\s*[h:]\s*(\d{2})?\s*h?)?\s*[-–:]?\s*([^\n]*)/gi;
  for (const m of t.matchAll(re)) {
    const [, dd, mm, aa, hh, mi, resto] = m;
    const dt = new Date(`${aa}-${mm}-${dd}T12:00`);
    if (Number.isNaN(dt.getTime()) || dt.getDate() !== Number(dd) || Number(aa) < 2000) continue;
    sessoes.push({ data: `${aa}-${mm}-${dd}`, hora: hh ? `${hh.padStart(2, '0')}:${mi ?? '00'}` : '', atividade: resto.replace(/^[-–.\s]+|[.\s]+$/g, '') });
  }
  if (!sessoes.length) return null;
  const baixo = t.toLowerCase();
  const area = /psic/.test(baixo) ? 'psicologia' : /fisio/.test(baixo) ? 'fisioterapia' : /fono/.test(baixo) ? 'fonoaudiologia'
    : /nutri/.test(baixo) ? 'nutricao' : /odont|dentista/.test(baixo) ? 'odontologia' : /terapia ocupacional/.test(baixo) ? 'terapia_ocupacional'
      : /m[ée]dic/.test(baixo) ? 'medicina' : 'psicologia';
  const padrao = AREAS_SAUDE[area].atividade.toLowerCase();
  for (const s of sessoes) if (s.atividade.toLowerCase() === padrao) s.atividade = '';
  sessoes.sort((x, y) => (x.data + x.hora).localeCompare(y.data + y.hora));
  return {
    area, mes: sessoes[sessoes.length - 1].data.slice(0, 7), contrato: /contrato/i.test(t),
    paciente: t.match(/paciente\s*:\s*([^\n]+)/i)?.[1].trim() ?? '', observacao: '', valorSessao: '',
    profissional: t.match(/respons[áa]vel\s*:\s*([^\n]*)/i)?.[1].trim() ?? estado.empresa?.profissional ?? '',
    conselho: t.match(/conselho\s*:\s*([^\n]*)/i)?.[1].trim() || t.match(/\b(CRP|CRM|CRN|CRO|CREFITO|CRFa)\b[^\n]*/)?.[0].trim() || estado.empresa?.conselho || '',
    sessoes,
  };
}

async function assistenteSaude(base) {
  if (!exigeEmpresa()) return;
  const e = estado.empresa;
  const anterior = base ?? estado.assistente;
  let p;
  if (anterior?.sessoes) {
    p = structuredClone(anterior);
    if (estado.assistenteDeNotaAnterior || base) {
      p.mes = mesSeguinte(anterior.mes || mesPadrao());
      p.sessoes = repetirPadrao(anterior.sessoes, p.mes);
    }
  } else {
    p = { area: 'psicologia', mes: mesPadrao(), contrato: true, paciente: '', observacao: '', valorSessao: '', profissional: e.profissional ?? '', conselho: e.conselho ?? '', sessoes: [] };
  }
  const form = $('#formModal');
  const primeira = p.sessoes.find((s) => s.data);
  const diaPadrao = primeira ? new Date(`${primeira.data}T12:00`).getDay() : 2;
  const horaPadrao = primeira?.hora || '16:00';
  const sessaoHtml = (s, i) => `<div class="sessao" data-i="${i}"><input type="date" value="${esc(s.data)}" data-k="data"><input type="time" value="${esc(s.hora)}" data-k="hora"><input value="${esc(s.atividade)}" data-k="atividade" placeholder="${esc(AREAS_SAUDE[p.area].atividade)}">${ico('excluir', 'Remover', `data-rm="${i}"`, 'perigo')}</div>`;
  const pronto = modal(`<h2>Assistente de descrição — saúde</h2>
    <p class="dica">Preencha só o que muda. O texto sai no formato usado pelos profissionais da saúde e você ainda pode editar antes de emitir.${anterior?.sessoes ? ' Trouxe o padrão da nota anterior, já com as datas do mês seguinte nos mesmos dias da semana e horários.' : ''}</p>
    <div class="linha">
      <div class="campo"><label>Área</label><select name="area">${Object.entries(AREAS_SAUDE).map(([k, a]) => `<option value="${k}" ${k === p.area ? 'selected' : ''}>${a.nome}</option>`).join('')}</select></div>
      <div class="campo"><label>Mês de referência</label><input type="month" name="mes" value="${esc(p.mes)}"></div>
      <div class="campo"><label>Valor por sessão (opcional)</label><input name="valorSessao" class="mono" value="${esc(p.valorSessao)}" placeholder="ex.: 150,00"></div>
    </div>
    <fieldset class="sub-cartao"><legend>Sessões / atendimentos</legend>
      <div class="linha">
        <div class="campo"><label>Preencher toda semana: dia</label><select name="semDia">${['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'].map((d, i) => `<option value="${i}" ${i === diaPadrao ? 'selected' : ''}>${d}-feira`.replace('domingo-feira', 'domingo').replace('sábado-feira', 'sábado') + '</option>').join('')}</select></div>
        <div class="campo pequeno"><label>Horário</label><input type="time" name="semHora" value="${horaPadrao}"></div>
        <div class="campo"><label>&nbsp;</label><button type="button" class="btn sec" id="btnSemanal">Adicionar todas do mês</button></div>
      </div>
      <div class="sessoes" id="sessoes"></div>
      <button type="button" class="btn mini sec" id="btnMaisSessao">+ Adicionar uma data</button>
    </fieldset>
    <div class="linha">
      <div class="campo grande"><label>Profissional responsável</label><input name="profissional" value="${esc(p.profissional)}"></div>
      <div class="campo"><label>Conselho / registro</label><input name="conselho" value="${esc(p.conselho)}" placeholder="ex.: CRP 13/12345"></div>
    </div>
    <div class="linha">
      <div class="campo"><label>Paciente (opcional — atenção ao sigilo)</label><input name="paciente" value="${esc(p.paciente)}" placeholder="iniciais ou nome, se o tomador exigir"></div>
      <div class="campo grande"><label>Observação (opcional)</label><input name="observacao" value="${esc(p.observacao)}"></div>
    </div>
    <label class="check"><input type="checkbox" name="contrato" ${p.contrato ? 'checked' : ''}> Citar "conforme contrato de prestação de serviços"</label>
    <label>Prévia</label><div class="previa-desc" id="previaSaude"></div>
    <div class="rodape"><button class="btn sec" value="cancelar" formnovalidate>Voltar</button><button class="btn pri" value="ok">Usar esta descrição</button></div>`, async () => true);

  const ler = () => {
    for (const k of ['area', 'mes', 'profissional', 'conselho', 'paciente', 'observacao', 'valorSessao']) p[k] = form.elements[k].value.trim();
    p.contrato = form.elements.contrato.checked;
  };
  const desenhar = () => {
    form.querySelector('#sessoes').innerHTML = p.sessoes.map(sessaoHtml).join('') || '<p class="dica">Nenhuma data ainda. Use "Adicionar todas do mês" ou "+ Adicionar uma data".</p>';
    previa();
  };
  const previa = () => { ler(); form.querySelector('#previaSaude').textContent = textoSaude(p); };
  form.oninput = (ev) => {
    const linha = ev.target.closest('.sessao');
    if (linha) p.sessoes[linha.dataset.i][ev.target.dataset.k] = ev.target.value;
    previa();
  };
  form.onchange = (ev) => { if (ev.target.name === 'area') desenhar(); };
  form.querySelector('#sessoes').onclick = (ev) => {
    const b = ev.target.closest('[data-rm]');
    if (!b) return;
    ev.preventDefault();
    p.sessoes.splice(Number(b.dataset.rm), 1); desenhar();
  };
  form.querySelector('#btnMaisSessao').onclick = () => { ler(); p.sessoes.push({ data: '', hora: form.elements.semHora.value, atividade: '' }); desenhar(); };
  form.querySelector('#btnSemanal').onclick = () => {
    ler();
    if (!p.mes) return toast('Escolha o mês de referência.', true);
    const novas = datasDoMes(p.mes, form.elements.semDia.value).map((data) => ({ data, hora: form.elements.semHora.value, atividade: '' }));
    const ja = new Set(p.sessoes.map((s) => s.data + s.hora));
    p.sessoes.push(...novas.filter((s) => !ja.has(s.data + s.hora)));
    p.sessoes.sort((x, y) => (x.data + x.hora).localeCompare(y.data + y.hora));
    desenhar();
  };
  desenhar();
  const ok = await pronto;
  form.oninput = null; form.onchange = null;
  if (!ok) return;
  estado.assistente = p;
  estado.assistenteDeNotaAnterior = false;
  definirDescricao(textoSaude(p));
  const qtd = p.sessoes.filter((s) => s.data).length;
  const vs = Number(String(p.valorSessao).replace(/\./g, '').replace(',', '.'));
  if (vs > 0 && qtd) $('#vServ').value = valorBr((vs * qtd).toFixed(2));
  if (!p.mes) return;
  const [a, m] = p.mes.split('-').map(Number);
  const ultimoDia = new Date(a, m, 0).getDate();
  if (!$('#dComp').value || $('#dComp').value.slice(0, 7) !== p.mes) $('#dComp').value = `${p.mes}-${String(ultimoDia).padStart(2, '0')}`;
  // Guarda profissional e conselho no cadastro da empresa, se ainda não houver.
  if ((p.profissional && !e.profissional) || (p.conselho && !e.conselho)) {
    try {
      const nova = await api('PUT', `/api/empresas/${e.id}`, { profissional: e.profissional || p.profissional, conselho: e.conselho || p.conselho });
      Object.assign(estado.empresa, { profissional: nova.profissional, conselho: nova.conselho });
    } catch { /* não é essencial */ }
  }
}

async function abrirModelos() {
  if (!exigeEmpresa()) return;
  const e = estado.empresa;
  const doc = so($('#tDoc').value);
  const [ultEmp, ultTom, salvos] = await Promise.all([
    api('GET', `/api/empresas/${e.id}/sugestao`),
    [11, 14].includes(doc.length) ? api('GET', `/api/empresas/${e.id}/sugestao?tomador=${doc}&somenteTomador=1`) : null,
    api('GET', `/api/empresas/${e.id}/modelos`),
  ]);
  const itens = [];
  const assist = (ent) => ent.servico?.assistente ?? assistenteDeTexto(ent.servico?.descricao);
  if (ultTom?.origem === 'tomador') itens.push({ nome: 'Última nota deste tomador', sub: `nº ${ultTom.nota.numero} de ${dataBr(ultTom.nota.dhProc)} · ${moeda(ultTom.nota.vServ)}`, texto: ultTom.entrada.servico?.descricao ?? '', assistente: assist(ultTom.entrada) });
  if (ultEmp.origem && ultEmp.nota.id !== ultTom?.nota?.id) itens.push({ nome: 'Última nota da empresa', sub: `nº ${ultEmp.nota.numero} de ${dataBr(ultEmp.nota.dhProc)} para ${ultEmp.nota.tomadorNome}`, texto: ultEmp.entrada.servico?.descricao ?? '', assistente: assist(ultEmp.entrada) });
  for (const m of salvos) itens.push({ nome: m.nome, sub: 'Modelo salvo', texto: m.texto, id: m.id, assistente: assistenteDeTexto(m.texto) });
  const li = (it, i) => `<li><div><b>${esc(it.nome)}</b><small>${esc(it.sub)}</small></div><div class="botoes">
      ${it.assistente ? `<button type="button" class="btn mini sec" data-assist="${i}">Assistente: mês seguinte</button>` : ''}
      <button type="button" class="btn mini pri" data-usar="${i}">Usar</button>
      ${it.id ? ico('excluir', 'Excluir modelo', `data-del-modelo="${it.id}"`, 'perigo') : ''}</div>
      <pre>${esc(semBanco(it.texto))}</pre></li>`;
  const form = $('#formModal');
  const pronto = modal(`<h2>Modelos de descrição</h2>
    <p class="dica">Escolha um texto para reaproveitar e depois mude só o que precisar. Os dados bancários são recolocados com os dados atuais da empresa.</p>
    <ul class="lista-modelos">${itens.map(li).join('') || '<p class="dica">Ainda não há nota nem modelo salvo para esta empresa.</p>'}
      <li><div><b>Assistente saúde (sessões/consultas)</b><small>Psicologia, fisioterapia, fonoaudiologia, nutrição, medicina…</small></div><div class="botoes"><button type="button" class="btn mini pri" data-assist="novo">Abrir</button></div></li>
    </ul>
    <div class="rodape"><button class="btn sec" value="cancelar">Fechar</button></div>`);
  form.querySelector('.lista-modelos').onclick = async (ev) => {
    const b = ev.target.closest('button');
    if (!b) return;
    ev.preventDefault(); ev.stopPropagation();
    const d = b.dataset;
    if (d.usar) {
      const it = itens[Number(d.usar)];
      $('#modal').close();
      estado.assistente = it.assistente ?? null;
      estado.assistenteDeNotaAnterior = Boolean(it.assistente);
      definirDescricao(semBanco(it.texto));
      toast(`Descrição de “${it.nome}” aplicada. Ajuste o que mudar.`);
    } else if (d.assist) {
      $('#modal').close();
      await new Promise((r) => setTimeout(r, 50));
      await assistenteSaude(d.assist === 'novo' ? null : itens[Number(d.assist)].assistente);
    } else if (d.delModelo) {
      if (!confirm('Excluir este modelo?')) return;
      await api('DELETE', `/api/modelos/${d.delModelo}`);
      b.closest('li').remove();
    }
  };
  await pronto;
}

async function salvarModelo() {
  if (!exigeEmpresa()) return;
  const texto = semBanco($('#sDesc').value);
  if (!texto.trim()) return toast('Escreva a descrição antes de salvar como modelo.', true);
  await modal(`<h2>Salvar descrição como modelo</h2>
    <div class="campo"><label>Nome do modelo *</label><input name="nome" required placeholder="ex.: Mensalidade do sistema"></div>
    <label>Texto</label><div class="previa-desc">${esc(texto)}</div>
    <p class="dica">Os dados bancários não entram no modelo: eles são recolocados com os dados atuais da empresa quando você usar.</p>
    ${rodapeModal('Salvar modelo')}`, (f) => api('POST', `/api/empresas/${estado.empresa.id}/modelos`, { nome: valorCampo(f, 'nome'), texto }));
}

function inserirBanco() {
  if (!exigeEmpresa()) return;
  if (!blocoBancario()) { toast('Esta empresa não tem banco/PIX cadastrado. Abra Empresas → Editar → Dados bancários.', true); return; }
  $('#sDesc').value = comBanco($('#sDesc').value);
  atualizarContDesc();
}

// ------------------------------------------------------------------ histórico
/** Ações secundárias da nota num menu "⋯ Mais" (os botões mantêm os mesmos data-* de antes). */
function menuMaisNota(n) {
  const emitida = n.papel !== 'recebida';
  const it = (icone, rotulo, attrs, cls = '') => `<button type="button" class="item-mais ${cls}" ${attrs}>${svg(icone)}<span>${rotulo}</span></button>`;
  const lk = (icone, rotulo, href, extra = '') => `<a class="item-mais" href="${href}" ${extra}>${svg(icone)}<span>${rotulo}</span></a>`;
  const itens = [
    n.chaveAcesso ? lk('baixar', 'Baixar DANFSe (PDF)', `/api/notas/${n.id}/pdf?baixar=1`, 'download') : '',
    n.chaveAcesso ? lk('xml', 'Baixar XML', `/api/notas/${n.id}/xml`, 'download') : '',
    emitida ? it('modelo', 'Usar como modelo', `data-modelo="${n.id}"`) : '',
    emitida && n.chaveAcesso ? it('favorito', 'Cadastrar serviço a partir desta nota', `data-servico-nota="${n.id}"`) : '',
    emitida && n.chaveAcesso ? it('anexo', n.anexos?.length ? `Anexos (${n.anexos.length})` : 'Anexos', `data-anexos="${n.id}"`) : '',
    n.status === 'autorizada' && emitida && n.ambiente === estado.empresa.ambiente ? it('substituir', 'Substituir nota', `data-substituir="${n.id}"`) : '',
    n.status === 'autorizada' && emitida && n.ambiente === estado.empresa.ambiente && n.analiseFiscal?.status !== 'solicitada' ? it('cancelar', 'Cancelar nota', `data-cancelar="${n.id}"`, 'perigo') : '',
  ].filter(Boolean);
  if (!itens.length) return '';
  return `<span class="mais-wrap"><button type="button" class="ico ico-mais${n.anexos?.length ? ' com-anexo' : ''}" data-mais="1" aria-label="Mais ações" aria-haspopup="true" data-dica="Mais ações">⋯</button><span class="menu-mais" role="menu" hidden>${itens.join('')}</span></span>`;
}
document.addEventListener('click', (ev) => {
  const botao = ev.target.closest('[data-mais]');
  const aberto = document.querySelector('.menu-mais:not([hidden])');
  if (aberto && (!botao || aberto !== botao.nextElementSibling)) aberto.hidden = true;
  if (botao) {
    const m = botao.nextElementSibling; m.hidden = !m.hidden;
    if (!m.hidden) { // posição fixa: não é cortado pela tabela com rolagem
      const r = botao.getBoundingClientRect(); const alt = m.offsetHeight;
      m.style.position = 'fixed'; m.style.right = `${Math.max(8, innerWidth - r.right)}px`; m.style.left = 'auto';
      m.style.top = `${r.bottom + 4 + alt > innerHeight ? Math.max(8, r.top - alt - 4) : r.bottom + 4}px`;
    }
    ev.stopPropagation(); return;
  }
  if (ev.target.closest('.item-mais') && aberto) aberto.hidden = true;
});
window.addEventListener('scroll', () => document.querySelectorAll('.menu-mais').forEach((m) => { m.hidden = true; }), true);
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') document.querySelectorAll('.menu-mais').forEach((m) => { m.hidden = true; }); });

async function carregarHistorico() {
  if (!exigeEmpresa()) return;
  const papel = $('#fPapel').value;
  const q = new URLSearchParams({ de: $('#fDe').value, ate: $('#fAte').value, q: $('#fBusca').value, status: $('#fStatus').value, papel });
  const { notas, totais } = await api('GET', `/api/empresas/${estado.empresa.id}/notas?${q}`);
  const recebidas = papel === 'recebida';
  $('#thContraparte').textContent = { emitida: 'Tomador', recebida: 'Prestador', todas: 'Contraparte' }[papel];
  $('#totais').innerHTML = `<div><span>Notas autorizadas</span><b>${totais.quantidade}</b></div>
    <div><span>${recebidas ? 'Serviços tomados' : 'Faturamento'}</span><b>${moeda(totais.vServ)}</b></div><div><span>ISS destacado</span><b>${moeda(totais.vISSQN)}</b></div>`;
  $('#tabNotas tbody').innerHTML = notas.length ? notas.map((n) => `<tr>
    <td class="mono">${esc(n.numero ?? '—')}<span class="sub">DPS ${esc(n.serie ?? '')}/${esc(n.nDPS ?? '')}</span></td>
    <td>${dataBr(n.dhProc ?? n.criadoEm)}<span class="sub">comp. ${dataBr(n.competencia && `${n.competencia}T12:00`)}</span></td>
    <td>${esc(n.tomadorNome)}<span class="sub mono">${docFmt(n.tomadorDoc)}</span></td>
    <td><span class="desc" title="${esc(n.descricao ?? '')}">${esc(n.descricao ?? '')}</span>${n.erro ? `<span class="sub">${esc(n.erro)}</span>` : ''}</td>
    <td class="num">${moeda(n.vServ)}</td><td class="num">${moeda(n.vISSQN)}</td>
    <td><span class="selo ${n.status}">${n.status}</span>${n.papel === 'recebida' && papel === 'todas' ? ' <span class="selo amb">recebida</span>' : ''}${n.origem === 'portal' ? ' <span class="selo portal">portal</span>' : ''}${n.ambiente !== 'producao' ? ` <span class="selo amb">${n.ambiente === 'simulacao' ? 'simulação' : 'homolog.'}</span>` : ''}</td>
    <td class="acoes"><div class="icones acoes-nota">${n.chaveAcesso ? icoLink('ver', 'Ver DANFSe (PDF)', `/api/notas/${n.id}/pdf`, 'target="_blank"') : ''}${n.status === 'autorizada' && n.papel !== 'recebida' && n.chaveAcesso ? ico('recibo', n.recibo ? 'Recibo assinado (gerar de novo)' : 'Gerar recibo assinado', `data-recibo="${n.id}"`, n.recibo ? 'com-anexo' : '') : ''}${menuMaisNota(n)}</div>${n.analiseFiscal ? `<span class="sub analise ${n.analiseFiscal.status}">${{ solicitada: 'cancelamento em análise na prefeitura', deferida: 'cancelamento deferido pela prefeitura', indeferida: 'cancelamento indeferido pela prefeitura' }[n.analiseFiscal.status] ?? ''}</span>` : ''}${n.cancelamentoPendente ? '<span class="sub">cancelamento aguardando a Receita</span>' : ''}${n.substituidaPorNumero ? `<span class="sub">substituída pela nº ${esc(n.substituidaPorNumero)}</span>` : ''}${n.substituiNumero ? `<span class="sub">substitui a nº ${esc(n.substituiNumero)}</span>` : ''}</td>
  </tr>`).join('') : '<tr><td colspan="8" class="vazio">Nenhuma nota no período.</td></tr>';
}

/** Puxa do Portal Nacional (ADN) todas as NFS-e da empresa, em lotes, até zerar a fila. */
async function importarPortal() {
  if (!exigeEmpresa()) return;
  const total = { emitidas: 0, recebidas: 0, canceladas: 0, jaExistiam: 0, ignorados: 0 };
  try {
    for (let rodada = 1; rodada <= 40; rodada++) {
      toast(`Consultando o Portal Nacional… lote ${rodada} (${total.emitidas + total.recebidas} notas novas até agora)`);
      let r;
      for (let tentativa = 1; ; tentativa++) {
        try { r = await api('POST', `/api/empresas/${estado.empresa.id}/sincronizar`); break; }
        catch (e) {
          if (tentativa >= 3 || !/comunicação/i.test(e.message)) throw e;
          toast(`Portal Nacional instável, tentando de novo (${tentativa}/3)…`);
          await new Promise((ok) => setTimeout(ok, 3000));
        }
      }
      for (const k of Object.keys(total)) total[k] += r[k] ?? 0;
      if (r.concluido) break;
    }
    toast(`Portal Nacional: ${total.emitidas} emitida(s) e ${total.recebidas} recebida(s) importadas, ${total.canceladas} cancelamento(s) aplicados, ${total.jaExistiam} já estavam no histórico.`);
    await carregarHistorico();
  } catch (e) { falha(e); }
}

async function iniciarSubstituicao(id) {
  const nota = await api('GET', `/api/notas/${id}`);
  if (!nota.entrada) return toast('Esta nota não guarda os dados de preenchimento. Importe-a do Portal Nacional primeiro.', true);
  location.hash = '#emitir';
  await mostrarTela('emitir', false);
  limparEmissao(false);
  preencherTomador(nota.entrada.tomador);
  preencherServicoValores(nota.entrada);
  if (nota.competencia) $('#dComp').value = nota.competencia;
  if (!estado.motivosSubst) estado.motivosSubst = await api('GET', '/api/sistema/motivos-substituicao');
  $('#cMotivo').innerHTML = Object.entries(estado.motivosSubst).map(([k, v]) => `<option value="${k}" ${k === '99' ? 'selected' : ''}>${k} — ${esc(v)}</option>`).join('');
  estado.substituindo = { id: nota.id, numero: nota.numero };
  $('#blocoSubst').hidden = false;
  $('#btnPrevia').hidden = true;
  $('#btnEmitir').textContent = `Emitir substituta da nº ${nota.numero}`;
  mostrarOrigem(`<b>Substituindo a NFS-e nº ${esc(nota.numero)}</b> de ${dataBr(nota.dhProc)} para ${esc(nota.tomadorNome)} (${moeda(nota.vServ)}). Corrija o que for preciso e informe o motivo no fim da página.`);
  $('#avisoOrigem').classList.add('subst');
}

// ------------------------------------------------------------------ cancelamento e anexos
async function enviarAnexos(notaId, arquivos, descricao = '') {
  for (const arq of arquivos) {
    if (arq.size > 10 * 1024 * 1024) { toast(`${arq.name}: máximo de 10 MB.`, true); continue; }
    await api('POST', `/api/notas/${notaId}/anexos`, { nome: arq.name, tipo: arq.type, base64: await lerArquivoBase64(arq), descricao });
  }
}

const listaAnexosHtml = (nota) => (nota.anexos?.length
  ? `<ul class="anexos">${nota.anexos.map((x) => `<li><a href="/api/notas/${nota.id}/anexos/${x.id}" target="_blank">${esc(x.nome)}</a><span>${(x.tamanho / 1024).toFixed(0)} KB · ${dataBr(x.criadoEm)}</span>${ico('excluir', 'Remover anexo', `data-del-anexo="${x.id}"`, 'perigo')}</li>`).join('')}</ul>`
  : '<p class="dica">Nenhum anexo ainda.</p>');

async function gerenciarAnexos(id) {
  let nota = await api('GET', `/api/notas/${id}`);
  const form = $('#formModal');
  const redesenhar = () => { form.querySelector('#listaAnexos').innerHTML = listaAnexosHtml(nota); };
  const pronto = modal(`<h2>Anexos da NFS-e nº ${esc(nota.numero)}</h2>
    <p class="dica">Guarde aqui o requerimento assinado, a declaração do tomador, comprovantes e o protocolo da prefeitura. Os arquivos ficam neste computador, junto com a nota.</p>
    <div id="listaAnexos"></div>
    <label class="btn sec arquivo">${svg('anexo')} Adicionar arquivo (PDF, PNG ou JPG)<input type="file" id="novoAnexo" accept="application/pdf,image/png,image/jpeg" multiple hidden></label>
    <div class="rodape"><button class="btn pri" value="cancelar">Fechar</button></div>`);
  redesenhar();
  form.querySelector('#novoAnexo').onchange = async (ev) => {
    try { await enviarAnexos(id, ev.target.files); nota = await api('GET', `/api/notas/${id}`); redesenhar(); } catch (e) { falha(e); }
    ev.target.value = '';
  };
  form.querySelector('#listaAnexos').onclick = async (ev) => {
    const b = ev.target.closest('[data-del-anexo]');
    if (!b) return;
    ev.preventDefault(); ev.stopPropagation();
    try { await api('DELETE', `/api/notas/${id}/anexos/${b.dataset.delAnexo}`); nota = await api('GET', `/api/notas/${id}`); redesenhar(); } catch (e) { falha(e); }
  };
  await pronto;
  await carregarHistorico();
}

async function cancelarNota(id) {
  let nota = await api('GET', `/api/notas/${id}`);
  if (!estado.motivosCanc) estado.motivosCanc = await api('GET', '/api/sistema/motivos-cancelamento');
  const prod = nota.ambiente === 'producao';
  const chaveModo = `modoCancelamento:${nota.empresaId}`;
  let modoPadrao = 'direto';
  try { modoPadrao = localStorage.getItem(chaveModo) ?? 'direto'; } catch { /* sem storage */ }
  const form = $('#formModal');
  const pronto = modal(`<h2>Cancelar a NFS-e nº ${esc(nota.numero)}</h2>
    <p class="dica">${esc(nota.tomadorNome)} · ${moeda(nota.vServ)} · emitida em ${dataBr(nota.dhProc)}. O pedido vai ao Sistema Nacional e <b>não pode ser desfeito</b>. Se a nota só tem um erro, prefira <b>Substituir</b>.</p>
    <div class="modos">
      <label class="modo"><input type="radio" name="modo" value="direto" ${modoPadrao === 'direto' ? 'checked' : ''}><span><b>Cancelamento direto</b><small>A nota é cancelada na hora, se o município permitir.</small></span></label>
      <label class="modo"><input type="radio" name="modo" value="analise" ${modoPadrao === 'analise' ? 'checked' : ''}><span><b>Solicitar análise fiscal à prefeitura</b><small>Para municípios que exigem requerimento ou termo assinado, ou quando o prazo do cancelamento direto já passou. A nota fica "em análise" até a prefeitura deferir.</small></span></label>
    </div>
    <div class="linha"><div class="campo grande"><label>Motivo *</label><select name="cMotivo">${Object.entries(estado.motivosCanc).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('')}</select></div></div>
    <div class="linha"><div class="campo grande"><label>Justificativa * (de 15 a 255 caracteres; vai no evento e no requerimento)</label><textarea name="xMotivo" rows="3" minlength="15" maxlength="255" required></textarea></div></div>
    <div class="bloco-analise">
      <p class="dica"><b>Documentos para a prefeitura.</b> O Sistema Nacional recebe só o motivo e a justificativa. O requerimento assinado e a declaração do tomador são protocolados na prefeitura; guarde as cópias aqui.</p>
      <div class="acoes-linha">
        <button type="button" class="btn sec" id="btnRequerimento">${svg('emitir')} Gerar requerimento (PDF)</button>
        <label class="btn sec arquivo">${svg('anexo')} Anexar requerimento assinado / termo<input type="file" id="anexoCanc" accept="application/pdf,image/png,image/jpeg" multiple hidden></label>
      </div>
      <div id="listaAnexos"></div>
    </div>
    ${prod ? '<label class="check"><input type="checkbox" name="confirma" required> Confirmo o pedido de cancelamento desta nota em Produção (com valor fiscal)</label>' : ''}
    <div class="rodape"><button class="btn sec" value="cancelar" formnovalidate>Voltar</button><button class="btn perigo" value="ok" id="btnConfCanc">Cancelar nota</button></div>`, async (f) => {
    const modo = f.elements.modo.value;
    const corpo = { cMotivo: f.elements.cMotivo.value, xMotivo: valorCampo(f, 'xMotivo'), confirmar: prod ? f.elements.confirma.checked : undefined };
    const resp = await api('POST', `/api/notas/${id}/${modo === 'analise' ? 'analise-fiscal' : 'cancelar'}`, corpo);
    if (resp.status === 'rejeitada') {
      if (modo === 'direto') {
        f.elements.modo.value = 'analise';
        atualizarModo();
        const e = new Error('A Receita/prefeitura recusou o cancelamento direto. Selecionei "Solicitar análise fiscal": gere o requerimento, anexe e envie de novo.');
        e.detalhes = resp.mensagens; throw e;
      }
      const e = new Error('A solicitação de análise fiscal foi recusada.'); e.detalhes = resp.mensagens; throw e;
    }
    try { localStorage.setItem(chaveModo, modo); } catch { /* sem storage */ }
    return resp;
  });
  const atualizarModo = () => {
    const analise = form.elements.modo.value === 'analise';
    form.querySelector('.bloco-analise').hidden = !analise;
    form.querySelector('#btnConfCanc').textContent = analise ? 'Enviar solicitação à prefeitura' : 'Cancelar nota';
  };
  const redesenhar = () => { form.querySelector('#listaAnexos').innerHTML = listaAnexosHtml(nota); };
  form.querySelectorAll('[name=modo]').forEach((r) => { r.onchange = atualizarModo; });
  atualizarModo(); redesenhar();
  form.querySelector('#btnRequerimento').onclick = () => {
    const just = valorCampo(form, 'xMotivo');
    if (just.length < 15) return toast('Escreva a justificativa (mínimo de 15 caracteres) antes de gerar o requerimento.', true);
    window.open(`/api/notas/${id}/requerimento?${new URLSearchParams({ cMotivo: form.elements.cMotivo.value, xMotivo: just })}`, '_blank');
  };
  form.querySelector('#anexoCanc').onchange = async (ev) => {
    try { await enviarAnexos(id, ev.target.files, 'Cancelamento'); nota = await api('GET', `/api/notas/${id}`); redesenhar(); } catch (e) { falha(e); }
    ev.target.value = '';
  };
  form.querySelector('#listaAnexos').onclick = async (ev) => {
    const b = ev.target.closest('[data-del-anexo]');
    if (!b) return;
    ev.preventDefault(); ev.stopPropagation();
    try { await api('DELETE', `/api/notas/${id}/anexos/${b.dataset.delAnexo}`); nota = await api('GET', `/api/notas/${id}`); redesenhar(); } catch (e) { falha(e); }
  };
  const r = await pronto;
  if (!r) { await carregarHistorico(); return; }
  toast(r.status === 'cancelada' ? `NFS-e nº ${nota.numero} cancelada.`
    : r.status === 'analise_solicitada' ? `Solicitação de cancelamento da NFS-e nº ${nota.numero} enviada. Protocole o requerimento na prefeitura; a nota fica "em análise" até o deferimento.`
      : r.mensagem);
  await carregarHistorico();
}

/** Abre o cadastro de serviço favorito já preenchido com os dados de uma nota emitida. */
async function servicoDaNota(id) {
  if (!exigeEmpresa()) return;
  const nota = await api('GET', `/api/notas/${id}`);
  const s = nota.entrada?.servico ?? {};
  const v = nota.entrada?.valores ?? {};
  if (!s.cTribNac && !nota.cTribNac) return toast('Esta nota não guarda os dados do serviço. Importe-a do Portal Nacional primeiro.', true);
  const desc = semBanco(s.descricao ?? nota.descricao ?? '');
  const ib = nota.entrada?.ibscbs ?? nota.ibscbs ?? {};
  const jaExiste = estado.servicos.find((x) => x.cTribNac === so(s.cTribNac ?? nota.cTribNac) && semBanco(x.descricao ?? '') === desc);
  if (jaExiste) toast(`Já existe um favorito igual: “${jaExiste.apelido}”. Você pode salvar outro com outro apelido.`);
  await editarServico({
    apelido: desc.split('\n')[0].replace(/^(presta[çc][ãa]o de servi[çc]os? de\s+)/i, '').slice(0, 40),
    cTribNac: so(s.cTribNac ?? nota.cTribNac), cNBS: so(s.cNBS), cTribMun: s.cTribMun ?? '', descricao: desc,
    vServ: v.vServ ?? nota.vServ, aliqIss: v.aliqIss ?? '', tpRetISSQN: v.tpRetISSQN ?? '1', codMunicipioPrestacao: s.codMunicipioPrestacao ?? '',
    ibscbs: Object.fromEntries(Object.entries({ CST: ib.CST, cClassTrib: ib.cClassTrib, cIndOp: ib.cIndOp }).filter(([, x]) => x)),
  });
}

async function usarComoModelo(id) {
  const nota = await api('GET', `/api/notas/${id}`);
  if (!nota.entrada) return toast('Esta nota não guarda os dados de preenchimento.', true);
  location.hash = '#emitir';
  await mostrarTela('emitir', false);
  limparEmissao(false);
  preencherTomador(nota.entrada.tomador);
  preencherServicoValores(nota.entrada);
  mostrarOrigem(`Preenchido a partir da nota ${nota.numero ? `nº <b>${esc(nota.numero)}</b>` : 'selecionada'}. Confira valor e competência.`);
}

// ------------------------------------------------------------------ tomadores
function formTomador(t = {}) {
  const e = t.endereco ?? {};
  return `<h2>${t.id ? 'Editar' : 'Novo'} tomador</h2>
  <div class="linha"><div class="campo"><label>CPF / CNPJ *</label><input name="documento" class="mono" required value="${esc(docFmt(t.documento))}"></div>
  <div class="campo grande"><label>Nome / razão social *</label><input name="nome" required value="${esc(t.nome)}"></div></div>
  <div class="linha"><div class="campo grande"><label>E-mail</label><input name="email" type="email" value="${esc(t.email)}"></div>
  <div class="campo"><label>Telefone</label><input name="fone" value="${esc(t.fone)}"></div>
  <div class="campo"><label>Inscrição municipal</label><input name="inscricaoMunicipal" value="${esc(t.inscricaoMunicipal)}"></div></div>
  <div class="linha"><div class="campo pequeno"><label>CEP</label><input name="cep" class="mono" value="${esc(e.cep)}"></div>
  <div class="campo grande"><label>Logradouro</label><input name="logradouro" value="${esc(e.logradouro)}"></div>
  <div class="campo pequeno"><label>Número</label><input name="numero" value="${esc(e.numero)}"></div></div>
  <div class="linha"><div class="campo"><label>Bairro</label><input name="bairro" value="${esc(e.bairro)}"></div>
  <div class="campo"><label>Complemento</label><input name="complemento" value="${esc(e.complemento)}"></div>
  <div class="campo grande"><label>Cidade (digite o nome)</label><input name="cidade" value="${esc(e.cidade)}"></div>
  <div class="campo pequeno"><label>Cód. IBGE</label><input name="codMunicipio" class="mono" value="${esc(e.codMunicipio)}"></div></div>
  ${rodapeModal()}`;
}

function dadosTomador(f) {
  const v = (n) => valorCampo(f, n);
  return {
    documento: so(v('documento')), nome: v('nome'), email: v('email'), fone: v('fone'), inscricaoMunicipal: v('inscricaoMunicipal'),
    endereco: so(v('cep')) ? { cep: so(v('cep')), logradouro: v('logradouro'), numero: v('numero'), bairro: v('bairro'),
      complemento: v('complemento'), cidade: v('cidade'), codMunicipio: so(v('codMunicipio')) } : undefined,
  };
}

async function editarTomador(t) {
  const aberto = modal(formTomador(t), (f) => (t?.id
    ? api('PUT', `/api/tomadores/${t.id}`, dadosTomador(f))
    : api('POST', `/api/empresas/${estado.empresa.id}/tomadores`, dadosTomador(f))));
  const f = $('#formModal');
  ligarMunicipio(f.elements.cidade, f.elements.codMunicipio, { sep: ' - ' });
  let ultimo = so(f.elements.documento.value);
  f.elements.documento.addEventListener('blur', async () => {
    const doc = so(f.elements.documento.value);
    f.elements.documento.value = docFmt(doc);
    if (doc.length !== 14 || doc === ultimo) return;
    ultimo = doc;
    try {
      const d = await consultarCnpj(doc);
      const e = d.endereco ?? {};
      const val = { nome: d.razaoSocial, email: d.email, fone: d.fone, cep: e.cep, logradouro: e.logradouro, numero: e.numero, bairro: e.bairro, complemento: e.complemento, cidade: e.cidade, codMunicipio: e.codMunicipio };
      for (const [k, v] of Object.entries(val)) if (v && f.elements[k]) f.elements[k].value = v;
      toast(`Dados trazidos da Receita (${d.situacao || 'situação não informada'}).`, Boolean(d.situacao && d.situacao.toUpperCase() !== 'ATIVA'));
    } catch (err) { toast(err.message, true); }
  });
  const ok = await aberto;
  if (ok) { await trocarEmpresa(estado.empresa); renderTomadores(); toast('Tomador salvo.'); }
}

function renderTomadores() {
  const termo = $('#buscaTom').value.toLowerCase();
  const lista = estado.tomadores.filter((t) => !termo || `${t.nome} ${t.documento}`.toLowerCase().includes(termo));
  $('#tabTomadores tbody').innerHTML = lista.length ? lista.map((t) => `<tr><td>${esc(t.nome)}</td><td class="mono">${docFmt(t.documento)}</td>
    <td>${esc(t.email)}</td><td>${esc(t.endereco?.cidade)}</td>
    <td class="acoes"><div class="icones">${ico('emitir', 'Emitir nota para este tomador', `data-emitir-tom="${t.id}"`)}${ico('editar', 'Editar tomador', `data-edit-tom="${t.id}"`)}${ico('excluir', 'Excluir tomador', `data-del-tom="${t.id}"`, 'perigo')}</div></td></tr>`).join('')
    : '<tr><td colspan="5" class="vazio">Nenhum tomador cadastrado. Eles também são salvos automaticamente ao emitir.</td></tr>';
}

// ------------------------------------------------------------------ serviços
function formServico(s = {}) {
  return `<h2>${s.id ? 'Editar' : 'Novo'} serviço favorito</h2>
  <div class="linha"><div class="campo grande"><label>Apelido *</label><input name="apelido" required value="${esc(s.apelido)}" placeholder="ex.: Honorário mensal"></div>
  <div class="campo"><label>Cód. tributação nacional *</label><input name="cTribNac" class="mono" required value="${esc(s.cTribNac)}"></div>
  <div class="campo"><label>NBS</label><input name="cNBS" class="mono" value="${esc(s.cNBS)}"></div>
  <div class="campo pequeno"><label>Cód. municipal <small>(3 díg., opcional)</small></label><input name="cTribMun" class="mono" maxlength="3" inputmode="numeric" pattern="\\d{3}" title="3 dígitos. Deixe em branco se a prefeitura não exigir." value="${esc(s.cTribMun)}"></div></div>
  <div class="campo"><label>Descrição padrão *</label><textarea name="descricao" rows="4" required>${esc(s.descricao)}</textarea></div>
  <div class="linha"><div class="campo grande"><label>Município da prestação (vazio = o da empresa)</label><input name="munNome" placeholder="Digite o nome da cidade"></div>
  <div class="campo pequeno"><label>Cód. IBGE</label><input name="codMunicipioPrestacao" class="mono" maxlength="7" value="${esc(s.codMunicipioPrestacao ?? '')}"></div></div>
  <div class="linha"><div class="campo"><label>Valor padrão (R$)</label><input name="vServ" class="mono" value="${esc(valorBr(s.vServ))}"></div>
  <div class="campo"><label>Alíquota ISS (%)</label><input name="aliqIss" class="mono" value="${esc(s.aliqIss)}"></div>
  <div class="campo"><label>Retenção ISS</label><select name="tpRetISSQN">${['Não retido', 'Retido pelo tomador', 'Retido pelo intermediário'].map((o, i) => `<option value="${i + 1}" ${String(s.tpRetISSQN ?? '1') === String(i + 1) ? 'selected' : ''}>${o}</option>`).join('')}</select></div></div>
  <fieldset class="sub-cartao"><legend>IBS/CBS deste serviço (vazio = usar o da empresa)</legend>
  <div class="linha"><div class="campo pequeno"><label>CST</label><input name="ibsCst" class="mono" maxlength="3" value="${esc(s.ibscbs?.CST)}"></div>
  <div class="campo"><label>cClassTrib</label><input name="ibsClass" class="mono" maxlength="6" value="${esc(s.ibscbs?.cClassTrib)}"></div>
  <div class="campo"><label>cIndOp</label><input name="ibsIndOp" class="mono" maxlength="6" value="${esc(s.ibscbs?.cIndOp)}"></div>
  <div class="campo"><label>Obrigatório a partir de</label><input type="date" name="ibsInicio" value="${esc(s.ibscbs?.inicio ?? '')}"></div></div>
  <div class="linha"><div class="campo grande"><label>Classificação frequente (preenche CST e cClassTrib)</label><select name="ibsComum"><option value="">— escolher —</option>${estado.sistema.classificacoes.map((c) => `<option value="${c.cClassTrib}">${esc(c.nome)}</option>`).join('')}</select></div>
  <div class="campo grande"><label>Atividade no Simples (cAtvSN)</label><select name="ibsAtv"><option value="">— da empresa —</option>${Object.entries(estado.sistema.atividadesSN).map(([k, v]) => `<option value="${k}" ${String(s.ibscbs?.cAtvSN ?? '') === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></div></div>
  </fieldset>
  ${rodapeModal()}`;
}

async function editarServico(s) {
  const dados = (f) => ({
    apelido: valorCampo(f, 'apelido'), cTribNac: so(valorCampo(f, 'cTribNac')), cNBS: so(valorCampo(f, 'cNBS')), cTribMun: valorCampo(f, 'cTribMun'),
    descricao: valorCampo(f, 'descricao'), vServ: valorCampo(f, 'vServ').replace(/\./g, '').replace(',', '.'),
    aliqIss: valorCampo(f, 'aliqIss').replace(',', '.'), tpRetISSQN: valorCampo(f, 'tpRetISSQN'), codMunicipioPrestacao: so(valorCampo(f, 'codMunicipioPrestacao')),
    ibscbs: Object.fromEntries(Object.entries({ CST: so(valorCampo(f, 'ibsCst')), cClassTrib: so(valorCampo(f, 'ibsClass')), cIndOp: so(valorCampo(f, 'ibsIndOp')), inicio: valorCampo(f, 'ibsInicio'), cAtvSN: valorCampo(f, 'ibsAtv') }).filter(([, v]) => v)),
  });
  const aberto = modal(formServico(s), (f) => (s?.id ? api('PUT', `/api/servicos/${s.id}`, dados(f)) : api('POST', `/api/empresas/${estado.empresa.id}/servicos`, dados(f))));
  const fs_ = $('#formModal');
  ligarMunicipio(fs_.elements.munNome, fs_.elements.codMunicipioPrestacao);
  fs_.elements.ibsComum.onchange = (ev) => {
    const c = estado.sistema.classificacoes.find((x) => x.cClassTrib === ev.target.value);
    if (c) { fs_.elements.ibsCst.value = c.CST; fs_.elements.ibsClass.value = c.cClassTrib; }
  };
  const ok = await aberto;
  if (ok) { await trocarEmpresa(estado.empresa); renderServicos(); toast('Serviço salvo.'); }
}

function renderServicos() {
  $('#tabServicos tbody').innerHTML = estado.servicos.length ? estado.servicos.map((s) => `<tr><td>${esc(s.apelido)}</td><td class="mono">${esc(s.cTribNac)}</td><td class="mono">${esc(s.cNBS)}</td>
    <td>${esc(s.descricao?.slice(0, 80))}</td><td class="num">${s.vServ ? moeda(s.vServ) : '—'}</td>
    <td class="acoes"><div class="icones">${ico('editar', 'Editar serviço', `data-edit-serv="${s.id}"`)}${ico('excluir', 'Excluir serviço', `data-del-serv="${s.id}"`, 'perigo')}</div></td></tr>`).join('')
    : '<tr><td colspan="6" class="vazio">Cadastre os serviços que a empresa emite com frequência.</td></tr>';
}

// ------------------------------------------------------------------ versão da instalação
const EDICOES = { admin: 'Versão Contador · Administrador', contador: 'Versão Contador', cliente: 'Versão Cliente', livre: '', sem_verificacao: '' };
const podeProcuracao = () => ['admin', 'contador'].includes(estado.instalacao?.edicao);
function aplicarEdicao() {
  const i = estado.instalacao ?? {};
  $('#edicaoLateral').textContent = EDICOES[i.edicao] ? `${EDICOES[i.edicao]}${i.edicao === 'contador' ? ` · ${i.usados} de ${i.limite} clientes${i.quarentena ? ` (${i.quarentena} excluída${i.quarentena > 1 ? 's' : ''} em 30 dias)` : ''}` : ''}` : '';
  const cliente = i.edicao === 'cliente';
  $('#seletorEmpresa').hidden = cliente && estado.empresas.length <= 1;
  $('#novaEmpresa').hidden = cliente && estado.empresas.length >= 1;
  aplicarMenu();
}

/** Menu e textos por versão: Administrador (tudo), Contador (escritório + clientes) e Cliente (só a própria empresa). */
const MENUS = {
  admin: { empresas: 'Empresas', tituloEmp: 'Empresas emitentes', usuarios: 'Usuários', tituloUsu: 'Usuários', tomadores: 'Tomadores' },
  contador: { empresas: 'Clientes do escritório', tituloEmp: 'Clientes do escritório', usuarios: 'Equipe', tituloUsu: 'Equipe do escritório', tomadores: 'Tomadores', novo: 'Novo cliente' },
  cliente: { empresas: 'Minha empresa', tituloEmp: 'Minha empresa', usuarios: 'Acessos', tituloUsu: 'Acessos ao sistema', tomadores: 'Meus clientes' },
};
/** Menu do escritório só para quem tem licença Contador; qualquer outra instalação (inclusive ainda sem liberação) vê o menu de empresa. */
const tipoMenu = () => ({ admin: 'admin', contador: 'contador' }[estado.instalacao?.edicao] ?? 'cliente');
function aplicarMenu() {
  const t = tipoMenu(); const m = MENUS[t]; const i = estado.instalacao ?? {};
  document.body.dataset.edicao = t;
  $('#navEmpresas').textContent = m.empresas; $('#tituloEmpresas').textContent = m.tituloEmp;
  $('#navUsuarios').textContent = m.usuarios; $('#tituloUsuarios').textContent = m.tituloUsu;
  $('#navTomadores').textContent = m.tomadores;
  $('#novaEmpresa').textContent = m.novo ?? 'Nova empresa';
  $('#cartaoLeiaute').hidden = t !== 'admin';
  $('#navLicencas').hidden = !(t === 'admin' && estado.usuario?.papel === 'admin' && estado.sistema?.adminLicencas);
  $('#navContratos').hidden = $('#navLicencas').hidden;
  $('#navUsuarios').hidden = !(t === 'admin' && estado.usuario?.papel === 'admin');
  const vagas = $('#cartaoVagas');
  vagas.hidden = !(i.edicao === 'contador');
  if (i.edicao === 'contador') {
    const livres = Math.max(0, (i.limite ?? 0) - (i.usados ?? 0));
    vagas.innerHTML = `<b>${i.usados} de ${i.limite}</b> vagas de clientes em uso · <b>${livres}</b> livre${livres === 1 ? '' : 's'}${i.quarentena ? ` · ${i.quarentena} ocupada${i.quarentena > 1 ? 's' : ''} por empresa excluída (libera em 30 dias)` : ''}. Para ampliar, fale com o suporte.`;
  }
}

// ------------------------------------------------------------------ empresas (tela)
function formEmpresa(e = {}) {
  const opt = (valor, rotulo, atual) => `<option value="${valor}" ${String(atual) === String(valor) ? 'selected' : ''}>${rotulo}</option>`;
  return `<h2>${e.id ? 'Editar' : 'Nova'} empresa emitente</h2>
  <p class="dica">Comece pelo certificado A1 <i>ou</i> pelo CNPJ: os dados cadastrais vêm da Receita automaticamente.</p>
  ${podeProcuracao() ? `<div class="linha"><div class="campo grande"><label>Acesso à Receita</label><select name="acesso">${opt('proprio', 'Certificado A1 da própria empresa', e.acesso ?? 'proprio')}${opt('procuracao', 'Procuração eletrônica (certificado do escritório)', e.acesso ?? 'proprio')}</select></div>
  <div class="campo grande" data-proc><label>Empresa procuradora (dona do certificado)</label><select name="procuradorId">${estado.empresas.filter((x) => x.id !== e.id && x.certificado && x.acesso !== 'procuracao').map((x) => opt(x.id, `${esc(x.razaoSocial)} — ${docFmt(x.cnpj)}`, e.procuradorId ?? estado.empresas.find((y) => y.cnpj === estado.instalacao?.titular)?.id)).join('') || '<option value="">Cadastre antes o escritório com o A1</option>'}</select></div>
  <div class="campo" data-proc><label>Procuração válida até</label><input type="date" name="procuracaoAte" value="${esc(e.procuracaoAte ?? '')}"></div></div>
  <p class="dica" data-proc>O cliente cadastra a procuração no portal da Receita (Controle de Acesso → Nova Autorização, serviço <b>NFS-e</b>) e o escritório confirma em <b>Recebidas</b>. A nota sai no CNPJ do cliente, assinada com o certificado do escritório. Na primeira vez, teste em Produção Restrita.</p>` : ''}
  <div class="linha" id="linhaCert"><div class="campo grande"><label>Certificado A1 (.pfx / .p12) ${e.certificado ? '— já cadastrado; envie outro só para trocar' : ''}</label><input name="cert" type="file" accept=".pfx,.p12"></div>
  <div class="campo"><label>Senha do certificado</label><input name="senha" type="password" autocomplete="new-password"></div></div>
  <div class="linha"><div class="campo"><label>CNPJ *</label><input name="cnpj" class="mono" required value="${esc(docFmt(e.cnpj))}"></div>
  <div class="campo grande"><label>Razão social *</label><input name="razaoSocial" required value="${esc(e.razaoSocial)}"></div></div>
  <p class="dica" id="infoCadastro"></p>
  <div class="linha"><div class="campo grande"><label>Município * (digite o nome)</label><input name="municipio" value="${esc(e.municipio ?? 'Campina Grande/PB')}" placeholder="Digite o nome da cidade"></div>
  <div class="campo pequeno"><label>Cód. IBGE *</label><input name="codMunicipio" class="mono" required maxlength="7" value="${esc(e.codMunicipio ?? '2504009')}"></div>
  <div class="campo"><label>Inscrição municipal</label><input name="inscricaoMunicipal" value="${esc(e.inscricaoMunicipal)}"></div></div>
  <div class="linha"><div class="campo"><label>Simples Nacional *</label><select name="opSimpNac">${opt(3, 'ME/EPP optante', e.opSimpNac ?? 3)}${opt(2, 'MEI', e.opSimpNac)}${opt(1, 'Não optante', e.opSimpNac)}</select></div>
  <div class="campo"><label>Apuração (ME/EPP)</label><select name="regApTribSN">${opt(1, 'Federal e municipal pelo SN', e.regApTribSN ?? 1)}${opt(2, 'Federal pelo SN, ISS fora', e.regApTribSN)}${opt(3, 'Federal e municipal fora do SN', e.regApTribSN)}</select></div>
  <div class="campo"><label>Regime especial</label><select name="regEspTrib">${[['0', 'Nenhum'], ['1', 'Ato cooperado'], ['2', 'Estimativa'], ['3', 'Microempresa municipal'], ['4', 'Notário/registrador'], ['5', 'Profissional autônomo'], ['6', 'Sociedade de profissionais'], ['9', 'Outros']].map(([v, r]) => opt(v, r, e.regEspTrib ?? '0')).join('')}</select></div></div>
  <div class="linha"><div class="campo"><label>% aprox. tributos SN (ME/EPP)</label><input name="pTotTribSN" class="mono" value="${esc(e.pTotTribSN ?? '')}" placeholder="ex.: 6"></div>
  <div class="campo"><label>% federal (não optante)</label><input name="pTotTribFed" class="mono" value="${esc(e.pTotTribFed ?? '')}"></div>
  <div class="campo"><label>% estadual</label><input name="pTotTribEst" class="mono" value="${esc(e.pTotTribEst ?? '')}"></div>
  <div class="campo"><label>% municipal</label><input name="pTotTribMun" class="mono" value="${esc(e.pTotTribMun ?? '')}"></div></div>
  <div class="linha"><div class="campo pequeno"><label>Série DPS</label><input name="serie" class="mono" value="${esc(e.serie ?? '1')}"></div>
  <div class="campo pequeno"><label>Nº DPS inicial</label><input name="nDpsInicial" class="mono" value="${esc(e.nDpsInicial ?? '1')}"></div>
  <div class="campo grande"><label>Ambiente</label><select name="ambiente">${Object.entries(estado.sistema.ambientes).map(([k, v]) => opt(k, v, e.ambiente ?? 'producao_restrita')).join('')}</select></div></div>
  <fieldset class="sub-cartao"><legend>Dados bancários e profissional (para a descrição da nota)</legend>
  <div class="linha"><div class="campo grande"><label>Banco</label><input name="banco" value="${esc(e.banco)}" placeholder="ex.: 077 - Banco Inter"></div>
  <div class="campo pequeno"><label>Agência</label><input name="agencia" class="mono" value="${esc(e.agencia)}"></div>
  <div class="campo"><label>Conta (com dígito)</label><input name="conta" class="mono" value="${esc(e.conta)}"></div>
  <div class="campo"><label>Tipo</label><select name="tipoConta">${['Conta corrente', 'Conta poupança', 'Conta de pagamento'].map((t) => opt(t, t, e.tipoConta ?? 'Conta corrente')).join('')}</select></div></div>
  <div class="linha"><div class="campo grande"><label>Chave PIX</label><input name="pix" value="${esc(e.pix)}" placeholder="CNPJ, e-mail, telefone ou chave aleatória"></div>
  <div class="campo grande"><label>Favorecido</label><input name="favorecido" value="${esc(e.favorecido)}" placeholder="vazio = razão social"></div></div>
  <label class="check"><input type="checkbox" name="incluirBanco" ${e.incluirBanco ? 'checked' : ''}> Incluir os dados bancários automaticamente no fim da descrição de toda nota</label>
  <div class="linha"><div class="campo grande"><label>Profissional responsável (saúde)</label><input name="profissional" value="${esc(e.profissional)}"></div>
  <div class="campo"><label>Conselho / registro</label><input name="conselho" value="${esc(e.conselho)}" placeholder="ex.: CRP 13/12345"></div></div>
  </fieldset>
  <fieldset class="sub-cartao" id="blocoIbsEmp"><legend>IBS/CBS — Reforma Tributária (padrão desta empresa)</legend>
  <div class="linha"><div class="campo grande"><label>Modelo</label><select name="ibsPerfil">${Object.entries(estado.sistema.perfisIbsCbs).map(([k, v]) => opt(k, v.nome, e.ibscbs?.perfil ?? 'personalizado')).join('')}</select></div>
  <div class="campo grande"><label>Regime de apuração do IBS/CBS (Simples)</label><select name="ibsRegAp">${opt('', '—', e.ibscbs?.regApIBSCBSSN ?? '')}${Object.entries(estado.sistema.regimesIbsCbsSN).map(([k, v]) => opt(k, v, e.ibscbs?.regApIBSCBSSN ?? '')).join('')}</select></div></div>
  <div class="linha"><div class="campo grande"><label>Atividade no Simples (cAtvSN)</label><select name="ibsAtv">${opt('', '—', e.ibscbs?.cAtvSN ?? '')}${Object.entries(estado.sistema.atividadesSN).map(([k, v]) => opt(k, v, e.ibscbs?.cAtvSN ?? '')).join('')}</select></div></div>
  <p class="dica" id="dicaPerfil"></p>
  <div class="linha"><div class="campo grande"><label>Quando informar</label><select name="ibsModo">${Object.entries(estado.sistema.modosIbsCbs).map(([k, v]) => opt(k, v, e.ibscbs?.modo ?? 'auto')).join('')}</select></div>
  <div class="campo"><label>Obrigatório a partir de</label><input type="date" name="ibsInicio" value="${esc(e.ibscbs?.inicio ?? '')}"></div></div>
  <div class="linha"><div class="campo pequeno"><label>CST</label><input name="ibsCst" class="mono" maxlength="3" value="${esc(e.ibscbs?.CST)}"></div>
  <div class="campo"><label>cClassTrib</label><input name="ibsClass" class="mono" maxlength="6" value="${esc(e.ibscbs?.cClassTrib)}"></div>
  <div class="campo"><label>Indicador da operação (cIndOp)</label><input name="ibsIndOp" class="mono" maxlength="6" value="${esc(e.ibscbs?.cIndOp)}"></div>
  <div class="campo"><label>Uso ou consumo pessoal</label><select name="ibsIndFinal">${opt('', 'Não informar', e.ibscbs?.indFinal ?? '')}${opt('0', 'Não', e.ibscbs?.indFinal ?? '')}${opt('1', 'Sim', e.ibscbs?.indFinal ?? '')}</select></div></div>
  <p class="dica">Data vazia = 01/01/2027 (itens 1.03, 1.05, 1.09 e 16.01: 01/03/2027, Ato Conjunto RFB/CGIBS nº 7/2026). Antes da data o grupo não vai na nota; depois, sem CST e cClassTrib a emissão é bloqueada com aviso. O serviço favorito pode ter códigos próprios.</p>
  </fieldset>
  <label class="check" id="linhaConfirmaProd" ${e.ambiente === 'producao' ? 'hidden' : ''}><input type="checkbox" name="confirmaProd"> Confirmo que, em Produção, as notas emitidas para esta empresa terão valor fiscal</label>
  <p class="dica">A série de 1 a 49999 é a faixa reservada a aplicativo próprio, por isso não colide com notas emitidas no portal (Emissor Web usa 70000 a 79999). O certificado e a senha ficam cifrados (AES-256) na pasta de dados deste computador.</p>
  ${rodapeModal()}`;
}

const lerArquivoBase64 = (arquivo) => new Promise((ok, erro) => {
  const r = new FileReader();
  r.onload = () => ok(String(r.result).split(',')[1]);
  r.onerror = erro;
  r.readAsDataURL(arquivo);
});

/** Modelo IBS/CBS (Simples puro / híbrido): preenche os códigos e mostra a orientação. */
function ligarPerfilIbs(f) {
  const el = (n) => f.elements[n];
  const dica = () => {
    const p = estado.sistema.perfisIbsCbs[el('ibsPerfil').value] ?? {};
    const sn = ['2', '3'].includes(el('opSimpNac').value);
    f.querySelector('#dicaPerfil').textContent = `${p.dica ?? 'Informe CST, cClassTrib e cIndOp desta empresa.'}${sn ? '' : ' (Este modelo é para optantes do Simples; a empresa não está marcada como optante.)'}${estado.sistema.xsdCamposSimples ? '' : ' Regime e atividade do Simples ficam guardados e entram no XML quando o leiaute da NT 009 com esses campos estiver publicado.'}`;
  };
  el('ibsPerfil').addEventListener('change', () => {
    const p = estado.sistema.perfisIbsCbs[el('ibsPerfil').value] ?? {};
    if (p.CST) {
      el('ibsCst').value = p.CST; el('ibsClass').value = p.cClassTrib; el('ibsIndOp').value = p.cIndOp; el('ibsRegAp').value = p.regApIBSCBSSN;
      if (!el('ibsModo').value) el('ibsModo').value = 'auto';
    }
    dica();
  });
  el('opSimpNac').addEventListener('change', dica);
  dica();
}

/** Liga a leitura do A1 e a consulta do CNPJ ao formulário de empresa. */
function ligarFormEmpresa(f) {
  ligarPerfilIbs(f);
  if (f.elements.acesso) {
    const alternar = () => {
      const proc = f.elements.acesso.value === 'procuracao';
      f.querySelectorAll('[data-proc]').forEach((el) => { el.hidden = !proc; });
      f.querySelector('#linhaCert').hidden = proc;
    };
    f.elements.acesso.addEventListener('change', alternar);
    alternar();
  }
  ligarMunicipio(f.elements.municipio, f.elements.codMunicipio, { sep: '/' });
  const info = $('#infoCadastro', f);
  const campo = (n) => f.elements[n];
  let ultimo = so(campo('cnpj').value);

  async function porCnpj() {
    const cnpj = so(campo('cnpj').value);
    campo('cnpj').value = docFmt(cnpj);
    if (cnpj.length !== 14 || cnpj === ultimo) return;
    ultimo = cnpj;
    info.textContent = 'Consultando CNPJ na Receita…';
    try {
      const d = await consultarCnpj(cnpj);
      campo('razaoSocial').value = d.razaoSocial || campo('razaoSocial').value;
      if (d.codMunicipio) campo('codMunicipio').value = d.codMunicipio;
      if (d.municipio) campo('municipio').value = d.municipio;
      if (d.opSimpNac) campo('opSimpNac').value = d.opSimpNac;
      const regime = { 1: 'fora do Simples', 2: 'MEI', 3: 'optante do Simples (ME/EPP)' }[d.opSimpNac] ?? 'regime não informado';
      info.innerHTML = `Dados da Receita: ${esc(d.razaoSocial)} · ${esc(d.municipio)} · <b>${regime}</b> · situação ${esc(d.situacao || '—')}. Confira o regime e preencha a inscrição municipal.${avisoSituacao(d.situacao)}`;
    } catch (err) { info.textContent = err.message; }
  }

  async function porCertificado() {
    const arq = campo('cert').files[0];
    const senha = campo('senha').value;
    if (!arq || !senha) return;
    info.textContent = 'Lendo certificado…';
    try {
      const c = await api('POST', '/api/certificado/ler', { certificadoBase64: await lerArquivoBase64(arq), senhaCertificado: senha });
      const dias = Math.ceil((new Date(c.validade) - Date.now()) / 86400000);
      info.innerHTML = `Certificado de <b>${esc(c.razaoSocial)}</b>, válido até ${dataBr(c.validade)} (${dias} dias).`;
      if (c.cnpj.length === 14) {
        if (so(campo('cnpj').value) && so(campo('cnpj').value) !== c.cnpj) {
          info.innerHTML += ' <b style="color:var(--erro)">O CNPJ do certificado é diferente do informado — corrigido para o do certificado.</b>';
        }
        campo('cnpj').value = docFmt(c.cnpj);
        if (!campo('razaoSocial').value) campo('razaoSocial').value = c.razaoSocial;
        const msg = info.innerHTML;
        await porCnpj();
        info.innerHTML = `${msg}<br>${info.innerHTML}`;
      }
    } catch (err) { info.textContent = err.message; }
  }

  const linhaProd = $('#linhaConfirmaProd', f);
  const ajustarProd = () => { if (linhaProd) linhaProd.hidden = campo('ambiente').value !== 'producao' || linhaProd.dataset.jaProd === '1'; };
  if (linhaProd && linhaProd.hasAttribute('hidden')) linhaProd.dataset.jaProd = '1';
  campo('ambiente').addEventListener('change', ajustarProd);
  ajustarProd();
  campo('cnpj').addEventListener('blur', porCnpj);
  campo('cert').addEventListener('change', () => (campo('senha').value ? porCertificado() : campo('senha').focus()));
  campo('senha').addEventListener('change', porCertificado);
}

async function editarEmpresa(e) {
  const aberto = modal(formEmpresa(e), async (f) => {
    const campos = ['razaoSocial', 'cnpj', 'codMunicipio', 'municipio', 'inscricaoMunicipal', 'opSimpNac', 'regApTribSN', 'regEspTrib', 'pTotTribSN', 'pTotTribFed', 'pTotTribEst', 'pTotTribMun', 'serie', 'nDpsInicial', 'ambiente',
      'banco', 'agencia', 'conta', 'tipoConta', 'pix', 'favorecido', 'profissional', 'conselho'];
    const dados = Object.fromEntries(campos.map((c) => [c, valorCampo(f, c)]));
    dados.incluirBanco = f.elements.incluirBanco.checked;
    if (f.elements.acesso) Object.assign(dados, { acesso: f.elements.acesso.value, procuradorId: f.elements.procuradorId?.value || undefined, procuracaoAte: f.elements.procuracaoAte?.value || '' });
    dados.ibscbs = { perfil: valorCampo(f, 'ibsPerfil'), regApIBSCBSSN: valorCampo(f, 'ibsRegAp'), cAtvSN: valorCampo(f, 'ibsAtv'), modo: valorCampo(f, 'ibsModo'), inicio: valorCampo(f, 'ibsInicio'), CST: so(valorCampo(f, 'ibsCst')), cClassTrib: so(valorCampo(f, 'ibsClass')), cIndOp: so(valorCampo(f, 'ibsIndOp')), indFinal: valorCampo(f, 'ibsIndFinal') };
    if (dados.ibscbs.CST && dados.ibscbs.cClassTrib && !dados.ibscbs.cClassTrib.startsWith(dados.ibscbs.CST)) throw new Error('O cClassTrib deve começar pelos 3 dígitos do CST.');
    dados.cnpj = so(dados.cnpj);
    const arq = f.elements.cert.files[0];
    if (arq) { dados.certificadoBase64 = await lerArquivoBase64(arq); dados.senhaCertificado = f.elements.senha.value; }
    if (dados.ambiente === 'producao' && e?.ambiente !== 'producao') {
      // Sem confirm() nativo: em janelas de app ele pode ser bloqueado e travar a troca.
      if (!f.elements.confirmaProd?.checked) throw new Error('Para ativar a Produção, marque a confirmação de que as notas terão valor fiscal.');
      dados.confirmarProducao = true;
    }
    return e?.id ? api('PUT', `/api/empresas/${e.id}`, dados) : api('POST', '/api/empresas', dados);
  });
  ligarFormEmpresa($('#formModal'));
  const ok = await aberto;
  if (ok) { estado.empresa = typeof ok === 'object' ? ok : estado.empresa; await carregarEmpresas(); renderEmpresas(); toast('Empresa salva.'); }
}

function procuracaoCelula(e) {
  const p = estado.empresas.find((x) => x.id === e.procuradorId);
  const dias = e.procuracaoAte ? Math.round((new Date(`${e.procuracaoAte}T12:00`) - Date.now()) / 86400000) : null;
  return `procuração via ${esc(p?.razaoSocial ?? '?')}${e.procuracaoAte ? `<span class="sub">até ${dataBr(`${e.procuracaoAte}T12:00`)}${dias !== null && dias < 30 ? ` <span class="selo rejeitada">${dias < 0 ? 'vencida' : `${dias} dias`}</span>` : ''}</span>` : ''}`;
}
async function excluirEmpresaUI(id) {
  const e = estado.empresas.find((x) => x.id === id);
  const adm = estado.instalacao?.edicao === 'admin';
  const msg = adm
    ? `Excluir ${e?.razaoSocial} e o certificado guardado?`
    : `Excluir ${e?.razaoSocial}?\n\nA empresa sai da lista, mas continua ocupando a vaga da licença por 30 dias. Nesse prazo você pode restaurá-la (ou cadastrar o mesmo CNPJ de novo, sem ocupar outra vaga).`;
  if (!confirm(msg)) return;
  const r = await api('DELETE', `/api/empresas/${id}`);
  toast(r.quarentena ? `Empresa excluída. A vaga fica ocupada até ${dataBr(r.liberaVagaEm)}.` : 'Empresa excluída.');
  estado.empresa = null;
  await carregarEmpresas();
  renderEmpresas();
}
async function renderExcluidas() {
  const lista = await api('GET', '/api/empresas-excluidas');
  $('#cartaoExcluidas').hidden = !lista.length;
  $('#tabExcluidas tbody').innerHTML = lista.map((x) => `<tr><td>${esc(x.razaoSocial)}</td><td class="mono">${docFmt(x.cnpj)}</td>
    <td>${dataBr(x.excluidaEm)}</td><td>${dataBr(x.liberaVagaEm)}</td>
    <td class="acoes"><div class="icones">${ico('reativar', 'Restaurar empresa', `data-rest-emp="${x.id}"`)}</div></td></tr>`).join('');
}
function renderEmpresas() {
  if (tipoMenu() === 'cliente') $('#cartaoExcluidas').hidden = true; else renderExcluidas().catch(() => {});
  const amb = { simulacao: 'Simulação', producao_restrita: 'Homologação', producao: 'Produção' };
  $('#tabEmpresas tbody').innerHTML = estado.empresas.length ? estado.empresas.map((e) => {
    const venc = e.certificado ? new Date(e.certificado.validade) : null;
    const dias = venc ? Math.ceil((venc - Date.now()) / 86400000) : null;
    return `<tr><td>${esc(e.razaoSocial)}<span class="sub">${esc(e.municipio)}</span></td><td class="mono">${docFmt(e.cnpj)}</td><td>${REGIMES[e.opSimpNac]}</td>
    <td><span class="selo ${e.ambiente === 'producao' ? 'autorizada' : 'amb'}">${amb[e.ambiente]}</span></td>
    <td>${e.acesso === 'procuracao' ? procuracaoCelula(e) : venc ? `vence ${venc.toLocaleDateString('pt-BR')}${dias < 30 ? ` <span class="selo rejeitada">${dias} dias</span>` : ''}` : '<span class="sub">não cadastrado</span>'}</td>
    <td class="mono">${esc(e.serie)}/${e.proximoNDps}</td>
    <td><span class="selo ${{ liberado: 'autorizada', vencendo: 'vencendo' }[e.licenca?.status] ?? 'rejeitada'}">${e.licenca?.admin ? 'administrador' : (SITUACAO_LIC[e.licenca?.status] ?? '—')}</span>${e.licenca?.ate ? `<span class="sub">até ${dataBr(`${e.licenca.ate}T12:00`)}</span>` : ''}</td>
    <td class="acoes"><div class="icones">${ico('editar', 'Editar empresa', `data-edit-emp="${e.id}"`)}${tipoMenu() === 'cliente' ? '' : ico('excluir', 'Excluir empresa', `data-del-emp="${e.id}"`, 'perigo')}</div></td></tr>`;
  }).join('') : '<tr><td colspan="8" class="vazio">Cadastre a primeira empresa. Comece no modo Simulação para conhecer o sistema sem certificado.</td></tr>';
}

// ------------------------------------------------------------------ navegação
const TELAS_LIVRES = ['empresas', 'usuarios', 'licencas', 'contratos', 'ajuda', 'suporte'];
async function mostrarTela(nome, recarregar = true) {
  if (['usuarios', 'licencas', 'contratos'].includes(nome) && estado.instalacao && tipoMenu() !== 'admin') { location.hash = '#emitir'; return; }
  const travada = estado.bloqueado && !TELAS_LIVRES.includes(nome);
  $('#telaBloqueio').hidden = !travada;
  $$('.tela').forEach((t) => { t.hidden = travada || t.id !== `tela-${nome}`; });
  if (travada) { $$('nav a').forEach((a) => a.classList.toggle('ativo', a.dataset.tela === nome)); return; }
  $$('nav a').forEach((a) => a.classList.toggle('ativo', a.dataset.tela === nome));
  if (!recarregar) return;
  try {
    if (nome === 'historico') await carregarHistorico();
    if (nome === 'tomadores') renderTomadores();
    if (nome === 'servicos') renderServicos();
    if (nome === 'empresas') renderEmpresas();
    if (nome === 'usuarios') await renderUsuarios();
    if (nome === 'licencas') await renderLicencas();
    if (nome === 'contratos') await renderContratos();
    if (nome === 'ajuda') renderAjuda();
    if (nome === 'suporte') await renderSuporte();
  } catch (e) { falha(e); }
}
const telaAtual = () => (location.hash.slice(1) || 'emitir');

function ligarEventos() {
  window.addEventListener('hashchange', () => mostrarTela(telaAtual()));
  $('#seletorEmpresa').onchange = async (ev) => {
    await trocarEmpresa(estado.empresas.find((e) => e.id === ev.target.value));
    limparEmissao(false);
    mostrarTela(telaAtual());
  };
  $('#formEmissao').onsubmit = emitir;
  $('#formEmissao').addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter' && !ev.target.matches('textarea, button, [type=submit], [type=button]')) ev.preventDefault();
  });
  $('#btnPrevia').onclick = previa;
  $('#btnLimpar').onclick = () => limparEmissao(false);
  $('#btnUltima').onclick = () => sugerirUltima(true).catch(falha);
  ligarMunicipio($('#sMunNome'), $('#sMun'));
  ligarMunicipio($('#eCidade'), $('#eIbge'), { sep: ' - ' });
  $('#btnModelos').onclick = () => abrirModelos().catch(falha);
  $('#btnAssistSaude').onclick = () => assistenteSaude().catch(falha);
  $('#btnBanco').onclick = inserirBanco;
  $('#btnSalvarModelo').onclick = () => salvarModelo().then((r) => r && toast('Modelo salvo.')).catch(falha);
  $('#sDesc').oninput = atualizarContDesc;
  for (const id of ['#iCst', '#iClass', '#iIndOp', '#dComp', '#sTrib']) $(id).addEventListener('input', atualizarStatusIbs);
  $('#dComp').addEventListener('change', atualizarStatusIbs);
  $('#semTomador').onchange = (ev) => { $('#blocoTomador').hidden = ev.target.checked; };
  $('#buscaTomador').onchange = (ev) => {
    const doc = ev.target.value.split('·').pop();
    if (so(doc).length >= 11) aoEscolherTomador(doc).catch(falha);
    ev.target.value = '';
  };
  $('#tDoc').onblur = () => {
    const d = so($('#tDoc').value);
    $('#tDoc').value = docFmt(d);
    if ([11, 14].includes(d.length) && estado.empresa && d !== estado.ultimoDocTomador) {
      estado.ultimoDocTomador = d;
      aoEscolherTomador(d).catch(falha);
    }
  };
  $('#eCep').onblur = buscarCep;
  $('#vServ').onblur = (ev) => { const v = ev.target.value.replace(/\./g, '').replace(',', '.'); if (v && !isNaN(v)) ev.target.value = valorBr(v); };
  $('#favorito').onchange = (ev) => {
    const s = estado.servicos.find((x) => x.id === ev.target.value);
    if (!s) return;
    preencherServicoValores({ servico: s, valores: { vServ: s.vServ || '', aliqIss: s.aliqIss, tpRetISSQN: s.tpRetISSQN } });
    mostrarOrigem(`Serviço preenchido a partir do favorito “${esc(s.apelido)}”.`);
    if (so($('#sTrib').value).length === 6) carregarTabelas().then(() => sugerirCodigos(so($('#sTrib').value), { sobrescrever: false })).catch(() => {});
  };
  $('#btnImportar').onclick = (ev) => ocupado(ev.target, importarPortal);
  ['#fDe', '#fAte', '#fStatus', '#fPapel'].forEach((s) => { $(s).onchange = () => carregarHistorico().catch(falha); });
  let t; $('#fBusca').oninput = () => { clearTimeout(t); t = setTimeout(() => carregarHistorico().catch(falha), 300); };
  $('#btnReprocessar').onclick = (ev) => ocupado(ev.target, async () => {
    try { const r = await api('POST', '/api/pendentes/reprocessar'); toast(r.length ? `${r.length} pendência(s) processada(s).` : 'Nenhuma pendência.'); carregarHistorico(); } catch (e) { falha(e); }
  });
  $('#buscaTom').oninput = renderTomadores;
  $('#novoTomador').onclick = () => exigeEmpresa() && editarTomador();
  $('#novoServico').onclick = () => exigeEmpresa() && editarServico();
  $('#novaEmpresa').onclick = () => editarEmpresa();

  const balao = document.createElement('div');
  balao.id = 'dica';
  document.body.append(balao);
  document.body.addEventListener('mouseover', (ev) => {
    const alvo = ev.target.closest('[data-dica]');
    if (!alvo) { balao.classList.remove('visivel'); return; }
    balao.textContent = alvo.dataset.dica;
    const r = alvo.getBoundingClientRect();
    balao.classList.add('visivel');
    const w = balao.offsetWidth;
    const left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), innerWidth - w - 8);
    const top = r.top - balao.offsetHeight - 8;
    balao.style.left = `${left}px`;
    balao.style.top = `${top < 8 ? r.bottom + 8 : top}px`;
  });
  document.addEventListener('scroll', () => balao.classList.remove('visivel'), true);
  document.body.addEventListener('click', async (ev) => {
    const b = ev.target.closest('button');
    if (!b) return;
    const d = b.dataset;
    try {
      if (d.modelo) await usarComoModelo(d.modelo);
      if (d.substituir) await iniciarSubstituicao(d.substituir);
      if (d.cancelar) await cancelarNota(d.cancelar);
      if (d.anexos) await gerenciarAnexos(d.anexos);
      if (d.servicoNota) await servicoDaNota(d.servicoNota);
      if (d.ativoUsr) { await api('PUT', `/api/usuarios/${d.ativoUsr}/ativo`, { ativo: d.ativo === '1' }); renderUsuarios(); }
      if (d.senhaUsr) await redefinirSenhaUsuario(d.senhaUsr, d.nome);
      if (d.licEdit || d.licMes || d.licBloq || d.licDel) await acaoLicenca(d);
      if (d.recibo) await gerarRecibo(d.recibo);
      if (d.ctrEdit || d.ctrPag || d.ctrStatus || d.ctrDel || d.ctrPublicar) await acaoContrato(d);
      if (d.chCopiar || d.chWhats || d.chSit) await acaoChamado(d);
      if (d.ajudaSec) { ev.preventDefault(); $(`#ajuda-sec-${d.ajudaSec}`)?.scrollIntoView({ behavior: 'smooth' }); }
      if (d.editTom) await editarTomador(estado.tomadores.find((x) => x.id === d.editTom));
      if (d.emitirTom) { location.hash = '#emitir'; await mostrarTela('emitir', false); limparEmissao(false); await aoEscolherTomador(estado.tomadores.find((x) => x.id === d.emitirTom).documento); }
      if (d.delTom && confirm('Excluir este tomador do cadastro?')) { await api('DELETE', `/api/tomadores/${d.delTom}`); await trocarEmpresa(estado.empresa); renderTomadores(); }
      if (d.editServ) await editarServico(estado.servicos.find((x) => x.id === d.editServ));
      if (d.delServ && confirm('Excluir este serviço favorito?')) { await api('DELETE', `/api/servicos/${d.delServ}`); await trocarEmpresa(estado.empresa); renderServicos(); }
      if (d.editEmp) await editarEmpresa(estado.empresas.find((x) => x.id === d.editEmp));
      if (d.delEmp) await excluirEmpresaUI(d.delEmp);
      if (d.restEmp) { await api('POST', `/api/empresas-excluidas/${d.restEmp}/restaurar`); toast('Empresa restaurada.'); await carregarEmpresas(); renderEmpresas(); }
    } catch (e) { falha(e); }
  });
}


// ------------------------------------------------------------------ responsivo
/** Em tela estreita as tabelas viram cartões: cada célula recebe o nome da coluna. */
function rotularTabelas() {
  for (const t of document.querySelectorAll('.tabela-wrap table')) {
    const nomes = [...t.querySelectorAll('thead th')].map((th) => th.textContent.trim());
    for (const tr of t.querySelectorAll('tbody tr')) {
      [...tr.children].forEach((td, i) => { if (!td.hasAttribute('data-rotulo')) td.setAttribute('data-rotulo', td.colSpan > 1 ? '' : (nomes[i] ?? '')); });
    }
  }
}
function ligarResponsivo() {
  const lateral = $('.lateral');
  const alternar = (abrir) => {
    lateral.classList.toggle('aberto', abrir);
    $('#btnMenu').setAttribute('aria-expanded', String(abrir));
  };
  $('#btnMenu').onclick = () => alternar(!lateral.classList.contains('aberto'));
  lateral.addEventListener('click', (ev) => { if (ev.target.closest('nav a')) alternar(false); });
  $('#seletorEmpresa').addEventListener('change', () => alternar(false));
  new MutationObserver(rotularTabelas).observe(document.querySelector('main'), { childList: true, subtree: true });
  rotularTabelas();
}
// ------------------------------------------------------------------ login
async function mostrarLogin() {
  const e = await api('GET', '/api/auth/estado');
  const cadastro = !e.temUsuarios;
  estado.modoCadastro = cadastro;
  $('#telaLogin').hidden = false;
  $('#loginTitulo').textContent = cadastro ? 'Criar sua conta' : 'Entrar';
  $('#loginSub').textContent = cadastro
    ? 'Primeiro acesso nesta instalação: crie a conta de administrador com seu e-mail e uma senha.'
    : 'Entre com seu e-mail e sua senha.';
  $('#campoNome').hidden = !cadastro;
  $('#campoSenha2').hidden = !cadastro;
  $('#lSenha').autocomplete = cadastro ? 'new-password' : 'current-password';
  $('#btnLogin').textContent = cadastro ? 'Criar conta e entrar' : 'Entrar';
  $('#erroLogin').textContent = '';
}

async function aposLogin(usuario) {
  estado.usuario = usuario;
  $('#telaLogin').hidden = true;
  $('#usuarioLateral').innerHTML = `${esc(usuario.nome)}<br><span class="mono">${esc(usuario.email)}</span><br><button type="button" id="btnSenha">Alterar senha</button> · ${usuario.papel === 'admin' ? '<button type="button" id="btnBackup">Backup</button> · ' : ''}<button type="button" id="btnSair">Sair</button>`;
  $('#btnSair').onclick = async () => { await api('POST', '/api/auth/sair'); location.reload(); };
  $('#btnSenha').onclick = alterarSenha;
  if ($('#btnBackup')) $('#btnBackup').onclick = () => abrirBackup().catch(falha);
  await carregarEmpresas();
  if (!estado.empresas.length && telaAtual() === 'emitir') location.hash = '#empresas';
  await mostrarTela(telaAtual());
}

async function enviarLogin(ev) {
  ev.preventDefault();
  const corpo = { nome: $('#lNome').value.trim(), email: $('#lEmail').value.trim(), senha: $('#lSenha').value };
  if (estado.modoCadastro && corpo.senha !== $('#lSenha2').value) { $('#erroLogin').textContent = 'As senhas não conferem.'; return; }
  await ocupado($('#btnLogin'), async () => {
    try { await aposLogin(await api('POST', estado.modoCadastro ? '/api/auth/registrar' : '/api/auth/login', corpo)); }
    catch (e) { $('#erroLogin').textContent = e.message; }
  });
}

async function alterarSenha() {
  const ok = await modal(`<h2>Alterar senha</h2>
    <div class="campo"><label>Senha atual</label><input name="atual" type="password" autocomplete="current-password" required></div>
    <div class="campo"><label>Nova senha (mín. 8)</label><input name="nova" type="password" autocomplete="new-password" required minlength="8"></div>
    ${rodapeModal('Salvar')}`, (f) => api('PUT', '/api/eu/senha', { senhaAtual: f.elements.atual.value, novaSenha: f.elements.nova.value }));
  if (ok) toast('Senha alterada.');
}

// ------------------------------------------------------------------ ajuda
const textoPuro = (html) => html.replace(/<[^>]+>/g, ' ');
function renderAjuda() {
  const termo = semAcento($('#buscaAjuda').value);
  const marca = (html) => {
    if (!termo) return html;
    return html.replace(/>([^<]+)</g, (m, txt) => {
      const base = txt.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); const i = base.indexOf(termo);
      return i < 0 ? m : `>${txt.slice(0, i)}<mark>${txt.slice(i, i + termo.length)}</mark>${txt.slice(i + termo.length)}<`;
    });
  };
  const secoes = AJUDA.map((s, si) => ({
    ...s, si,
    itens: s.itens.filter((it) => (!it.ed || it.ed.includes(tipoMenu())) && (!termo || semAcento(`${it.t} ${textoPuro(it.c)}`).includes(termo))),
  })).filter((s) => s.itens.length);
  $('#ajudaIndice').innerHTML = termo ? '' : secoes.map((s) => `<button type="button" data-ajuda-sec="${s.si}">${esc(s.secao)}</button>`).join('');
  $('#ajudaConteudo').innerHTML = secoes.length ? secoes.map((s) => `<div class="ajuda-secao" id="ajuda-sec-${s.si}"><h2>${esc(s.secao)}</h2>
    ${s.itens.map((it) => `<details class="ajuda-item" ${termo ? 'open' : ''}><summary>${esc(it.t)}</summary><div class="ajuda-texto">${marca(`>${it.c}<`).slice(1, -1)}</div></details>`).join('')}</div>`).join('')
    : `<div class="cartao"><p>Nada encontrado para “${esc($('#buscaAjuda').value)}”. Não achou? <a href="#suporte">Abra um chamado</a>.</p></div>`;
}

// ------------------------------------------------------------------ suporte (chamados)
const linkWhats = (num, texto) => `https://wa.me/${so(num).startsWith('55') ? so(num) : `55${so(num)}`}?text=${encodeURIComponent(texto)}`;
const linkEmail = (email, assunto, texto) => `mailto:${email}?subject=${encodeURIComponent(assunto)}&body=${encodeURIComponent(texto.replace(/\*/g, ''))}`;
async function renderSuporte() {
  const r = await api('GET', '/api/suporte');
  estado.suporte = r;
  const c = r.contato;
  $('#chImpacto').innerHTML = Object.entries(r.impactos).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('');
  $('#chEnviarWhats').hidden = !c?.whatsapp;
  $('#chEnviarEmail').hidden = !c?.email;
  $('#chContato').innerHTML = c?.whatsapp || c?.email
    ? `Atendimento: <b>${esc(c.nome || 'Everton Sousa Contabilidade')}</b>${c.whatsapp ? ` · WhatsApp ${esc(fmtFone(c.whatsapp))}` : ''}${c.email ? ` · ${esc(c.email)}` : ''}. O chamado fica registrado abaixo com o número de protocolo.`
    : 'O contato do suporte ainda não foi configurado pelo escritório. O chamado fica registrado aqui; use <b>Copiar texto</b> e envie ao escritório.';
  if (!c?.whatsapp && !c?.email) { $('#chEnviarWhats').hidden = false; $('#chEnviarWhats').textContent = 'Registrar e copiar texto'; }
  $('#tabChamados tbody').innerHTML = r.chamados.length ? r.chamados.map((x) => `<tr><td class="mono">${esc(x.protocolo)}</td>
    <td>${x.tipo === 'melhoria' ? 'Melhoria' : 'Inconsistência'}</td><td>${esc(x.titulo)}<span class="sub">${esc(x.tela)}</span></td>
    <td>${new Date(x.criadoEm).toLocaleString('pt-BR')}</td>
    <td><span class="selo ${x.situacao === 'resolvido' ? 'autorizada' : 'vencendo'}">${x.situacao === 'resolvido' ? 'resolvido' : 'aberto'}</span></td>
    <td class="acoes"><div class="icones">${x.print ? icoLink('ver', 'Ver o print', `/api/suporte/chamados/${x.id}/print`, 'target="_blank" rel="noopener"') : ''}${ico('modelo', 'Copiar texto do chamado', `data-ch-copiar="${x.id}"`)}${c?.whatsapp ? ico('emitir', 'Reenviar pelo WhatsApp', `data-ch-whats="${x.id}"`) : ''}${ico(x.situacao === 'resolvido' ? 'substituir' : 'reativar', x.situacao === 'resolvido' ? 'Reabrir' : 'Marcar como resolvido', `data-ch-sit="${x.id}"`)}</div></td></tr>`).join('')
    : '<tr><td colspan="6" class="vazio">Nenhum chamado aberto.</td></tr>';
}
const fmtFone = (n) => { const d = so(n).replace(/^55/, ''); return d.length === 11 ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}` : d; };
// Print do chamado: sempre convertido para PNG (é o formato que dá para colar no WhatsApp/e-mail).
async function anexarPrint(arquivo) {
  if (!arquivo || !/^image\//.test(arquivo.type)) { toast('Cole ou escolha uma imagem (print da tela).', true); return; }
  const bmp = await createImageBitmap(arquivo);
  const escala = Math.min(1, 2400 / bmp.width);
  const cv = document.createElement('canvas');
  cv.width = Math.round(bmp.width * escala); cv.height = Math.round(bmp.height * escala);
  cv.getContext('2d').drawImage(bmp, 0, 0, cv.width, cv.height);
  const blob = await new Promise((ok) => cv.toBlob(ok, 'image/png'));
  if (blob.size > 8 * 1024 * 1024) { toast('Print muito grande (máx. 8 MB).', true); return; }
  const base64 = await new Promise((ok) => { const fr = new FileReader(); fr.onload = () => ok(String(fr.result).split(',')[1]); fr.readAsDataURL(blob); });
  estado.printChamado = { blob, base64, tipo: 'image/png' };
  $('#chPrintImg').src = URL.createObjectURL(blob);
  $('#chPrintVazio').hidden = true; $('#chPrintCheio').hidden = false;
}
function limparPrint() {
  estado.printChamado = null;
  $('#chPrintVazio').hidden = false; $('#chPrintCheio').hidden = true; $('#chPrintImg').removeAttribute('src');
  $('#chPrintArquivo').value = '';
}
function ligarPrintChamado() {
  $('#tela-suporte').addEventListener('paste', (ev) => {
    const item = [...(ev.clipboardData?.items ?? [])].find((i) => i.type.startsWith('image/'));
    if (!item) return;
    ev.preventDefault();
    anexarPrint(item.getAsFile()).catch(falha);
  });
  const zona = $('#chZonaPrint');
  zona.addEventListener('dragover', (ev) => { ev.preventDefault(); zona.classList.add('arrastando'); });
  zona.addEventListener('dragleave', () => zona.classList.remove('arrastando'));
  zona.addEventListener('drop', (ev) => { ev.preventDefault(); zona.classList.remove('arrastando'); anexarPrint(ev.dataTransfer.files[0]).catch(falha); });
  $('#chPrintArquivo').onchange = (ev) => anexarPrint(ev.target.files[0]).catch(falha);
  $('#chPrintRemover').onclick = limparPrint;
  const ajustar = () => {
    const inc = $('input[name=tipoChamado]:checked').value === 'inconsistencia';
    $('#chPrintRotulo').textContent = inc ? 'Print da tela com o erro *' : 'Print da tela (opcional)';
  };
  $$('input[name=tipoChamado]').forEach((r) => r.addEventListener('change', ajustar));
  ajustar();
}
const copiarImagem = (blobOuPromessa) => navigator.clipboard?.write?.([new ClipboardItem({ 'image/png': blobOuPromessa })]);

async function enviarChamado(meio) {
  const tipoCh = $('input[name=tipoChamado]:checked').value;
  if (tipoCh === 'inconsistencia' && !estado.printChamado) { toast('Anexe o print da tela com o erro: tire com Windows + Shift + S e cole aqui (Ctrl+V).', true); $('#chZonaPrint').focus(); return; }
  if (tipoCh === 'inconsistencia' && $('#chDescricao').value.trim().length < 30) { toast('Descreva o erro com pelo menos 30 caracteres: o que fez, o que esperava e o que aconteceu.', true); $('#chDescricao').focus(); return; }
  // copia o print agora (ainda dentro do clique) para colar na conversa
  let printCopiado = false;
  if (estado.printChamado && (meio === 'whats' || meio === 'email')) {
    try { await copiarImagem(estado.printChamado.blob); printCopiado = true; } catch { /* sem permissão: o print fica salvo no chamado */ }
  }
  const corpo = {
    print: estado.printChamado ? { tipo: estado.printChamado.tipo, base64: estado.printChamado.base64 } : undefined,
    tipo: $('input[name=tipoChamado]:checked').value, titulo: $('#chTitulo').value, descricao: $('#chDescricao').value,
    tela: $('#chTela').value, impacto: $('#chImpacto').value, semDiagnostico: !$('#chDiagnostico').checked, empresaId: estado.empresa?.id,
  };
  // abre a janela antes da chamada (bloqueio de pop-up) e define o endereço depois
  const c = estado.suporte?.contato;
  const janela = meio === 'whats' && c?.whatsapp ? window.open('about:blank', '_blank') : null;
  try {
    const r = await api('POST', '/api/suporte/chamados', corpo);
    const assunto = `[${r.protocolo}] ${r.titulo}`;
    if (meio === 'whats' && c?.whatsapp) janela.location = linkWhats(c.whatsapp, r.texto);
    else if (meio === 'email' && c?.email) location.href = linkEmail(c.email, assunto, r.texto);
    else { await navigator.clipboard?.writeText(r.texto).catch(() => {}); }
    toast(`Chamado ${r.protocolo} registrado.${printCopiado ? ' O print foi copiado: na conversa, cole com Ctrl+V antes de enviar.' : ''}${!c?.whatsapp && !c?.email ? ' Texto copiado: cole na mensagem ao escritório.' : ''}`);
    $('#chTitulo').value = ''; $('#chDescricao').value = ''; limparPrint();
    await renderSuporte();
  } catch (e) { janela?.close(); falha(e); }
}
async function acaoChamado(d) {
  const id = d.chCopiar ?? d.chWhats ?? d.chSit;
  if (d.chSit) {
    const x = estado.suporte.chamados.find((c) => c.id === id);
    await api('PUT', `/api/suporte/chamados/${id}`, { situacao: x.situacao === 'resolvido' ? 'aberto' : 'resolvido' });
    return renderSuporte();
  }
  const ch = estado.suporte.chamados.find((c) => c.id === id);
  if (d.chWhats && ch?.print) {
    try { await copiarImagem(fetch(`/api/suporte/chamados/${id}/print`).then((r) => r.blob())); toast('Print copiado: na conversa, cole com Ctrl+V.'); } catch { /* segue só com o texto */ }
  }
  const { texto } = await api('GET', `/api/suporte/chamados/${id}/texto`);
  if (d.chWhats) return window.open(linkWhats(estado.suporte.contato.whatsapp, texto), '_blank');
  try { await navigator.clipboard.writeText(texto); toast('Texto do chamado copiado.'); } catch { toast('Não foi possível copiar automaticamente.', true); }
}
async function contatoNoBloqueio() {
  try {
    const { contato: c } = await api('GET', '/api/suporte');
    $('#bloqueioContato').innerHTML = c?.whatsapp || c?.email
      ? `${c.whatsapp ? `<a href="${linkWhats(c.whatsapp, `Olá! Preciso liberar o ES NFS-e para o CNPJ ${docFmt(estado.empresa?.cnpj)}.`)}" target="_blank">WhatsApp ${esc(fmtFone(c.whatsapp))}</a>` : ''}${c.whatsapp && c.email ? ' · ' : ''}${c.email ? esc(c.email) : ''}` : '';
  } catch { /* sem contato */ }
}

// ------------------------------------------------------------------ liberação de acesso
const SITUACAO_LIC = { liberado: 'liberado', vencendo: 'vence em breve', vencido: 'vencido', bloqueado: 'bloqueado', nao_liberado: 'não liberado', sem_verificacao: 'sem verificação' };
function aplicarLicenca() {
  const s = estado.empresa?.licenca;
  estado.bloqueado = Boolean(s?.bloqueia);
  $('#faixaLicenca').hidden = s?.status !== 'vencendo';
  if (s?.status === 'vencendo') $('#faixaLicenca').textContent = `⚠ ${s.mensagem} Fale com o escritório para renovar.`;
  if (estado.bloqueado) {
    $('#bloqueioMsg').textContent = s.mensagem;
    $('#bloqueioCnpj').textContent = docFmt(estado.empresa.cnpj);
    contatoNoBloqueio();
  }
  $$('nav a').forEach((link) => link.classList.toggle('travado', estado.bloqueado && !TELAS_LIVRES.includes(link.dataset.tela)));
  if (estado.usuario) mostrarTela(telaAtual(), false);
}
async function verificarLicencaAgora() {
  await ocupado($('#btnVerificarLicenca'), async () => {
    const r = await api('POST', '/api/licencas/verificar');
    await carregarEmpresas();
    if (!r.ok) toast(`Não foi possível consultar a liberação (${r.erro}). Confira a internet.`, true);
    else if (estado.bloqueado) toast('Esta empresa ainda não está liberada. Se acabou de ser liberada, aguarde alguns minutos e tente de novo.', true);
    else { toast('Acesso liberado.'); await mostrarTela(telaAtual()); }
  });
}

// --- painel do administrador
const somaDias = (iso, dias) => { const d = new Date(`${iso}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + dias); return d.toISOString().slice(0, 10); };
const somaMeses = (iso, meses) => { const d = new Date(`${iso}T12:00:00Z`); d.setUTCMonth(d.getUTCMonth() + meses); return d.toISOString().slice(0, 10); };
async function renderLicencas() {
  const r = await api('GET', '/api/admin/licencas');
  estado.licencas = r.lista;
  estado.hojeLic = r.hoje;
  if (document.activeElement?.closest?.('#ctWhats, #ctEmail, #ctNome') == null) {
    $('#ctWhats').value = r.contato?.whatsapp ? fmtFone(r.contato.whatsapp) : '';
    $('#ctEmail').value = r.contato?.email ?? ''; $('#ctNome').value = r.contato?.nome ?? '';
  }
  const el = $('#licEstado');
  el.className = r.pendente ? 'pendente' : 'dica';
  el.textContent = r.ultimoErro ? `Última publicação falhou: ${r.ultimoErro}`
    : r.pendente ? 'Há alterações ainda não publicadas — clique em Publicar para valerem nos clientes.'
      : r.publicadoEm ? `Publicado em ${new Date(r.publicadoEm).toLocaleString('pt-BR')}. Os clientes recebem em até alguns minutos.` : 'Nada publicado ainda.';
  $('#licPublicar').textContent = r.pendente ? 'Publicar alterações' : 'Publicar';
  $('#tabLicencas tbody').innerHTML = r.lista.length ? r.lista.map((x) => {
    const dias = Math.round((new Date(`${x.ate}T12:00:00Z`) - new Date(`${r.hoje}T12:00:00Z`)) / 86400000);
    const sit = x.bloqueado ? ['bloqueado', 'rejeitada'] : dias < 0 ? ['vencido', 'rejeitada'] : dias <= 5 ? [`vence em ${dias} dia${dias === 1 ? '' : 's'}`, 'vencendo'] : ['liberado', 'autorizada'];
    return `<tr><td>${esc(x.nome || '—')}</td><td class="mono">${docFmt(x.cnpj)}</td><td>${x.perfil === 'contador' ? `Contador<span class="sub">até ${x.limite} cliente(s)</span>` : 'Cliente'}</td><td>${dataBr(`${x.ate}T12:00`)}</td>
      <td><span class="selo ${sit[1]}">${sit[0]}</span></td><td>${esc(x.obs)}</td>
      <td class="acoes"><div class="icones">${ico('editar', 'Editar', `data-lic-edit="${x.cnpj}"`)}${ico('calendario', '+1 mês (a partir do vencimento ou de hoje)', `data-lic-mes="${x.cnpj}"`)}${x.bloqueado ? ico('reativar', 'Desbloquear', `data-lic-bloq="${x.cnpj}"`) : ico('desativar', 'Bloquear', `data-lic-bloq="${x.cnpj}"`, 'perigo')}${ico('excluir', 'Remover da lista', `data-lic-del="${x.cnpj}"`, 'perigo')}</div></td></tr>`;
  }).join('') : '<tr><td colspan="7" class="vazio">Nenhuma empresa liberada ainda. Use "Adicionar empresas deste computador" ou "Nova liberação".</td></tr>';
}
async function editarLicenca(x) {
  const hj = estado.hojeLic ?? hoje();
  const ok = await modal(`<h2>${x?.cnpj ? 'Editar liberação' : 'Nova liberação'}</h2>
    <div class="linha"><div class="campo"><label>CNPJ ou CPF *</label><input name="cnpj" class="mono" required value="${esc(x?.cnpj ? docFmt(x.cnpj) : '')}" ${x?.cnpj ? 'readonly' : ''}></div>
    <div class="campo grande"><label>Empresa</label><input name="nome" value="${esc(x?.nome ?? '')}"></div></div>
    <div class="linha"><div class="campo grande"><label>Versão</label><select name="perfil"><option value="cliente" ${x?.perfil !== 'contador' ? 'selected' : ''}>Cliente — emite só para este CNPJ</option><option value="contador" ${x?.perfil === 'contador' ? 'selected' : ''}>Contador — este CNPJ é o escritório e emite para clientes</option></select></div>
    <div class="campo pequeno" data-limite><label>Limite de clientes</label><input name="limite" type="number" min="0" max="9999" value="${esc(x?.limite ?? 10)}"></div></div>
    <div class="linha"><div class="campo"><label>Liberado até *</label><input type="date" name="ate" required value="${esc(x?.ate ?? somaMeses(hj, 1))}"></div>
    <div class="campo grande"><label>Atalhos</label><div class="acoes-linha" style="margin:0">
      <button type="button" class="btn mini sec" data-prazo="1">+1 mês</button><button type="button" class="btn mini sec" data-prazo="3">+3 meses</button>
      <button type="button" class="btn mini sec" data-prazo="6">+6 meses</button><button type="button" class="btn mini sec" data-prazo="12">+1 ano</button></div></div></div>
    <label class="check"><input type="checkbox" name="bloqueado" ${x?.bloqueado ? 'checked' : ''}> Bloqueado (trava o acesso mesmo dentro do prazo)</label>
    <div class="campo"><label>Observação</label><input name="obs" value="${esc(x?.obs ?? '')}" placeholder="ex.: mensalidade paga até…"></div>
    ${rodapeModal('Salvar')}`, (f) => api('POST', '/api/admin/licencas', { cnpj: so(f.elements.cnpj.value), nome: valorCampo(f, 'nome'), ate: f.elements.ate.value, bloqueado: f.elements.bloqueado.checked, obs: valorCampo(f, 'obs'), perfil: f.elements.perfil.value, limite: f.elements.limite.value }));
  // (os atalhos são ligados logo abaixo, antes do await terminar)
  if (ok) { toast('Salvo. Clique em Publicar para valer nos clientes.'); await renderLicencas(); }
}
function ligarAtalhosPrazo() {
  const f = $('#formModal');
  const lim = () => { f.querySelector('[data-limite]').hidden = f.elements.perfil.value !== 'contador'; };
  f.elements.perfil.addEventListener('change', lim); lim();
  f.querySelectorAll('[data-prazo]').forEach((b) => {
    b.onclick = () => {
      const base = f.elements.ate.value && f.elements.ate.value > (estado.hojeLic ?? hoje()) ? f.elements.ate.value : (estado.hojeLic ?? hoje());
      f.elements.ate.value = somaMeses(base, Number(b.dataset.prazo));
    };
  });
  const doc = f.elements.cnpj;
  if (!doc.readOnly) {
    doc.addEventListener('blur', async () => {
      const d = so(doc.value);
      if (d.length !== 14 || f.elements.nome.value) return;
      try { const r = await consultarCnpj(d); if (r?.razaoSocial) f.elements.nome.value = r.razaoSocial; } catch { /* sem consulta */ }
    });
  }
}
async function acaoLicenca(d) {
  const x = estado.licencas.find((l) => l.cnpj === (d.licEdit ?? d.licMes ?? d.licBloq ?? d.licDel));
  if (!x) return;
  if (d.licEdit) { const p = editarLicenca(x); ligarAtalhosPrazo(); await p; return; }
  if (d.licDel) {
    if (!confirm(`Remover ${x.nome || docFmt(x.cnpj)} da lista? Depois de publicar, o acesso dessa empresa fica travado.`)) return;
    await api('DELETE', `/api/admin/licencas/${x.cnpj}`);
  }
  if (d.licMes) {
    const base = x.ate > estado.hojeLic ? x.ate : estado.hojeLic;
    await api('POST', '/api/admin/licencas', { ...x, ate: somaMeses(base, 1) });
  }
  if (d.licBloq) await api('POST', '/api/admin/licencas', { ...x, bloqueado: !x.bloqueado });
  toast('Salvo. Clique em Publicar para valer nos clientes.');
  await renderLicencas();
}
async function licencasDestaMaquina() {
  const ja = new Set((estado.licencas ?? []).map((l) => l.cnpj));
  const novas = estado.empresas.filter((e) => !ja.has(so(e.cnpj)));
  if (!novas.length) return toast('Todas as empresas deste computador já estão na lista.');
  const ate = somaMeses(estado.hojeLic ?? hoje(), 12);
  for (const e of novas) await api('POST', '/api/admin/licencas', { cnpj: so(e.cnpj), nome: e.razaoSocial, ate, obs: 'adicionada deste computador' });
  toast(`${novas.length} empresa(s) adicionada(s), liberadas por 1 ano. Revise e publique.`);
  await renderLicencas();
}
async function publicarLicencas() {
  await ocupado($('#licPublicar'), async () => {
    try {
      const r = await api('POST', '/api/admin/licencas/publicar');
      toast(`Lista publicada: ${r.total} empresa(s). Os clientes recebem em alguns minutos.`);
    } catch (e) { falha(e); }
    await renderLicencas();
  });
}

// ------------------------------------------------------------------ contratos (administrador)
const dBr = (iso) => (iso ? iso.slice(0, 10).split('-').reverse().join('/') : '—');
const compBr = (c) => c.split('-').reverse().join('/');
const STATUS_CTR = { ativo: ['ativo', 'autorizada'], suspenso: ['suspenso', 'vencendo'], encerrado: ['encerrado', 'rejeitada'] };
async function renderContratos() {
  const r = await api('GET', '/api/admin/contratos');
  estado.contratos = r;
  const s = r.resumo;
  $('#ctrResumo').innerHTML = [
    ['Contratos ativos', String(s.ativos)], ['Receita mensal', moeda(s.mrr)], ['A receber neste mês', moeda(s.aReceber)],
    ['Em atraso', moeda(s.atrasado)], ['Recebido no mês', moeda(s.recebidoMes)],
  ].map(([t, v], i) => `<div class="stat${i === 3 && s.atrasado ? ' alerta' : ''}"><span>${t}</span><b>${v}</b></div>`).join('');
  const p = r.publicacao;
  $('#ctrEstado').className = p.pendente ? 'pendente' : 'dica';
  $('#ctrEstado').innerHTML = p.pendente ? 'Há mudanças de licença ainda não publicadas. <button type="button" class="btn mini pri" data-ctr-publicar="1">Publicar licenças</button>'
    : `Licenças publicadas${p.publicadoEm ? ` em ${new Date(p.publicadoEm).toLocaleString('pt-BR')}` : ''}.`;
  const nomePlano = (c) => (c.plano === 'consulta' ? `Sob consulta · ${c.empresas} empresas` : r.planos.find((x) => x.id === c.plano)?.nome ?? c.plano);
  $('#tabContratos tbody').innerHTML = r.lista.length ? r.lista.map((c) => {
    const st = c.situacao;
    const fin = c.status !== 'ativo' ? '<span class="sub">—</span>'
      : st.atrasadas ? `<span class="selo rejeitada">${st.atrasadas} em atraso</span><span class="sub">${moeda(st.valorAtrasado)}</span>`
        : `<span class="selo autorizada">em dia</span>${st.proxima ? `<span class="sub">próx. ${dBr(st.proxima.vencimento)}</span>` : ''}`;
    const [stTxt, stCls] = STATUS_CTR[c.status];
    return `<tr><td class="mono">${esc(c.numero)}<span class="sub">desde ${dBr(c.inicio)}</span></td>
      <td>${esc(c.razaoSocial)}<span class="sub mono">${docFmt(c.cnpj)}</span></td>
      <td>${c.perfil === 'contador' ? 'Contador' : 'Cliente'}<span class="sub">${esc(nomePlano(c))}</span></td>
      <td class="num">${moeda(c.valorMensal)}<span class="sub">dia ${c.diaVencimento}</span></td>
      <td>${fin}${st.implantacaoPendente ? '<span class="sub">implantação a receber</span>' : ''}</td>
      <td>${dBr(st.liberadoAte)}${c.status === 'ativo' && st.licencaVencida ? ' <span class="selo rejeitada">travada</span>' : ''}</td>
      <td><span class="selo ${stCls}">${stTxt}</span></td>
      <td class="acoes"><div class="icones">${ico('calendario', 'Mensalidades e pagamentos', `data-ctr-pag="${c.id}"`)}${icoLink('baixar', 'Contrato em PDF', `/api/admin/contratos/${c.id}/pdf`, 'target="_blank" rel="noopener"')}${ico('editar', 'Editar contrato', `data-ctr-edit="${c.id}"`)}${c.status === 'ativo' ? ico('desativar', 'Suspender (bloqueia o acesso)', `data-ctr-status="${c.id}" data-novo="suspenso"`, 'perigo') : ico('reativar', 'Reativar', `data-ctr-status="${c.id}" data-novo="ativo"`)}${c.status !== 'encerrado' ? ico('cancelar', 'Encerrar contrato', `data-ctr-status="${c.id}" data-novo="encerrado"`, 'perigo') : ''}${!c.pagamentos.length && !c.implantacaoPagaEm ? ico('excluir', 'Excluir contrato', `data-ctr-del="${c.id}"`, 'perigo') : ''}</div></td></tr>`;
  }).join('') : '<tr><td colspan="8" class="vazio">Nenhum contrato ainda. Clique em "Novo contrato".</td></tr>';
}

async function editarContrato(c) {
  const r = estado.contratos ?? await api('GET', '/api/admin/contratos');
  const hj = r.hoje;
  const v = (k, p = '') => esc(c?.[k] ?? p);
  const opt = (val, rot, atual) => `<option value="${val}" ${String(atual) === String(val) ? 'selected' : ''}>${rot}</option>`;
  const aberto = modal(`<h2>${c ? `Editar contrato ${esc(c.numero)}` : 'Novo contrato'}</h2>
    <fieldset class="sub-cartao"><legend>Contratante</legend>
    <div class="linha"><div class="campo"><label>CNPJ ou CPF *</label><input name="cnpj" class="mono" required value="${c ? docFmt(c.cnpj) : ''}" ${c ? 'readonly' : ''}></div>
    <div class="campo grande"><label>Nome / razão social *</label><input name="razaoSocial" required value="${v('razaoSocial')}"></div></div>
    <div class="linha"><div class="campo grande"><label>Endereço</label><input name="endereco" value="${v('endereco')}"></div><div class="campo"><label>Cidade/UF</label><input name="cidade" value="${v('cidade')}"></div></div>
    <div class="linha"><div class="campo grande"><label>Representante legal</label><input name="representante" value="${v('representante')}"></div><div class="campo"><label>CPF do sócio administrador</label><input name="cpfRepresentante" class="mono" value="${c?.cpfRepresentante ? docFmt(c.cpfRepresentante) : ''}"></div></div>
    <div class="linha"><div class="campo grande"><label>E-mail</label><input name="email" type="email" value="${v('email')}"></div><div class="campo"><label>WhatsApp</label><input name="whatsapp" class="mono" value="${c?.whatsapp ? fmtFone(c.whatsapp) : ''}"></div></div>
    </fieldset>
    <fieldset class="sub-cartao"><legend>Plano e cobrança</legend>
    <div class="linha"><div class="campo"><label>Versão</label><select name="perfil">${opt('cliente', 'Cliente (só o próprio CNPJ)', c?.perfil ?? 'contador')}${opt('contador', 'Contador (escritório + clientes)', c?.perfil ?? 'contador')}</select></div>
    <div class="campo grande"><label>Plano *</label><select name="plano">${r.planos.map((p) => opt(p.id, `${p.nome}${p.mensal ? ` — ${moeda(p.mensal)}/mês` : ''}`, c?.plano ?? 'ate5')).join('')}</select></div>
    <div class="campo pequeno" data-qtd><label>Empresas</label><input name="empresas" type="number" min="101" value="${v('empresas', 150)}"></div></div>
    <div class="linha"><div class="campo"><label>Mensalidade (R$) *</label><input name="valorMensal" class="mono" value="${v('valorMensal', 57)}"></div>
    <div class="campo"><label>Implantação (R$)</label><input name="valorImplantacao" class="mono" value="${v('valorImplantacao', r.implantacao)}"></div>
    <div class="campo pequeno"><label>Dia do vencimento</label><input name="diaVencimento" type="number" min="1" max="28" value="${v('diaVencimento', 10)}"></div>
    <div class="campo pequeno"><label>Carência (dias)</label><input name="carencia" type="number" min="0" max="30" value="${v('carencia', 5)}"></div></div>
    <div class="linha"><div class="campo"><label>Início *</label><input name="inicio" type="date" required value="${v('inicio', hj)}"></div>
    <div class="campo"><label>1º vencimento</label><input name="primeiroVencimento" type="date" value="${v('primeiroVencimento')}"></div>
    <div class="campo pequeno"><label>Prazo (meses)</label><input name="prazoMeses" type="number" min="1" max="60" value="${v('prazoMeses', 12)}"></div></div>
    <p class="dica" id="dicaPlano"></p>
    <div class="campo"><label>Observações (saem no contrato)</label><input name="obs" value="${v('obs')}"></div>
    </fieldset>
    ${rodapeModal(c ? 'Salvar' : 'Criar contrato')}`, (f) => {
    const g = (n) => valorCampo(f, n);
    const corpo = { cnpj: so(g('cnpj')), razaoSocial: g('razaoSocial'), endereco: g('endereco'), cidade: g('cidade'), representante: g('representante'), cpfRepresentante: so(g('cpfRepresentante')),
      email: g('email'), whatsapp: so(g('whatsapp')), perfil: g('perfil'), plano: g('plano'), empresas: g('empresas'), valorMensal: g('valorMensal').replace(',', '.'),
      valorImplantacao: g('valorImplantacao').replace(',', '.'), diaVencimento: g('diaVencimento'), carencia: g('carencia'), inicio: g('inicio'), primeiroVencimento: g('primeiroVencimento'), prazoMeses: g('prazoMeses'), obs: g('obs') };
    if (corpo.whatsapp && corpo.whatsapp.length <= 11) corpo.whatsapp = `55${corpo.whatsapp}`;
    return c ? api('PUT', `/api/admin/contratos/${c.id}`, corpo) : api('POST', '/api/admin/contratos', corpo);
  });
  const f = $('#formModal');
  const atualizarPlano = (trocouPlano) => {
    const p = r.planos.find((x) => x.id === f.elements.plano.value);
    f.querySelector('[data-qtd]').hidden = Boolean(p.empresas);
    if (trocouPlano && p.mensal) f.elements.valorMensal.value = p.mensal;
    const n = p.empresas ?? (Number(f.elements.empresas.value) || 0);
    $('#dicaPlano').textContent = f.elements.perfil.value === 'contador'
      ? `Licença Contador: até ${n} empresas emitentes (o escritório + ${Math.max(1, n - 1)} clientes).`
      : 'Licença Cliente: emite só para o CNPJ/CPF do contratante.';
  };
  f.elements.plano.onchange = () => atualizarPlano(true);
  f.elements.perfil.onchange = () => atualizarPlano(false);
  f.elements.empresas.oninput = () => atualizarPlano(false);
  atualizarPlano(false);
  if (!c) {
    f.elements.cnpj.onblur = async () => {
      try {
        const d = await consultarCnpj(f.elements.cnpj.value);
        if (!d) return;
        if (!f.elements.razaoSocial.value) f.elements.razaoSocial.value = d.razaoSocial;
        const e = d.endereco;
        if (e && !f.elements.endereco.value) f.elements.endereco.value = [`${e.logradouro}, ${e.numero}`, e.complemento, e.bairro, e.cep && `CEP ${e.cep.replace(/^(\d{5})(\d{3})$/, '$1-$2')}`].filter(Boolean).join(' - ');
        if (!f.elements.cidade.value) f.elements.cidade.value = d.municipio;
        if (!f.elements.email.value) f.elements.email.value = d.email;
      } catch (e) { toast(e.message, true); }
    };
  }
  const ok = await aberto;
  if (ok) { toast(c ? 'Contrato salvo.' : `Contrato ${ok.numero} criado. A licença já foi preparada: publique para valer.`); await renderContratos(); }
}

async function editarContratada() {
  const r = estado.contratos ?? await api('GET', '/api/admin/contratos');
  const c = r.contratada;
  const ok = await modal(`<h2>Dados da contratada</h2><p class="dica">Aparecem no contrato em PDF.</p>
    <div class="linha"><div class="campo grande"><label>Razão social / nome *</label><input name="razaoSocial" required value="${esc(c.razaoSocial)}"></div><div class="campo"><label>CNPJ ou CPF</label><input name="cnpj" class="mono" value="${c.cnpj ? docFmt(c.cnpj) : ''}"></div></div>
    <div class="linha"><div class="campo grande"><label>Endereço</label><input name="endereco" value="${esc(c.endereco)}"></div><div class="campo"><label>Cidade/UF (foro)</label><input name="cidade" value="${esc(c.cidade)}"></div></div>
    <div class="linha"><div class="campo grande"><label>Representante</label><input name="representante" value="${esc(c.representante)}"></div><div class="campo grande"><label>Qualificação</label><input name="qualificacao" value="${esc(c.qualificacao)}"></div></div>
    <div class="linha"><div class="campo grande"><label>E-mail</label><input name="email" value="${esc(c.email)}"></div><div class="campo"><label>WhatsApp</label><input name="whatsapp" class="mono" value="${c.whatsapp ? fmtFone(c.whatsapp) : ''}"></div></div>
    ${rodapeModal('Salvar')}`, (f) => {
    const w = so(valorCampo(f, 'whatsapp'));
    return api('PUT', '/api/admin/contratada', { razaoSocial: valorCampo(f, 'razaoSocial'), cnpj: valorCampo(f, 'cnpj'), endereco: valorCampo(f, 'endereco'), cidade: valorCampo(f, 'cidade'),
      representante: valorCampo(f, 'representante'), qualificacao: valorCampo(f, 'qualificacao'), email: valorCampo(f, 'email'), whatsapp: w && w.length <= 11 ? `55${w}` : w });
  });
  if (ok) { toast('Dados da contratada salvos.'); await renderContratos(); }
}

async function pagamentosContrato(id) {
  await renderContratos();
  const c = estado.contratos.lista.find((x) => x.id === id);
  if (!c) return;
  const hj = estado.contratos.hoje;
  const linhas = c.parcelas.map((p) => `<tr><td>${compBr(p.competencia)}</td><td>${dBr(p.vencimento)}</td><td class="num">${moeda(p.valor)}</td>
    <td>${p.pago ? `<span class="selo autorizada">pago ${dBr(p.pagoEm)}</span>${p.forma ? `<span class="sub">${esc(p.forma)}</span>` : ''}` : p.atrasada ? '<span class="selo rejeitada">em atraso</span>' : '<span class="selo amb">a vencer</span>'}</td>
    <td>${p.pago ? `<button type="button" class="btn mini sec" data-estornar="${p.competencia}">Estornar</button>` : `<button type="button" class="btn mini pri" data-pagar="${p.competencia}">Registrar pagamento</button>`}</td></tr>`).join('');
  const impl = Number(c.valorImplantacao) > 0 ? `<tr><td>Implantação</td><td>—</td><td class="num">${moeda(c.valorImplantacao)}</td>
    <td>${c.implantacaoPagaEm ? `<span class="selo autorizada">pago ${dBr(c.implantacaoPagaEm)}</span>` : '<span class="selo vencendo">a receber</span>'}</td>
    <td>${c.implantacaoPagaEm ? '<button type="button" class="btn mini sec" data-estornar="implantacao">Estornar</button>' : '<button type="button" class="btn mini pri" data-pagar="implantacao">Registrar pagamento</button>'}</td></tr>` : '';
  const aberto = modal(`<h2>${esc(c.razaoSocial)} · ${esc(c.numero)}</h2>
    <p class="dica">Licença liberada até <b>${dBr(c.situacao.liberadoAte)}</b>. Cada mensalidade paga em sequência libera até o vencimento seguinte + ${c.carencia} dia(s).</p>
    <div class="linha"><div class="campo"><label>Data do pagamento</label><input name="pagoEm" type="date" value="${hj}"></div>
    <div class="campo"><label>Forma</label><select name="forma"><option>PIX</option><option>Boleto</option><option>Transferência</option><option>Cartão</option><option>Dinheiro</option></select></div></div>
    <div class="tabela-wrap"><table><thead><tr><th>Competência</th><th>Vencimento</th><th>Valor</th><th>Situação</th><th></th></tr></thead><tbody>${impl}${linhas}</tbody></table></div>
    <div class="rodape"><button class="btn sec" value="cancelar" formnovalidate>Fechar</button></div>`);
  const f = $('#formModal');
  f.onclick = async (ev) => {
    const b = ev.target.closest('button[data-pagar], button[data-estornar]');
    if (!b) return;
    ev.preventDefault();
    try {
      if (b.dataset.pagar) await api('POST', `/api/admin/contratos/${c.id}/pagamentos`, { competencia: b.dataset.pagar, pagoEm: f.elements.pagoEm.value, forma: f.elements.forma.value });
      else if (confirm('Estornar este pagamento? A liberação da licença volta a ser calculada.')) await api('DELETE', `/api/admin/contratos/${c.id}/pagamentos/${b.dataset.estornar}`);
      else return;
      $('#modal').close();
      toast('Pagamento atualizado. Publique as licenças para valer.');
      await pagamentosContrato(c.id);
    } catch (e) { falha(e); }
  };
  await aberto;
  await renderContratos();
}

async function acaoContrato(d) {
  if (d.ctrPublicar) {
    try { const r = await api('POST', '/api/admin/licencas/publicar'); toast(`Licenças publicadas: ${r.total} empresa(s).`); } catch (e) { falha(e); }
    return renderContratos();
  }
  const c = estado.contratos?.lista.find((x) => x.id === (d.ctrEdit ?? d.ctrPag ?? d.ctrStatus ?? d.ctrDel));
  if (!c) return;
  if (d.ctrEdit) return editarContrato(c);
  if (d.ctrPag) return pagamentosContrato(c.id);
  if (d.ctrStatus) {
    const msg = { suspenso: `Suspender ${c.razaoSocial}? O acesso fica bloqueado depois de publicar.`, encerrado: `Encerrar o contrato ${c.numero}? A licença fica bloqueada e não há mais cobrança.`, ativo: `Reativar ${c.razaoSocial}?` }[d.novo];
    if (!confirm(msg)) return;
    await api('POST', `/api/admin/contratos/${c.id}/status`, { status: d.novo });
    toast('Situação alterada. Publique as licenças para valer.');
  }
  if (d.ctrDel) {
    if (!confirm(`Excluir o contrato ${c.numero}? A liberação na tela Licenças continua até você remover.`)) return;
    await api('DELETE', `/api/admin/contratos/${c.id}`);
  }
  await renderContratos();
}

// ------------------------------------------------------------------ recibo assinado
const FORMAS_PAG = ['PIX', 'Dinheiro', 'Transferência bancária', 'Cartão de crédito', 'Cartão de débito', 'Boleto', 'Cheque'];
async function gerarRecibo(id) {
  const [p, nota] = await Promise.all([api('GET', `/api/notas/${id}/recibo`), api('GET', `/api/notas/${id}`)]);
  const aviso = p.temCertificado
    ? `Será assinado digitalmente com o certificado A1 de <b>${esc(p.titular ?? '')}</b> (ICP-Brasil).`
    : '<b>Esta empresa não tem certificado A1 próprio cadastrado:</b> o recibo sairá sem assinatura digital.';
  const aberto = modal(`<h2>Recibo da NFS-e nº ${esc(nota.numero ?? '')}</h2>
    <p class="dica">${aviso} O recibo cita o número e a chave de acesso da nota e traz o QR Code de consulta.</p>
    <div class="linha"><div class="campo"><label>Valor recebido (R$) *</label><input name="valor" class="mono" required value="${String(p.valor.toFixed(2)).replace('.', ',')}"></div>
    <div class="campo"><label>Forma de pagamento</label><select name="forma">${FORMAS_PAG.map((f) => `<option ${f === p.forma ? 'selected' : ''}>${f}</option>`).join('')}</select></div>
    <div class="campo"><label>Data do pagamento</label><input name="dataPagamento" type="date" value="${p.dataPagamento}"></div></div>
    <div class="campo"><label>Referente a *</label><textarea name="referente" rows="3" maxlength="600" required>${esc(p.referente)}</textarea></div>
    <div class="linha"><div class="campo grande"><label>Quem assina (nome no recibo)</label><input name="assinante" value="${esc(p.assinante)}"></div>
    <div class="campo grande"><label>Registro profissional (opcional)</label><input name="registro" placeholder="Ex.: Psicóloga CRP 13/12345" value="${esc(p.registro)}"></div></div>
    <div class="campo"><label>Endereço da empresa * <small>(exigido pela Receita para dedução no IR)</small></label><input name="endereco" required maxlength="200" placeholder="Rua, número - bairro - CEP" value="${esc(p.endereco)}"></div>
    <div class="linha"><div class="campo grande"><label>Sócio administrador (opcional)</label><input name="representante" placeholder="Nome do sócio administrador" value="${esc(p.representante)}"></div>
    <div class="campo"><label>CPF do representante</label><input name="cpfRepresentante" class="mono" value="${p.cpfRepresentante ? docFmt(p.cpfRepresentante) : ''}"></div>
    <label class="check" style="align-self:flex-end;margin-bottom:12px"><input type="checkbox" name="cpfCompleto" ${p.cpfCompleto ? 'checked' : ''}> CPF completo no recibo</label></div>
    <div class="linha"><div class="campo"><label>Cidade</label><input name="cidade" value="${esc(p.cidade)}"></div>
    <div class="campo"><label>Data do recibo</label><input name="dataEmissao" type="date" value="${p.dataEmissao}"></div>
    <div class="campo grande"><label>Observação (opcional)</label><input name="obs" maxlength="300" value="${esc(p.obs)}"></div></div>
    ${rodapeModal(p.temCertificado ? 'Gerar recibo assinado' : 'Gerar recibo')}`, async (f) => {
    const corpo = Object.fromEntries(['valor', 'forma', 'dataPagamento', 'referente', 'assinante', 'registro', 'cidade', 'dataEmissao', 'obs', 'endereco', 'representante', 'cpfRepresentante'].map((k) => [k, valorCampo(f, k)]));
    corpo.cpfCompleto = f.elements.cpfCompleto.checked;
    const resp = await fetch(`/api/notas/${id}/recibo`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(corpo) });
    if (!resp.ok) { const e = await resp.json().catch(() => ({})); throw new Error(e.erro || 'Não foi possível gerar o recibo.'); }
    return { blob: await resp.blob(), assinado: resp.headers.get('X-Recibo-Assinado') === '1' };
  });
  const r = await aberto;
  if (!r) return;
  const url = URL.createObjectURL(r.blob);
  const a = document.createElement('a');
  a.href = url; a.download = `Recibo-NFSe-${nota.numero ?? id}.pdf`; document.body.append(a); a.click(); a.remove();
  window.open(url, '_blank');
  toast(r.assinado ? 'Recibo assinado digitalmente gerado e baixado.' : 'Recibo gerado (sem assinatura digital) e baixado.');
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  await carregarHistorico();
}

// ------------------------------------------------------------------ backup
const tamanhoTxt = (b) => (b >= 1048576 ? `${(b / 1048576).toFixed(1).replace('.', ',')} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);
async function abrirBackup() {
  const r = await api('GET', '/api/backup');
  const linhas = r.lista.slice(0, 12).map((b) => `<tr><td>${new Date(b.criadoEm).toLocaleString('pt-BR')}</td><td>${esc(b.tipo)}</td><td class="num">${tamanhoTxt(b.tamanho)}</td>
    <td class="acoes"><div class="icones">${icoLink('baixar', 'Baixar este backup', `/api/backup/arquivos/${encodeURIComponent(b.nome)}`, 'download')}</div></td></tr>`).join('');
  modal(`<h2>Backup</h2>
    <p class="dica">O backup guarda tudo deste computador: empresas, certificados, notas, XML, tomadores, serviços e configurações. O sistema faz um <b>backup automático por semana</b> (guarda os 8 últimos) em <span class="mono">${esc(r.pasta)}</span>. Guarde também uma cópia <b>fora do computador</b> (pendrive, HD externo ou nuvem pessoal).</p>
    <div class="acoes-linha"><a class="btn pri" href="/api/backup/baixar" download id="bkBaixar">Fazer backup agora e baixar</a></div>
    <h3>Backups neste computador</h3>
    <div class="tabela-wrap"><table><thead><tr><th>Data</th><th>Tipo</th><th>Tamanho</th><th></th></tr></thead><tbody>${linhas || '<tr><td colspan="4" class="vazio">Nenhum backup ainda.</td></tr>'}</tbody></table></div>
    <h3>Restaurar</h3>
    <p class="dica">Troca os dados deste computador pelos do backup escolhido. Antes, o sistema guarda um backup do estado atual ("antes de restaurar").</p>
    <div class="linha"><div class="campo grande"><label>Arquivo do backup (.zip)</label><input type="file" name="arquivoBackup" accept=".zip"></div>
    <button type="button" class="btn sec" id="bkRestaurar" style="margin-bottom:12px">Restaurar backup</button></div>
    <div class="rodape"><button class="btn sec" value="cancelar" formnovalidate>Fechar</button></div>`);
  $('#bkBaixar').onclick = () => setTimeout(() => { $('#modal').close(); toast('Backup gerado. Copie o arquivo baixado para um pendrive ou nuvem.'); }, 400);
  $('#bkRestaurar').onclick = async (ev) => {
    const arq = $('#formModal').elements.arquivoBackup.files[0];
    if (!arq) { toast('Escolha o arquivo do backup.', true); return; }
    if (!confirm(`Restaurar "${arq.name}"? Os dados atuais deste computador serão substituídos (um backup deles será guardado antes).`)) return;
    try {
      const r2 = await ocupado(ev.target, async () => {
        const resp = await fetch('/api/backup/restaurar', { method: 'POST', headers: { 'Content-Type': 'application/zip' }, body: arq });
        const corpo = await resp.json().catch(() => ({}));
        if (!resp.ok) throw new Error(corpo.erro || 'Não foi possível restaurar.');
        return corpo;
      });
      $('#modal').close();
      alert(`Backup restaurado (${r2.arquivos} arquivos). O sistema vai recarregar; se pedir, entre de novo com o e-mail e a senha do backup.`);
      location.reload();
    } catch (e) { falha(e); }
  };
}

// ------------------------------------------------------------------ usuários
async function renderUsuarios() {
  const lista = await api('GET', '/api/usuarios');
  $('#cfgLeiaute').innerHTML = Object.entries(estado.sistema.leiautes).map(([k, v]) => `<option value="${k}" ${k === estado.sistema.leiaute ? 'selected' : ''}>${esc(v)}</option>`).join('');
  $('#leiauteHoje').textContent = `Hoje as notas saem no leiaute ${estado.sistema.leiauteHoje === 'nt009' ? 'da NT 009' : 'da NT 004'}.`;
  $('#tabUsuarios tbody').innerHTML = lista.map((u) => `<tr><td>${esc(u.nome)}</td><td class="mono">${esc(u.email)}</td>
    <td>${u.papel === 'admin' ? 'Administrador' : 'Usuário'}${u.inativo ? ' <span class="selo rejeitada">inativo</span>' : ''}</td>
    <td>${u.ultimoAcesso ? new Date(u.ultimoAcesso).toLocaleString('pt-BR') : '—'}</td>
    <td class="acoes">${u.id === estado.usuario.id ? '' : `<div class="icones">${ico('editar', 'Redefinir senha', `data-senha-usr="${u.id}" data-nome="${esc(u.nome)}"`)}${u.inativo ? ico('reativar', 'Reativar usuário', `data-ativo-usr="${u.id}" data-ativo="1"`) : ico('desativar', 'Desativar usuário', `data-ativo-usr="${u.id}" data-ativo="0"`, 'perigo')}</div>`}</td></tr>`).join('');
}

async function novoUsuario() {
  const ok = await modal(`<h2>Novo usuário</h2>
    <div class="linha"><div class="campo"><label>Nome *</label><input name="nome" required></div>
    <div class="campo grande"><label>E-mail *</label><input name="email" type="email" required></div></div>
    <div class="campo"><label>Senha provisória * (mín. 8; a pessoa troca em "Alterar senha")</label><input name="senha" type="password" autocomplete="new-password" required minlength="8"></div>
    ${rodapeModal('Criar')}`, (f) => api('POST', '/api/usuarios', { nome: valorCampo(f, 'nome'), email: valorCampo(f, 'email'), senha: f.elements.senha.value }));
  if (ok) { toast('Usuário criado.'); renderUsuarios(); }
}

async function redefinirSenhaUsuario(id, nome) {
  const ok = await modal(`<h2>Redefinir senha de ${esc(nome)}</h2>
    <p class="dica">Defina uma senha provisória e passe para a pessoa; ela troca depois em "Alterar senha". As sessões abertas dela são encerradas.</p>
    <div class="campo"><label>Nova senha provisória * (mín. 8)</label><input name="senha" type="password" autocomplete="new-password" required minlength="8"></div>
    ${rodapeModal('Redefinir')}`, (f) => api('PUT', `/api/usuarios/${id}/senha`, { senha: f.elements.senha.value }));
  if (ok) toast('Senha redefinida.');
}

async function iniciar() {
  estado.sistema = await api('GET', '/api/sistema');
  if ($('#rodapeLeiaute')) $('#rodapeLeiaute').textContent = `leiaute ${estado.sistema.leiauteHoje === 'nt009' ? 'NT 009' : 'NT 004'}`;
  $('#versao').textContent = `v${estado.sistema.versao}`;
  ligarEventos();
  ligarResponsivo();
  $('#formLogin').onsubmit = enviarLogin;
  $('#novoUsuario').onclick = novoUsuario;
  $('#btnVerificarLicenca').onclick = () => verificarLicencaAgora().catch(falha);
  $('#licNova').onclick = () => { const p = editarLicenca(null); ligarAtalhosPrazo(); return p.catch(falha); };
  $('#licDestaMaquina').onclick = () => licencasDestaMaquina().catch(falha);
  $('#licPublicar').onclick = () => publicarLicencas();
  ligarBuscaServico();
  $('#btnFiltros').onclick = () => { const c = $('#cartaoFiltros'); c.classList.toggle('aberto'); $('#btnFiltros').setAttribute('aria-expanded', c.classList.contains('aberto')); $('#btnFiltros').textContent = c.classList.contains('aberto') ? 'Esconder filtros' : 'Filtrar notas'; };
  $('#ctrNovo').onclick = () => editarContrato(null).catch(falha);
  $('#ctrContratada').onclick = () => editarContratada().catch(falha);
  $('#buscaAjuda').oninput = renderAjuda;
  ligarPrintChamado();
  $('#chEnviarWhats').onclick = () => enviarChamado('whats');
  $('#chEnviarEmail').onclick = () => enviarChamado('email');
  $$('input[name=tipoChamado]').forEach((r) => { r.onchange = () => { $('#campoImpacto').hidden = r.value === 'melhoria' && r.checked; }; });
  $('#ctSalvar').onclick = async () => {
    try {
      const n = so($('#ctWhats').value);
      await api('PUT', '/api/admin/contato', { whatsapp: n && !n.startsWith('55') ? `55${n}` : n, email: $('#ctEmail').value, nome: $('#ctNome').value });
      toast('Contato salvo. Clique em Publicar para enviar aos clientes.'); await renderLicencas();
    } catch (e) { falha(e); }
  };
  $('#salvarLeiaute').onclick = async () => {
    try {
      const r = await api('PUT', '/api/config/leiaute', { leiaute: $('#cfgLeiaute').value });
      Object.assign(estado.sistema, r);
      $('#leiauteHoje').textContent = `Hoje as notas saem no leiaute ${r.leiauteHoje === 'nt009' ? 'da NT 009' : 'da NT 004'}.`;
      toast('Leiaute salvo.');
    } catch (e) { falha(e); }
  };
  const e = await api('GET', '/api/auth/estado');
  if (!e.usuario) { $('#dComp').value = hoje(); return mostrarLogin(); }
  $('#dComp').value = hoje();
  return aposLogin(e.usuario);
}
iniciar().catch(falha);
