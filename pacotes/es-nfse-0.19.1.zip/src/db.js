// Armazenamento local em arquivos JSON (uma coleção por arquivo).
// Escrita atômica (arquivo temporário + rename) e fila única de gravação,
// para nunca corromper dados nem perder número de DPS em gravações simultâneas.
import { promises as fs } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const DATA_DIR = process.env.ES_NFSE_DADOS ?? path.resolve('dados');

const cache = new Map();
let fila = Promise.resolve();

function arquivo(colecao) {
  return path.join(DATA_DIR, `${colecao}.json`);
}

async function carregar(colecao) {
  if (cache.has(colecao)) return cache.get(colecao);
  let dados;
  try {
    dados = JSON.parse(await fs.readFile(arquivo(colecao), 'utf8'));
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    dados = colecao.startsWith('_') ? {} : [];
  }
  cache.set(colecao, dados);
  return dados;
}

async function persistir(colecao) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const destino = arquivo(colecao);
  const tmp = `${destino}.${process.pid}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(cache.get(colecao), null, 2));
  await fs.rename(tmp, destino);
}

/** Executa `fn(dados)` com exclusão mútua e grava o resultado em disco. */
export function transacao(colecao, fn) {
  const tarefa = fila.then(async () => {
    const dados = await carregar(colecao);
    const retorno = await fn(dados);
    await persistir(colecao);
    return retorno;
  });
  fila = tarefa.catch(() => {});
  return tarefa;
}

export async function listar(colecao, filtro = () => true) {
  await fila;
  return (await carregar(colecao)).filter(filtro);
}

export async function obter(colecao, id) {
  await fila;
  return (await carregar(colecao)).find((r) => r.id === id);
}

export function inserir(colecao, registro) {
  return transacao(colecao, (dados) => {
    const novo = { id: crypto.randomUUID(), criadoEm: new Date().toISOString(), ...registro };
    dados.push(novo);
    return novo;
  });
}

export function atualizar(colecao, id, mudancas) {
  return transacao(colecao, (dados) => {
    const i = dados.findIndex((r) => r.id === id);
    if (i < 0) return undefined;
    dados[i] = { ...dados[i], ...mudancas, id, atualizadoEm: new Date().toISOString() };
    return dados[i];
  });
}

export function remover(colecao, id) {
  return transacao(colecao, (dados) => {
    const i = dados.findIndex((r) => r.id === id);
    if (i >= 0) dados.splice(i, 1);
    return i >= 0;
  });
}

/** Mapa chave→valor (coleções que começam com "_"). */
export async function mapaObter(colecao, chave) {
  await fila;
  return (await carregar(colecao))[chave];
}

export function mapaAtualizar(colecao, chave, fn) {
  return transacao(colecao, (dados) => {
    dados[chave] = fn(dados[chave]);
    return dados[chave];
  });
}
