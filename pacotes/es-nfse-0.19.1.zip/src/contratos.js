// Contratos e cobrança das licenças (só no computador do administrador).
// Cada contrato define plano, mensalidade e vencimento; os pagamentos
// registrados aqui estendem a liberação do CNPJ na lista de licenças.
import PDFDocument from 'pdfkit';
import * as db from './db.js';
import * as licenca from './licenca.js';

const so = (v) => String(v ?? '').replace(/\D/g, '');
const erro = (m) => Object.assign(new Error(m), { usuario: true });

export const IMPLANTACAO = 197;
export const PLANOS = [
  { id: 'ate5', nome: 'Até 5 empresas', empresas: 5, mensal: 57 },
  { id: 'ate20', nome: 'Até 20 empresas', empresas: 20, mensal: 97 },
  { id: 'ate50', nome: 'Até 50 empresas', empresas: 50, mensal: 147 },
  { id: 'ate100', nome: 'Até 100 empresas', empresas: 100, mensal: 257 },
  { id: 'consulta', nome: 'Acima de 100 empresas (sob consulta)', empresas: null, mensal: null },
];
export const CARENCIA_PADRAO = 5;
export const VALIDADE_TECNICA_MESES = 12;

export const CONTRATADA_PADRAO = {
  razaoSocial: 'Everton Sousa Contabilidade', cnpj: '', endereco: '', cidade: 'Campina Grande/PB',
  representante: 'José Everton Marques de Sousa', qualificacao: 'contador, CRC-PB 013847/O-6',
  email: '', whatsapp: '5583987351040',
};

// ------------------------------------------------------------------ datas
const pad = (n) => String(n).padStart(2, '0');
const ultimoDia = (a, m) => new Date(Date.UTC(a, m, 0)).getUTCDate();
/** 'AAAA-MM' + n meses */
export const somaComp = (comp, n) => {
  const [a, m] = comp.split('-').map(Number);
  const t = a * 12 + (m - 1) + n;
  return `${Math.floor(t / 12)}-${pad((t % 12) + 1)}`;
};
const vencimentoDe = (comp, dia) => {
  const [a, m] = comp.split('-').map(Number);
  return `${comp}-${pad(Math.min(dia, ultimoDia(a, m)))}`;
};
const somaDias = (iso, d) => new Date(Date.parse(`${iso}T12:00:00Z`) + d * 864e5).toISOString().slice(0, 10);
const compDe = (iso) => iso.slice(0, 7);

// ------------------------------------------------------------------ contratada
export async function contratada() {
  return { ...CONTRATADA_PADRAO, ...((await db.mapaObter('_config', 'contratada')) ?? {}) };
}
export async function salvarContratada(e) {
  const c = {};
  for (const k of Object.keys(CONTRATADA_PADRAO)) c[k] = String(e[k] ?? '').trim().slice(0, 200);
  c.cnpj = so(c.cnpj); c.whatsapp = so(c.whatsapp);
  if (c.cnpj && c.cnpj.length !== 14 && c.cnpj.length !== 11) throw erro('CNPJ/CPF da contratada inválido.');
  await db.mapaAtualizar('_config', 'contratada', () => c);
  return c;
}

// ------------------------------------------------------------------ cálculo
/** Mensalidades do contrato até a competência de referência, com o que já foi pago. */
export function parcelas(c, hoje = licenca.hojeBrasil()) {
  const pagos = new Map((c.pagamentos ?? []).map((p) => [p.competencia, p]));
  const fimComp = c.encerradoEm ? compDe(c.encerradoEm) : somaComp(compDe(hoje), 1);
  const lista = [];
  for (let comp = compDe(c.primeiroVencimento); comp <= fimComp && lista.length < 240; comp = somaComp(comp, 1)) {
    const venc = vencimentoDe(comp, c.diaVencimento);
    const p = pagos.get(comp);
    lista.push({ competencia: comp, vencimento: venc, valor: p?.valor ?? c.valorMensal, pago: Boolean(p), pagoEm: p?.pagoEm ?? null, forma: p?.forma ?? '', atrasada: !p && venc < hoje });
  }
  for (const [comp, p] of pagos) if (!lista.some((x) => x.competencia === comp)) lista.push({ competencia: comp, vencimento: vencimentoDe(comp, c.diaVencimento), valor: p.valor, pago: true, pagoEm: p.pagoEm, forma: p.forma, atrasada: false });
  return lista.sort((a, b) => a.competencia.localeCompare(b.competencia));
}

/** Até quando a licença fica liberada: vencimento seguinte à última mensalidade paga em sequência, mais a carência. */
export function liberadoAte(c) {
  const pagos = new Set((c.pagamentos ?? []).map((p) => p.competencia));
  let comp = compDe(c.primeiroVencimento);
  let ultima = null;
  while (pagos.has(comp)) { ultima = comp; comp = somaComp(comp, 1); }
  const base = ultima ? vencimentoDe(somaComp(ultima, 1), c.diaVencimento) : c.primeiroVencimento;
  return somaDias(base, c.carencia ?? CARENCIA_PADRAO);
}

export function situacao(c, hoje = licenca.hojeBrasil()) {
  const ps = parcelas(c, hoje);
  const atrasadas = ps.filter((p) => p.atrasada);
  const proxima = ps.find((p) => !p.pago && !p.atrasada) ?? null;
  const ate = liberadoAte(c);
  const status = c.status !== 'ativo' ? c.status : atrasadas.length ? 'atrasado' : 'em_dia';
  return {
    status, atrasadas: atrasadas.length, valorAtrasado: atrasadas.reduce((s, p) => s + Number(p.valor || 0), 0),
    proxima, liberadoAte: ate, licencaVencida: ate < hoje, implantacaoPendente: Number(c.valorImplantacao) > 0 && !c.implantacaoPagaEm,
  };
}

export async function resumo(hoje = licenca.hojeBrasil()) {
  const todos = await db.listar('contratos');
  const ativos = todos.filter((c) => c.status === 'ativo');
  const compAtual = compDe(hoje);
  let aReceber = 0; let atrasado = 0; let recebidoMes = 0;
  for (const c of todos) {
    for (const p of parcelas(c, hoje)) {
      if (p.pago && p.pagoEm?.startsWith(compAtual)) recebidoMes += Number(p.valor || 0);
      if (!p.pago && c.status === 'ativo' && p.competencia === compAtual && !p.atrasada) aReceber += Number(p.valor || 0);
      if (p.atrasada && c.status === 'ativo') atrasado += Number(p.valor || 0);
    }
    if (c.implantacaoPagaEm?.startsWith(compAtual)) recebidoMes += Number(c.valorImplantacao || 0);
  }
  return { ativos: ativos.length, mrr: ativos.reduce((s, c) => s + Number(c.valorMensal || 0), 0), aReceber, atrasado, recebidoMes };
}

// ------------------------------------------------------------------ cadastro
async function proximoNumero(ano) {
  let n = 0;
  await db.mapaAtualizar('_contadores', `contratos:${ano}`, (v = 0) => { n = v + 1; return n; });
  return `CT-${ano}-${String(n).padStart(3, '0')}`;
}

/** Limite de clientes na licença Contador: o plano conta todas as empresas emitentes, inclusive o escritório. */
export const limiteDoPlano = (empresas) => Math.max(1, Number(empresas) - 1);

function normalizar(e, atual = {}) {
  const doc = so(e.cnpj ?? atual.cnpj);
  if (doc.length !== 14 && doc.length !== 11) throw erro('Informe o CNPJ (ou CPF) do contratante.');
  const plano = PLANOS.find((p) => p.id === (e.plano ?? atual.plano));
  if (!plano) throw erro('Escolha o plano.');
  const perfil = (e.perfil ?? atual.perfil) === 'contador' ? 'contador' : 'cliente';
  const num = (v, padrao) => { const n = Number(String(v ?? '').replace(',', '.')); return Number.isFinite(n) && String(v ?? '') !== '' ? n : padrao; };
  const valorMensal = num(e.valorMensal, plano.mensal ?? atual.valorMensal);
  if (!(valorMensal > 0)) throw erro('Informe o valor da mensalidade.');
  const empresas = plano.empresas ?? Math.max(1, Number.parseInt(e.empresas ?? atual.empresas, 10) || 0);
  if (!plano.empresas && !(empresas > 100)) throw erro('No plano sob consulta, informe a quantidade de empresas (acima de 100).');
  const dia = Number.parseInt(e.diaVencimento ?? atual.diaVencimento, 10);
  if (!(dia >= 1 && dia <= 28)) throw erro('Dia de vencimento entre 1 e 28.');
  const inicio = String(e.inicio ?? atual.inicio ?? '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(inicio)) throw erro('Informe a data de início.');
  let primeiroVencimento = String(e.primeiroVencimento ?? atual.primeiroVencimento ?? '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(primeiroVencimento)) {
    const comp = compDe(inicio);
    primeiroVencimento = vencimentoDe(vencimentoDe(comp, dia) >= inicio ? comp : somaComp(comp, 1), dia);
  }
  primeiroVencimento = vencimentoDe(compDe(primeiroVencimento), dia);
  const txt = (k, max = 200) => String(e[k] ?? atual[k] ?? '').trim().slice(0, max);
  const razaoSocial = txt('razaoSocial', 150);
  if (!razaoSocial) throw erro('Informe o nome ou razão social do contratante.');
  return {
    cnpj: doc, razaoSocial, endereco: txt('endereco', 250), cidade: txt('cidade', 80), representante: txt('representante', 120),
    cpfRepresentante: so(e.cpfRepresentante ?? atual.cpfRepresentante), email: txt('email', 120).toLowerCase(), whatsapp: so(e.whatsapp ?? atual.whatsapp),
    perfil, plano: plano.id, empresas, valorMensal, valorImplantacao: num(e.valorImplantacao, atual.valorImplantacao ?? IMPLANTACAO),
    diaVencimento: dia, inicio, primeiroVencimento, prazoMeses: Math.max(1, Math.min(60, Number.parseInt(e.prazoMeses ?? atual.prazoMeses, 10) || 12)),
    carencia: (() => { const n = Number.parseInt(e.carencia ?? atual.carencia, 10); return Number.isFinite(n) ? Math.max(0, Math.min(30, n)) : CARENCIA_PADRAO; })(),
    obs: txt('obs', 500),
  };
}

/** Leva o contrato para a lista de licenças (perfil, limite, vencimento e bloqueio). */
export async function sincronizarLicenca(c) {
  return licenca.salvarAdmin({
    cnpj: c.cnpj, nome: c.razaoSocial, perfil: c.perfil, limite: c.perfil === 'contador' ? limiteDoPlano(c.empresas) : undefined,
    ate: liberadoAte(c), bloqueado: c.status !== 'ativo', obs: `Contrato ${c.numero}`,
  });
}

export async function listar() {
  const hoje = licenca.hojeBrasil();
  const lista = (await db.listar('contratos')).sort((a, b) => b.numero.localeCompare(a.numero));
  return lista.map((c) => ({ ...c, situacao: situacao(c, hoje), parcelas: parcelas(c, hoje) }));
}

export async function salvar(e, id) {
  if (id) {
    const atual = await db.obter('contratos', id);
    if (!atual) throw Object.assign(erro('Contrato não encontrado.'), { status: 404 });
    const dados = normalizar(e, atual);
    if (dados.cnpj !== atual.cnpj) throw erro('O CNPJ do contrato não pode ser trocado. Encerre este e crie outro.');
    const c = await db.atualizar('contratos', id, { ...dados, atualizadoEm: new Date().toISOString() });
    await sincronizarLicenca(c);
    return c;
  }
  const dados = normalizar(e);
  const dup = (await db.listar('contratos')).find((c) => c.cnpj === dados.cnpj && c.status !== 'encerrado');
  if (dup) throw erro(`Já existe o contrato ${dup.numero} ativo para este CNPJ.`);
  const c = await db.inserir('contratos', { ...dados, numero: await proximoNumero(dados.inicio.slice(0, 4)), status: 'ativo', pagamentos: [], implantacaoPagaEm: null, criadoEm: new Date().toISOString() });
  await sincronizarLicenca(c);
  return c;
}

export async function registrarPagamento(id, { competencia, valor, pagoEm, forma } = {}) {
  const c = await db.obter('contratos', id);
  if (!c) throw Object.assign(erro('Contrato não encontrado.'), { status: 404 });
  const data = /^\d{4}-\d{2}-\d{2}$/.test(String(pagoEm ?? '')) ? pagoEm : licenca.hojeBrasil();
  if (competencia === 'implantacao') {
    const n = await db.atualizar('contratos', id, { implantacaoPagaEm: data, implantacaoForma: String(forma ?? '').slice(0, 40) });
    return n;
  }
  const pagos = new Set((c.pagamentos ?? []).map((p) => p.competencia));
  let comp = competencia;
  if (!comp) { comp = compDe(c.primeiroVencimento); while (pagos.has(comp)) comp = somaComp(comp, 1); }
  if (!/^\d{4}-\d{2}$/.test(comp)) throw erro('Competência inválida.');
  if (pagos.has(comp)) throw erro(`A mensalidade ${comp.split('-').reverse().join('/')} já está paga.`);
  const v = Number(String(valor ?? '').replace(',', '.'));
  const n = await db.atualizar('contratos', id, {
    pagamentos: [...(c.pagamentos ?? []), { competencia: comp, valor: v > 0 ? v : c.valorMensal, pagoEm: data, forma: String(forma ?? '').slice(0, 40) }]
      .sort((a, b) => a.competencia.localeCompare(b.competencia)),
  });
  await sincronizarLicenca(n);
  return n;
}

export async function estornarPagamento(id, competencia) {
  const c = await db.obter('contratos', id);
  if (!c) throw Object.assign(erro('Contrato não encontrado.'), { status: 404 });
  if (competencia === 'implantacao') return db.atualizar('contratos', id, { implantacaoPagaEm: null });
  const n = await db.atualizar('contratos', id, { pagamentos: (c.pagamentos ?? []).filter((p) => p.competencia !== competencia) });
  await sincronizarLicenca(n);
  return n;
}

export async function mudarStatus(id, status) {
  if (!['ativo', 'suspenso', 'encerrado'].includes(status)) throw erro('Situação inválida.');
  const c = await db.obter('contratos', id);
  if (!c) throw Object.assign(erro('Contrato não encontrado.'), { status: 404 });
  const n = await db.atualizar('contratos', id, { status, encerradoEm: status === 'encerrado' ? licenca.hojeBrasil() : null });
  await sincronizarLicenca(n);
  return n;
}

export async function remover(id) {
  const c = await db.obter('contratos', id);
  if (!c) return;
  if ((c.pagamentos ?? []).length || c.implantacaoPagaEm) throw erro('Contrato com pagamentos registrados não pode ser excluído: use Encerrar.');
  await db.remover('contratos', id);
}

// ------------------------------------------------------------------ PDF
const fmtDoc = (d = '') => (d.length === 14
  ? d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5')
  : d.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4'));
const moeda = (v) => Number(v ?? 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const dataBr = (iso) => (iso ? iso.split('-').reverse().join('/') : '—');
const extenso = (iso) => new Date(`${iso}T12:00:00Z`).toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
const fone = (f = '') => (f.length >= 12 ? `(${f.slice(2, 4)}) ${f.slice(4, -4)}-${f.slice(-4)}` : f);

export function contratoPdf(c, ctd) {
  const M = 64;
  const pdf = new PDFDocument({ size: 'A4', margins: { top: 60, bottom: 64, left: M, right: M }, info: { Title: `Contrato ${c.numero} — ES NFS-e`, Producer: 'ES NFS-e' }, bufferPages: true });
  const L = pdf.page.width - 2 * M;
  const j = { align: 'justify', width: L, lineGap: 2.5 };
  const plano = PLANOS.find((p) => p.id === c.plano);
  const contratadaTxt = `${ctd.razaoSocial || '[CONTRATADA]'}${ctd.cnpj ? `, inscrita no ${ctd.cnpj.length === 14 ? 'CNPJ' : 'CPF'} sob o nº ${fmtDoc(ctd.cnpj)}` : ', [CNPJ]'}${ctd.endereco ? `, com sede em ${ctd.endereco}` : ''}${ctd.cidade ? `, ${ctd.cidade}` : ''}, neste ato representada por ${ctd.representante || '[REPRESENTANTE]'}${ctd.qualificacao ? `, ${ctd.qualificacao}` : ''}`;
  const contratanteTxt = `${c.razaoSocial}, inscrita no ${c.cnpj.length === 14 ? 'CNPJ' : 'CPF'} sob o nº ${fmtDoc(c.cnpj)}${c.endereco ? `, com endereço em ${c.endereco}` : ''}${c.cidade ? `, ${c.cidade}` : ''}${c.representante ? `, neste ato representada por ${c.representante}${c.cpfRepresentante ? `, CPF nº ${fmtDoc(c.cpfRepresentante)}` : ''}` : ''}`;
  const limiteTxt = c.perfil === 'contador'
    ? `Versão Contador, para até ${c.empresas} (${c.empresas === 1 ? 'uma' : c.empresas}) empresas emitentes, incluída a própria CONTRATANTE, que poderá emitir NFS-e para seus clientes com o certificado digital de cada um ou por procuração eletrônica`
    : 'Versão Cliente, para emissão exclusiva em nome do CNPJ/CPF da CONTRATANTE';

  pdf.font('Helvetica-Bold').fontSize(13).text('CONTRATO DE LICENÇA DE USO DE SOFTWARE', { align: 'center' });
  pdf.text('E PRESTAÇÃO DE SERVIÇOS DE IMPLANTAÇÃO E SUPORTE', { align: 'center' });
  pdf.moveDown(0.3).font('Helvetica').fontSize(9.5).fillColor('#555').text(`ES NFS-e · Contrato nº ${c.numero}`, { align: 'center' }).fillColor('#000');
  pdf.moveDown(1.2).fontSize(10.5);

  const titulo = (t) => { pdf.moveDown(0.6).font('Helvetica-Bold').text(t, j).moveDown(0.2).font('Helvetica'); };
  const par = (t) => pdf.text(t, j).moveDown(0.35);

  par(`CONTRATADA: ${contratadaTxt}.`);
  par(`CONTRATANTE: ${contratanteTxt}.`);
  par('As partes acima identificadas celebram o presente contrato, nos termos da Lei nº 9.609/1998 (Lei do Software), da Lei nº 13.709/2018 (Lei Geral de Proteção de Dados) e do Código Civil, mediante as cláusulas seguintes.');

  titulo('CLÁUSULA 1ª — DO OBJETO');
  par(`1.1. Licença de uso, não exclusiva e intransferível, do programa ES NFS-e, emissor de Nota Fiscal de Serviço Eletrônica do Padrão Nacional, na ${limiteTxt}.`);
  par('1.2. Prestação dos serviços de implantação e de suporte técnico descritos neste contrato.');
  par('1.3. A licença não transfere à CONTRATANTE a propriedade do programa nem de seu código-fonte, sendo vedados a cessão, sublicença, cópia para terceiros, engenharia reversa e qualquer tentativa de contornar o controle de licenças.');

  titulo('CLÁUSULA 2ª — DA IMPLANTAÇÃO');
  par(`2.1. A implantação compreende a instalação remota, o cadastro das empresas e dos certificados digitais junto com a CONTRATANTE, o cadastro dos serviços favoritos, a configuração de procuração eletrônica quando aplicável, a emissão assistida da primeira nota e orientação de uso à equipe da CONTRATANTE.`);
  par(`2.2. Pela implantação a CONTRATANTE pagará ${moeda(c.valorImplantacao)}, em parcela única, até a data da implantação.`);

  titulo('CLÁUSULA 3ª — DO PREÇO E DO PAGAMENTO');
  par(`3.1. Pela licença e pelo suporte a CONTRATANTE pagará mensalidade de ${moeda(c.valorMensal)} (plano ${plano?.nome ?? c.plano}), com vencimento todo dia ${c.diaVencimento} de cada mês, sendo o primeiro vencimento em ${dataBr(c.primeiroVencimento)}.`);
  par('3.2. A mudança de plano, por aumento ou redução da quantidade de empresas, altera a mensalidade a partir do mês seguinte ao pedido.');
  par('3.3. Os valores serão reajustados a cada 12 (doze) meses pela variação acumulada do IPCA/IBGE, ou outro índice que o substitua.');

  titulo('CLÁUSULA 4ª — DA INADIMPLÊNCIA E DO BLOQUEIO');
  par(`4.1. O atraso no pagamento sujeita o valor devido a multa de 2% (dois por cento) e juros de 1% (um por cento) ao mês, pro rata die.`);
  par(`4.2. Decorridos ${c.carencia} (${c.carencia === 1 ? 'um' : c.carencia}) dias do vencimento sem pagamento, o acesso ao sistema poderá ser suspenso automaticamente, sem prejuízo da cobrança, e será restabelecido após a quitação. A suspensão não apaga as notas e os dados guardados no computador da CONTRATANTE.`);

  titulo('CLÁUSULA 5ª — DO SUPORTE E DA VALIDADE TÉCNICA');
  par('5.1. O suporte técnico será prestado em dias úteis, em horário comercial, pelos canais de atendimento informados no próprio sistema (abertura de chamado, WhatsApp e e-mail), e abrange dúvidas de uso e correção de falhas do programa.');
  par('5.2. As atualizações de versão, inclusive para adequação às notas técnicas do Padrão Nacional da NFS-e, são instaladas automaticamente, sem custo adicional, enquanto o contrato estiver vigente.');
  par(`5.3. Nos termos do art. 7º da Lei nº 9.609/1998, o prazo de validade técnica de cada versão comercializada é de ${VALIDADE_TECNICA_MESES} (doze) meses contados de sua liberação, ou até a liberação da versão seguinte, mantida a obrigação de suporte prevista no art. 8º da mesma lei durante esse prazo.`);
  par('5.4. Não integram o suporte: a emissão de notas em nome da CONTRATANTE, a consultoria tributária sobre o enquadramento dos serviços, nem falhas causadas por indisponibilidade dos sistemas da Receita Federal, do Comitê Gestor da NFS-e, da prefeitura, da internet ou do equipamento da CONTRATANTE.');

  titulo('CLÁUSULA 6ª — DAS OBRIGAÇÕES DA CONTRATANTE');
  par('6.1. Manter certificado digital válido e a guarda da respectiva senha, que é de uso exclusivo da CONTRATANTE; manter as procurações eletrônicas vigentes, quando utilizadas; e conservar cópias de segurança de seu computador.');
  par('6.2. Responder pelo conteúdo das notas emitidas, pela correção dos dados informados e pelo cumprimento das obrigações tributárias decorrentes.');

  titulo('CLÁUSULA 7ª — DOS DADOS E DA PROTEÇÃO DE DADOS PESSOAIS');
  par('7.1. O sistema funciona instalado no computador da CONTRATANTE, onde ficam armazenados as notas, os cadastros e o certificado digital, este de forma cifrada. A CONTRATADA não acessa esses dados, salvo quando a CONTRATANTE os compartilhar para atendimento de suporte, hipótese em que atuará como operadora, nos termos da Lei nº 13.709/2018, apenas para essa finalidade.');
  par('7.2. Para o controle de licenças, o sistema consulta periodicamente uma lista publicada pela CONTRATADA, na qual o CNPJ/CPF consta apenas em forma cifrada (resumo criptográfico).');

  titulo('CLÁUSULA 8ª — DA VIGÊNCIA E DA RESCISÃO');
  par(`8.1. Este contrato vigora por ${c.prazoMeses} (${c.prazoMeses === 12 ? 'doze' : c.prazoMeses}) meses a partir de ${dataBr(c.inicio)}, renovando-se automaticamente por iguais períodos, salvo manifestação contrária de qualquer das partes com antecedência mínima de 30 (trinta) dias.`);
  par('8.2. Qualquer das partes poderá rescindir o contrato, sem multa, mediante aviso prévio de 30 (trinta) dias, sendo devidas as mensalidades até o fim do aviso. O valor da implantação não é reembolsável após sua realização.');
  par('8.3. Encerrado o contrato, a licença de uso é cancelada; as notas já emitidas continuam disponíveis no Portal Nacional da NFS-e.');

  titulo('CLÁUSULA 9ª — DO FORO');
  par(`9.1. Fica eleito o foro da comarca de ${(ctd.cidade || 'Campina Grande/PB').replace('/', ' - ')} para dirimir questões oriundas deste contrato.`);
  if (c.obs) { titulo('OBSERVAÇÕES'); par(c.obs); }

  if (pdf.y > pdf.page.height - 240) pdf.addPage();
  pdf.moveDown(0.8).text(`${(ctd.cidade || 'Campina Grande/PB').split('/')[0]}, ${extenso(c.inicio)}.`, j);
  pdf.moveDown(3);
  const y = pdf.y; const w = (L - 40) / 2;
  pdf.moveTo(M, y).lineTo(M + w, y).stroke('#333');
  pdf.moveTo(M + w + 40, y).lineTo(M + L, y).stroke('#333');
  pdf.fontSize(9.5).text(`CONTRATADA\n${ctd.razaoSocial}\n${ctd.representante}`, M, y + 6, { width: w, align: 'center' });
  pdf.text(`CONTRATANTE\n${c.razaoSocial}\n${c.representante || ''}`, M + w + 40, y + 6, { width: w, align: 'center' });

  const total = pdf.bufferedPageRange().count;
  for (let i = 0; i < total; i++) {
    pdf.switchToPage(i);
    pdf.page.margins.bottom = 0;
    pdf.fontSize(8).fillColor('#777').text(`Contrato ${c.numero} · ES NFS-e · página ${i + 1} de ${total}${ctd.whatsapp ? ` · ${fone(ctd.whatsapp)}` : ''}`, M, pdf.page.height - 44, { width: L, align: 'center', lineBreak: false });
  }
  pdf.end();
  return pdf;
}
