// Requerimento de cancelamento de NFS-e (para protocolar na prefeitura quando
// o cancelamento depende de análise fiscal ou de termo assinado).
import PDFDocument from 'pdfkit';

const M = 60;
const fmtDoc = (d = '') => (d.length === 14
  ? d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5')
  : d.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4'));
const moeda = (v) => Number(v ?? 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const dataBr = (v) => (v ? new Date(v).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : '-');
const extenso = (d) => d.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'America/Sao_Paulo' });

/** Lê do XML da NFS-e o endereço e a inscrição do prestador, quando houver. */
function dadosPrestador(xml = '') {
  const emit = xml.match(/<emit>([\s\S]*?)<\/emit>/)?.[1] ?? '';
  const g = (t) => emit.match(new RegExp(`<${t}>([^<]*)</${t}>`))?.[1] ?? '';
  const partes = [g('xLgr') && `${g('xLgr')}, ${g('nro') || 's/n'}`, g('xCpl'), g('xBairro'), g('CEP') && `CEP ${g('CEP').replace(/^(\d{5})(\d{3})$/, '$1-$2')}`].filter(Boolean);
  return { endereco: partes.join(' - '), im: g('IM') };
}

export function gerarRequerimentoPdf({ empresa, nota, xmlNfse, cMotivoTexto, justificativa, municipio }) {
  const pdf = new PDFDocument({ size: 'A4', margins: { top: 56, bottom: 56, left: M, right: M }, info: { Title: `Requerimento de cancelamento NFS-e ${nota.numero}`, Producer: 'ES NFS-e' } });
  const largura = pdf.page.width - 2 * M;
  const prest = dadosPrestador(xmlNfse);
  const cidade = municipio || empresa.municipio || '';
  const just = { align: 'justify', width: largura, lineGap: 3 };

  pdf.font('Helvetica-Bold').fontSize(14).text('REQUERIMENTO DE CANCELAMENTO DE NFS-e', { align: 'center' });
  pdf.moveDown(0.3).font('Helvetica').fontSize(9).fillColor('#555')
    .text('Solicitação de Análise Fiscal para Cancelamento de Nota Fiscal de Serviço Eletrônica', { align: 'center' });
  pdf.fillColor('#000').moveDown(1.5).fontSize(11)
    .text(`À Secretaria Municipal de Finanças / Fiscalização do ISS${cidade ? ` de ${cidade}` : ''}`, just);

  pdf.moveDown(1).font('Helvetica')
    .text(`${empresa.razaoSocial}, inscrita no CNPJ sob o nº ${fmtDoc(empresa.cnpj)}${(empresa.inscricaoMunicipal || prest.im) ? `, inscrição municipal nº ${empresa.inscricaoMunicipal || prest.im}` : ''}${prest.endereco ? `, com sede em ${prest.endereco}` : ''}${cidade ? `, ${cidade}` : ''}, por seu representante legal abaixo assinado, vem requerer o CANCELAMENTO da Nota Fiscal de Serviço Eletrônica descrita a seguir, pelos motivos expostos.`, just);

  // Quadro com os dados da nota
  pdf.moveDown(1);
  const linhas = [
    ['Número da NFS-e', String(nota.numero ?? '-')],
    ['Chave de acesso', nota.chaveAcesso ?? '-'],
    ['Data de emissão', dataBr(nota.dhProc)],
    ['Competência', dataBr(nota.competencia && `${nota.competencia}T12:00`)],
    ['Tomador', `${nota.tomadorNome ?? '-'}${nota.tomadorDoc ? ` — ${fmtDoc(nota.tomadorDoc)}` : ''}`],
    ['Valor do serviço', moeda(nota.vServ)],
    ['Discriminação', String(nota.descricao ?? '-').slice(0, 300)],
  ];
  const col = 130;
  let y = pdf.y;
  pdf.fontSize(9.5);
  for (const [rot, val] of linhas) {
    const h = Math.max(pdf.heightOfString(val, { width: largura - col - 12 }), 11) + 10;
    pdf.rect(M, y, col, h).fillAndStroke('#f2f2f2', '#999');
    pdf.rect(M + col, y, largura - col, h).stroke('#999');
    pdf.fillColor('#000').font('Helvetica-Bold').text(rot, M + 6, y + 5, { width: col - 12 });
    pdf.font('Helvetica').text(val, M + col + 6, y + 5, { width: largura - col - 12 });
    y += h;
  }
  pdf.x = M; pdf.y = y + 16;

  pdf.fontSize(11).font('Helvetica-Bold').text('Motivo: ', { continued: true }).font('Helvetica').text(cMotivoTexto || '-');
  pdf.moveDown(0.6).font('Helvetica-Bold').text('Justificativa:');
  pdf.font('Helvetica').text(justificativa || '-', just);

  pdf.moveDown(1).text('Declara, sob as penas da lei, que as informações acima são verdadeiras, e junta a este requerimento a declaração de concordância do tomador do serviço e os documentos que comprovam o alegado. Nestes termos, pede deferimento.', just);

  pdf.moveDown(1.5).text(`${cidade ? `${cidade.split('/')[0]}, ` : ''}${extenso(new Date())}.`, { align: 'right', width: largura });

  const assinatura = (titulo, nome, doc) => {
    pdf.moveDown(2.6);
    const yy = pdf.y;
    pdf.moveTo(M + 70, yy).lineTo(M + largura - 70, yy).stroke('#000');
    pdf.moveDown(0.3).fontSize(10).font('Helvetica-Bold').text(nome, { align: 'center', width: largura });
    pdf.font('Helvetica').fontSize(9).text(`${titulo}${doc ? ` — ${fmtDoc(doc)}` : ''}`, { align: 'center', width: largura });
  };
  assinatura('Prestador do serviço (representante legal)', empresa.razaoSocial, empresa.cnpj);

  pdf.moveDown(1.6).fontSize(10.5).font('Helvetica-Bold').text('DECLARAÇÃO DO TOMADOR DO SERVIÇO', { align: 'center', width: largura });
  pdf.moveDown(0.4).font('Helvetica').fontSize(10)
    .text(`${nota.tomadorNome ?? 'O tomador'}${nota.tomadorDoc ? `, ${nota.tomadorDoc.length === 14 ? 'CNPJ' : 'CPF'} nº ${fmtDoc(nota.tomadorDoc)}` : ''}, declara estar ciente e de acordo com o cancelamento da NFS-e nº ${nota.numero}, no valor de ${moeda(nota.vServ)}, e que não a utilizou nem a utilizará para qualquer fim, inclusive crédito ou dedução de tributos.`, just);
  assinatura('Tomador do serviço (representante legal)', nota.tomadorNome ?? '', nota.tomadorDoc);

  pdf.page.margins.bottom = 0;
  pdf.fontSize(7.5).fillColor('#777').text(`Gerado pelo ES NFS-e em ${new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}`, M, pdf.page.height - 40, { width: largura, align: 'center', lineBreak: false });
  pdf.end();
  return pdf;
}
