// Suporte: chamados (inconsistência ou melhoria), últimos erros e diagnóstico.
// O chamado fica registrado aqui e é enviado ao escritório pelo WhatsApp ou
// e-mail publicados pelo administrador junto com a lista de liberações.
import os from 'node:os';
import * as db from './db.js';
import { VERSAO } from './versao.js';

const MAX_ERROS = 40;
const ultimosErros = [];

/** Guarda (sem dados sensíveis) os últimos erros vistos pelo servidor. */
export function registrarErro(req, status, mensagem) {
  ultimosErros.push({
    em: new Date().toISOString(), status, rota: `${req.method} ${req.path.replace(/\/[0-9a-f-]{20,}/gi, '/:id')}`,
    erro: String(mensagem ?? '').slice(0, 300),
  });
  if (ultimosErros.length > MAX_ERROS) ultimosErros.shift();
}

export const TIPOS = { inconsistencia: 'Inconsistência (erro no sistema)', melhoria: 'Solicitação de melhoria' };
export const IMPACTOS = { impede: 'Impede emitir/trabalhar', atrapalha: 'Atrapalha, mas dá para contornar', baixo: 'Baixo impacto' };

async function proximoProtocolo() {
  const hoje = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  let n = 0;
  await db.mapaAtualizar('_contadores', `chamados:${hoje}`, (v = 0) => { n = v + 1; return n; });
  return `CH-${hoje}-${String(n).padStart(3, '0')}`;
}

export async function diagnostico({ empresa, leiaute } = {}) {
  const notas = empresa ? await db.listar('notas', (x) => x.empresaId === empresa.id) : [];
  return {
    versao: VERSAO,
    sistema: `${os.type()} ${os.release()} · Node ${process.version}`,
    leiaute,
    empresa: empresa ? { razaoSocial: empresa.razaoSocial, cnpj: empresa.cnpj, ambiente: empresa.ambiente, opSimpNac: empresa.opSimpNac, municipio: empresa.municipio } : null,
    notas: notas.length,
    pendentes: notas.filter((x) => x.status === 'pendente').length,
    ultimosErros: ultimosErros.slice(-10),
  };
}

export async function abrirChamado(dados, { usuario, empresa, leiaute }) {
  const tipo = TIPOS[dados.tipo] ? dados.tipo : null;
  const titulo = String(dados.titulo ?? '').trim();
  const descricao = String(dados.descricao ?? '').trim();
  if (!tipo) throw Object.assign(new Error('Escolha o tipo do chamado.'), { usuario: true });
  if (titulo.length < 5) throw Object.assign(new Error('Dê um título ao chamado.'), { usuario: true });
  if (descricao.length < 15) throw Object.assign(new Error('Descreva o que aconteceu (ou o que precisa), com pelo menos 15 caracteres.'), { usuario: true });
  return db.inserir('chamados', {
    protocolo: await proximoProtocolo(),
    tipo, titulo: titulo.slice(0, 120), descricao: descricao.slice(0, 3000),
    tela: String(dados.tela ?? '').slice(0, 60),
    impacto: tipo === 'inconsistencia' && IMPACTOS[dados.impacto] ? dados.impacto : undefined,
    situacao: 'aberto',
    usuario: { nome: usuario?.nome, email: usuario?.email },
    diagnostico: dados.semDiagnostico ? null : await diagnostico({ empresa, leiaute }),
  });
}

/** Texto do chamado para WhatsApp/e-mail. */
export function textoChamado(c) {
  const d = c.diagnostico;
  const l = [
    `*${c.protocolo}* — ${TIPOS[c.tipo]}`,
    `*${c.titulo}*`,
    '',
    c.descricao,
    '',
    c.tela ? `Tela: ${c.tela}` : '',
    c.impacto ? `Impacto: ${IMPACTOS[c.impacto]}` : '',
    `Aberto por: ${c.usuario?.nome ?? ''} (${c.usuario?.email ?? ''}) em ${new Date(c.criadoEm).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}`,
  ];
  if (d) {
    l.push('', '— Diagnóstico —', `ES NFS-e v${d.versao} · leiaute ${d.leiaute ?? '-'} · ${d.sistema}`);
    if (d.empresa) l.push(`Empresa: ${d.empresa.razaoSocial} (${d.empresa.cnpj}) · ${d.empresa.ambiente} · ${d.empresa.municipio ?? ''}`);
    l.push(`Notas: ${d.notas} · pendentes: ${d.pendentes}`);
    if (d.ultimosErros?.length) {
      l.push('Últimos erros:');
      for (const e of d.ultimosErros.slice(-5)) l.push(`• ${e.em.slice(0, 16).replace('T', ' ')} ${e.rota} → ${e.erro}`);
    }
  }
  return l.filter((x, i, a) => x !== '' || a[i - 1] !== '').join('\n');
}
