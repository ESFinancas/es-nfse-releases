// Guarda o certificado A1 (.pfx) e a senha de cada empresa cifrados com
// AES-256-GCM. A chave-mestra fica em dados/.chave-mestra (gerada na
// primeira execução) ou na variável ES_NFSE_CHAVE (64 hex), que é o mais
// seguro: assim a pasta de dados sozinha não abre os certificados.
import { promises as fs } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DATA_DIR } from './db.js';

let chaveMestra;

async function chave() {
  if (chaveMestra) return chaveMestra;
  if (process.env.ES_NFSE_CHAVE) {
    chaveMestra = Buffer.from(process.env.ES_NFSE_CHAVE, 'hex');
    if (chaveMestra.length !== 32) throw new Error('ES_NFSE_CHAVE deve ter 64 caracteres hexadecimais');
    return chaveMestra;
  }
  const arq = path.join(DATA_DIR, '.chave-mestra');
  try {
    chaveMestra = Buffer.from((await fs.readFile(arq, 'utf8')).trim(), 'hex');
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    await fs.mkdir(DATA_DIR, { recursive: true });
    chaveMestra = crypto.randomBytes(32);
    await fs.writeFile(arq, chaveMestra.toString('hex'), { mode: 0o600 });
  }
  return chaveMestra;
}

export async function cifrar(buffer) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', await chave(), iv);
  const dados = Buffer.concat([c.update(buffer), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), dados]).toString('base64');
}

export async function decifrar(b64) {
  const raw = Buffer.from(b64, 'base64');
  const d = crypto.createDecipheriv('aes-256-gcm', await chave(), raw.subarray(0, 12));
  d.setAuthTag(raw.subarray(12, 28));
  return Buffer.concat([d.update(raw.subarray(28)), d.final()]);
}

const DIR_CERT = () => path.join(DATA_DIR, 'certificados');

export async function salvarCertificado(empresaId, pfx, senha) {
  await fs.mkdir(DIR_CERT(), { recursive: true });
  const conteudo = JSON.stringify({ pfx: await cifrar(pfx), senha: await cifrar(Buffer.from(senha, 'utf8')) });
  await fs.writeFile(path.join(DIR_CERT(), `${empresaId}.cert`), conteudo, { mode: 0o600 });
}

export async function lerCertificado(empresaId) {
  try {
    const { pfx, senha } = JSON.parse(await fs.readFile(path.join(DIR_CERT(), `${empresaId}.cert`), 'utf8'));
    return { pfx: await decifrar(pfx), password: (await decifrar(senha)).toString('utf8') };
  } catch (err) {
    if (err.code === 'ENOENT') return undefined;
    throw err;
  }
}

export async function apagarCertificado(empresaId) {
  await fs.rm(path.join(DIR_CERT(), `${empresaId}.cert`), { force: true });
}
