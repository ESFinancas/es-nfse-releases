// Leiaute da DPS (NT 004 x NT 009) e grupo IBS/CBS da Reforma Tributária.
//
// A open-nfse monta a DPS no leiaute da NT 004 (RTC v1.01, em produção até
// 30/11/2026). A NT 009 (releases 1 a 3, produção prevista para 01/12/2026)
// muda a estrutura; aqui convertemos o XML antes de assinar e validamos contra
// o XSD certo. XSD da NT 009: pacote de produção restrita de 20/10/2026.
import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { validateDpsXml, XsdValidationError } from 'open-nfse';

export const LEIAUTES = {
  auto: 'Automático (NT 004 até 30/11/2026; NT 009 a partir de 01/12/2026)',
  nt004: 'Sempre NT 004 (leiaute anterior)',
  nt009: 'Sempre NT 009 (leiaute novo)',
};
/** Início da NT 009 em produção (00:00 de Brasília). */
export const INICIO_NT009 = new Date('2026-12-01T00:00:00-03:00');

export function leiauteVigente(config = 'auto', quando = new Date()) {
  if (config === 'nt004' || config === 'nt009') return config;
  return quando >= INICIO_NT009 ? 'nt009' : 'nt004';
}
export const outroLeiaute = (l) => (l === 'nt009' ? 'nt004' : 'nt009');

// ---------------------------------------------------------------------------
// IBS/CBS: quando informar e com quais códigos
// ---------------------------------------------------------------------------
export const MODOS_IBSCBS = {
  auto: 'Automático: informar a partir da data obrigatória',
  sempre: 'Sempre informar',
  nunca: 'Não informar',
};
/**
 * Modelos prontos para o Simples Nacional. CST/cClassTrib descrevem a OPERAÇÃO
 * (000/000001 = tributação integral, regra geral); o que separa puro e híbrido é
 * o regime de apuração do IBS/CBS (regApIBSCBSSN, NT 009 item 2.4):
 *   1 - IBS e CBS apurados pelo SN (puro, dentro do DAS)
 *   2 - CBS apurada pelo SN e IBS pelo regime regular (híbrido parcial)
 *   3 - IBS e CBS apurados pelo regime regular (híbrido, fora do DAS)
 * cIndOp 100301 é o indicador geral usado nos exemplos do Anexo VIII para serviços
 * prestados sem local físico específico (ajuste no serviço quando for presencial).
 */
export const PERFIS_IBSCBS = {
  personalizado: { nome: 'Personalizado (informo os códigos)' },
  sn_puro: {
    nome: 'Simples Nacional puro — IBS e CBS no DAS',
    regApIBSCBSSN: '1', CST: '000', cClassTrib: '000001', cIndOp: '100301',
    dica: 'IBS e CBS recolhidos dentro do DAS. A nota informa a operação (000/000001, tributação integral) e o regime 1. Se algum serviço tiver redução da LC 214/2025, ainda não há orientação consolidada para o Simples puro: confirme antes de usar CST 200.',
  },
  sn_hibrido: {
    nome: 'Simples Nacional híbrido — IBS e CBS fora do DAS',
    regApIBSCBSSN: '3', CST: '000', cClassTrib: '000001', cIndOp: '100301',
    dica: 'IBS e CBS apurados pelo regime regular, com destaque e crédito para o tomador. Use no serviço o CST/cClassTrib de redução da LC 214/2025 quando cabível (ex.: 200052 profissões intelectuais 30%, se cumprir o art. 127). Regime 3 (ou 2, se só a CBS for pelo regime regular).',
  },
};
export const REGIMES_IBSCBS_SN = {
  1: '1 - IBS e CBS apurados pelo Simples Nacional',
  2: '2 - CBS apurada pelo SN e IBS pelo regime regular',
  3: '3 - IBS e CBS apurados pelo regime regular',
};
export const ATIVIDADES_SN = {
  7: '7 - Serviços com ISS, exclusivamente Anexo III',
  8: '8 - Serviços contábeis com ISS fixo - Anexo III',
  9: '9 - Serviços sujeitos ao Fator "R" - Anexo III ou V',
  10: '10 - Transporte municipal de passageiros (16.01) - Anexo III',
  11: '11 - Locação de bens móveis e serviços sem ISS - Anexo III',
  12: '12 - Construção civil 7.02/7.05 - Anexo III',
  13: '13 - Construção civil 7.02/7.05 - Anexo IV',
  14: '14 - Prestação de serviços - Anexo IV',
  90: '90 - Operações não tributadas',
};
/** Classificações frequentes em serviços (Anexo VIII da NFS-e, referência; confira a tabela oficial). */
export const CLASSIFICACOES_COMUNS = [
  { CST: '000', cClassTrib: '000001', nome: '000001 - Tributação integral (regra geral)' },
  { CST: '200', cClassTrib: '200052', nome: '200052 - Redução 30% profissões intelectuais (só se cumprir o art. 127 da LC 214/2025)' },
  { CST: '200', cClassTrib: '200029', nome: '200029 - Redução 60% serviços de saúde (conforme NBS do Anexo da LC 214/2025)' },
];

/** Itens com obrigatoriedade a partir de 01/03/2027 (Ato Conjunto RFB/CGIBS nº 7/2026). */
const ITENS_MARCO_2027 = ['0103', '0105', '0109', '1601'];
export const inicioPadrao = (cTribNac = '') =>
  (ITENS_MARCO_2027.includes(String(cTribNac).replace(/\D/g, '').slice(0, 4)) ? '2027-03-01' : '2027-01-01');

const so = (s) => String(s ?? '').replace(/\D/g, '');

/**
 * Junta a configuração da empresa (padrão) com a informada na emissão (que já
 * vem do serviço favorito ou da última nota) e decide se o grupo vai na DPS.
 * Devolve `null` quando não deve ser informado.
 */
export function resolverIbsCbs(empresa, entrada, leiaute) {
  const perfil = PERFIS_IBSCBS[empresa.ibscbs?.perfil] ?? {};
  const padrao = { ...perfil, ...Object.fromEntries(Object.entries(empresa.ibscbs ?? {}).filter(([, x]) => x !== '' && x != null)) };
  const daNota = entrada.ibscbs ?? {};
  const v = (k) => (daNota[k] !== undefined && daNota[k] !== '' ? daNota[k] : padrao[k]);
  const modo = v('modo') || 'auto';
  if (modo === 'nunca') return null;
  const cTribNac = so(entrada.servico?.cTribNac);
  const inicio = v('inicio') || inicioPadrao(cTribNac);
  const competencia = entrada.dataCompetencia || new Date().toISOString().slice(0, 10);
  if (modo === 'auto' && competencia < inicio) return null;

  const CST = so(v('CST'));
  const cClassTrib = so(v('cClassTrib'));
  const cIndOp = so(v('cIndOp'));
  const onde = 'Configure em Empresas → Editar → IBS/CBS, no serviço favorito ou no bloco IBS/CBS da emissão.';
  const faltas = [];
  if (!/^\d{3}$/.test(CST)) faltas.push('CST do IBS/CBS (3 dígitos)');
  if (!/^\d{6}$/.test(cClassTrib)) faltas.push('cClassTrib (6 dígitos)');
  if (leiaute === 'nt004' && !/^\d{6}$/.test(cIndOp)) faltas.push('Indicador da operação — cIndOp (6 dígitos)');
  if (cIndOp && !/^\d{6}$/.test(cIndOp)) faltas.push('cIndOp deve ter 6 dígitos');
  if (faltas.length) {
    const motivo = modo === 'auto' ? `IBS/CBS é obrigatório nesta nota (competência a partir de ${inicio.split('-').reverse().join('/')}).` : 'O IBS/CBS está marcado para ser informado.';
    const e = new Error(`${motivo} Falta: ${faltas.join('; ')}. ${onde}`);
    e.usuario = true; e.detalhes = [];
    throw e;
  }
  if (!cClassTrib.startsWith(CST)) {
    const e = new Error(`O cClassTrib ${cClassTrib} deve começar pelos 3 dígitos do CST (${CST}).`);
    e.usuario = true; e.detalhes = [];
    throw e;
  }
  if (!so(entrada.servico?.cNBS)) {
    const e = new Error('Com IBS/CBS a NBS do serviço é obrigatória (regra E0322). Informe a NBS de 9 dígitos.');
    e.usuario = true; e.detalhes = [];
    throw e;
  }
  const indFinal = ['0', '1'].includes(String(v('indFinal'))) ? String(v('indFinal')) : '';
  const regApIBSCBSSN = ['1', '2', '3'].includes(String(v('regApIBSCBSSN'))) && ['2', '3'].includes(String(empresa.opSimpNac)) ? String(v('regApIBSCBSSN')) : '';
  const cAtvSN = ATIVIDADES_SN[v('cAtvSN')] && ['2', '3'].includes(String(empresa.opSimpNac)) ? String(v('cAtvSN')) : '';
  return {
    CST, cClassTrib, ...(cIndOp ? { cIndOp } : {}), ...(indFinal ? { indFinal } : {}), indDest: '0', inicio, modo,
    ...(empresa.ibscbs?.perfil ? { perfil: empresa.ibscbs.perfil } : {}),
    ...(regApIBSCBSSN ? { regApIBSCBSSN } : {}), ...(cAtvSN ? { cAtvSN } : {}),
  };
}

/** Grupo IBSCBS no formato de domínio da open-nfse (leiaute NT 004). */
export function ibscbsNt004(g) {
  return {
    finNFSe: '0',
    ...(g.indFinal ? { indFinal: g.indFinal } : {}),
    cIndOp: g.cIndOp,
    indDest: g.indDest ?? '0',
    valores: { trib: { gIBSCBS: { CST: g.CST, cClassTrib: g.cClassTrib } } },
  };
}

/** Grupo IBSCBS em XML no leiaute da NT 009 (CST e cClassTrib sobem para `trib`). */
export function ibscbsNt009Xml(g) {
  return '<IBSCBS>'
    + (g.indFinal ? `<indFinal>${g.indFinal}</indFinal>` : '')
    + (g.cIndOp ? `<cIndOp>${g.cIndOp}</cIndOp>` : '')
    + `<indDest>${g.indDest ?? '0'}</indDest>`
    + `<valores><trib><CST>${g.CST}</CST><cClassTrib>${g.cClassTrib}</cClassTrib></trib></valores>`
    + '</IBSCBS>';
}

// ---------------------------------------------------------------------------
// Conversão NT 004 → NT 009 (DPS ainda sem assinatura)
// ---------------------------------------------------------------------------
export function paraNt009(xml, ibscbs) {
  let x = xml;
  // 1) finNFSe passa para a raiz de infDPS, logo após tpEmit / cMotivoEmisTI.
  if (!/<infDPS[^>]*>[\s\S]*<finNFSe>[\s\S]*<\/cLocEmi>/.test(x)) {
    x = /<\/cMotivoEmisTI>/.test(x)
      ? x.replace('</cMotivoEmisTI>', '</cMotivoEmisTI><finNFSe>0</finNFSe>')
      : x.replace('</tpEmit>', '</tpEmit><finNFSe>0</finNFSe>');
  }
  // 2) xDescServ passa a ser o último campo de cServ.
  x = x.replace(/<cServ>([\s\S]*?)<\/cServ>/, (_, dentro) => {
    const desc = dentro.match(/<xDescServ>[\s\S]*?<\/xDescServ>/)?.[0] ?? '';
    return `<cServ>${dentro.replace(desc, '')}${desc}</cServ>`;
  });
  // 3) Campos do Simples (regApIBSCBSSN, cAtvSN): só quando o XSD em uso já os tiver.
  if (ibscbs && xsdTemCamposSimples()) {
    if (ibscbs.regApIBSCBSSN) {
      x = /<\/regApTribSN>/.test(x)
        ? x.replace('</regApTribSN>', `</regApTribSN><regApIBSCBSSN>${ibscbs.regApIBSCBSSN}</regApIBSCBSSN>`)
        : x.replace('</opSimpNac>', `</opSimpNac><regApIBSCBSSN>${ibscbs.regApIBSCBSSN}</regApIBSCBSSN>`);
    }
    if (ibscbs.cAtvSN) x = x.replace('<xDescServ>', `<cAtvSN>${ibscbs.cAtvSN}</cAtvSN><xDescServ>`);
  }
  // 4) Grupo IBSCBS (o da NT 004, se existir, é trocado pelo novo).
  x = x.replace(/<IBSCBS>[\s\S]*?<\/IBSCBS>/, '');
  if (ibscbs) x = x.replace('</infDPS>', `${ibscbsNt009Xml(ibscbs)}</infDPS>`);
  return x;
}

// ---------------------------------------------------------------------------
// Validação XSD
// ---------------------------------------------------------------------------
const DIR_NT009 = path.join(path.dirname(fileURLToPath(import.meta.url)), 'xsd', 'nt009-prodrest-20261020');
let esquemas009;
function carregar009() {
  esquemas009 ??= readdirSync(DIR_NT009).filter((f) => f.endsWith('.xsd'))
    .map((f) => ({ fileName: f, contents: readFileSync(path.join(DIR_NT009, f), 'utf8') }));
  return esquemas009;
}

/** O XSD da NT 009 em uso já traz os campos do Simples (release seguinte)? */
export const xsdTemCamposSimples = () => carregar009().some((e) => e.contents.includes('regApIBSCBSSN'));

export async function validarDps(xml, leiaute) {
  if (leiaute === 'nt004') return validateDpsXml(xml);
  const { validateXML } = await import('xmllint-wasm');
  const todos = carregar009();
  const principal = todos.find((s) => s.fileName === 'DPS_v1.01.xsd');
  const out = await validateXML({
    xml: [{ fileName: 'dps.xml', contents: xml }],
    schema: [principal],
    preload: todos.filter((s) => s !== principal),
  });
  if (out.valid) return undefined;
  throw new XsdValidationError(out.errors.map((e) => ({ message: e.message ?? e.rawMessage, line: e.loc?.lineNumber })));
}

// ---------------------------------------------------------------------------
// Leitura tolerante de NFS-e (a open-nfse só lê o leiaute da NT 004)
// ---------------------------------------------------------------------------
/** Converte a parte IBS/CBS de uma NFS-e NT 009 para o formato que o leitor da lib aceita. */
export function paraLeitura004(xml) {
  let x = xml;
  const i = x.indexOf('<infDPS');
  if (i < 0) return x;
  let dps = x.slice(i);
  dps = dps.replace(/<finNFSe>\d<\/finNFSe>(?=[\s\S]*<cLocEmi>)/, '');
  dps = dps.replace(/<IBSCBS>(?!<finNFSe>)/, '<IBSCBS><finNFSe>0</finNFSe>');
  if (/<IBSCBS>/.test(dps) && !/<IBSCBS>[\s\S]*?<cIndOp>/.test(dps)) {
    dps = dps.replace(/(<IBSCBS><finNFSe>0<\/finNFSe>(?:<indFinal>\d<\/indFinal>)?)/, '$1<cIndOp>000000</cIndOp>');
  }
  dps = dps.replace(/<trib><CST>(\d{3})<\/CST><cClassTrib>(\d{6})<\/cClassTrib>(?:<gIBSCBS>([\s\S]*?)<\/gIBSCBS>)?<\/trib>/,
    (_, cst, ct, dentro = '') => `<trib><gIBSCBS><CST>${cst}</CST><cClassTrib>${ct}</cClassTrib>${dentro}</gIBSCBS></trib>`);
  return x.slice(0, i) + dps;
}
export const semIbsCbs = (xml) => xml.replace(/<IBSCBS>[\s\S]*?<\/IBSCBS>/g, '');

/** Extrai do XML os campos de IBS/CBS usados no DANFSe, em qualquer leiaute. */
export function ibscbsDeXml(xml = '') {
  const i = xml.indexOf('<infDPS');
  const nf = i > 0 ? xml.slice(0, i) : '';
  const dps = i > 0 ? xml.slice(i) : xml;
  const grupoNf = nf.match(/<IBSCBS>[\s\S]*<\/IBSCBS>/)?.[0] ?? '';
  const grupoDps = dps.match(/<IBSCBS>[\s\S]*?<\/IBSCBS>/)?.[0] ?? '';
  if (!grupoNf && !grupoDps) return null;
  const g = (fonte, t) => fonte.match(new RegExp(`<${t}>([^<]*)</${t}>`))?.[1];
  const r = {};
  for (const t of ['CST', 'cClassTrib', 'cIndOp', 'indFinal']) r[t] = g(grupoDps, t);
  if (r.cIndOp === '000000') delete r.cIndOp;
  for (const t of ['cLocalidadeIncid', 'xLocalidadeIncid', 'pRedutor', 'vBC', 'pIBSUF', 'pRedAliqUF', 'pAliqEfetUF', 'pIBSMun', 'pRedAliqMun', 'pAliqEfetMun',
    'pCBS', 'pRedAliqCBS', 'pAliqEfetCBS', 'vTotNF', 'vIBSUF', 'vIBSMun', 'vIBSTot', 'vCBS', 'pIBSSN', 'vIBSSN', 'pCBSSN', 'vCBSSN']) r[t] = g(grupoNf, t);
  for (const k of Object.keys(r)) if (r[k] === undefined) delete r[k];
  return r;
}

/** parseNfseXml que não quebra com o leiaute novo. */
export function lerNfse(parse, xml) {
  try { return parse(xml); } catch (e1) {
    try { return parse(paraLeitura004(xml)); } catch {
      try { return parse(semIbsCbs(xml)); } catch { throw e1; }
    }
  }
}
