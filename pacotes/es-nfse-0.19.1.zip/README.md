# ES NFS-e — v0.5.4

Emissor de **NFS-e Padrão Nacional** para o escritório: várias empresas clientes, cada uma com seu certificado A1, emitindo direto na API oficial da Receita (SEFIN Nacional). Roda **só no seu computador**, com a tela no navegador.

Motor fiscal: [open-nfse](https://github.com/fm-s/open-nfse) 0.11.1 (MIT), com a versão fixada. Ele cuida de montar a DPS, validar no XSD (RTC v1.01), assinar, enviar via mTLS e gerar o DANFSe.

## Instalação (Windows)

1. Envie para o computador (seu ou do cliente) o arquivo **`Instalar ES NFS-e.cmd`**, que fica em <https://github.com/ESFinancas/es-nfse-releases>.
2. Dois cliques nele. O programa é instalado em `%LOCALAPPDATA%\ESNFSe`, sem pedir administrador. Se faltar, o Node.js é baixado em versão portátil.
3. O atalho **ES NFS-e** aparece na Área de Trabalho e no Menu Iniciar e abre o sistema em janela própria.
4. No primeiro acesso, crie a conta de administrador com e-mail e senha.

**Atualizações:** toda vez que o atalho é aberto, o sistema consulta o GitHub. Se houver versão nova, ele baixa e troca o programa antes de abrir. A pasta `dados` (empresas, certificados, notas e numeração da DPS) fica separada do programa e nunca é apagada nem substituída.

**Publicar uma versão** (escritório): ajuste a versão em `package.json`/`src/versao.js`, descreva no `CHANGELOG.md` e rode `scripts/publicar-release.sh`. Ele envia o pacote e o `latest.json` para o repositório de releases.

## Desenvolvimento

`npm install` e depois `npm start` (ou `iniciar.bat`), e abra `http://localhost:3737`.

## Ambientes (por empresa)

| Ambiente | O que acontece |
|---|---|
| Simulação | Nada sai do computador. Gera nota e DANFSe fictícios. |
| Produção Restrita | Homologação oficial da Receita. Precisa do A1 e a nota não tem valor fiscal. |
| Produção | Nota com valor fiscal. Pede confirmação ao ativar e a cada emissão. |

Caminho recomendado: Simulação → Produção Restrita (emitir 2 ou 3 notas reais de teste) → Produção.

## O que o sistema faz

- **Multiempresa**: cada cliente tem regime (MEI, ME/EPP, não optante), série, numeração da DPS, ambiente e certificado A1 próprios.
- **Emissão** com prévia do XML assinado (valida no XSD sem enviar) e DANFSe em PDF + XML.
- **Pré-preenchimento**:
  - ao abrir a tela, serviço e valores vêm da última nota emitida pela empresa;
  - ao informar ou buscar um tomador que já tem nota, tudo vem da **última nota daquele tomador**;
  - o botão **Repetir última nota** traz também o tomador;
  - no histórico, **Usar como modelo** em qualquer nota.
- **Dados da Receita automáticos**: digitou o CNPJ (da empresa ou do tomador) ou carregou o A1, o sistema traz razão social, município/IBGE, regime e endereço (BrasilAPI + ViaCEP; precisa de internet).
- **Cadastro de tomadores** (salvos automaticamente ao emitir) e **serviços favoritos**.
- **Importação do Portal Nacional**: no Histórico, o botão "Importar do Portal Nacional" traz todas as NFS-e da empresa (emitidas e recebidas) desde a primeira, inclusive as feitas no portal do governo, e aplica os cancelamentos. Nas próximas vezes busca só o que for novo.
- **Substituição de nota** pelo Histórico, com motivo; a original é cancelada automaticamente pelo Sistema Nacional.
- **Liberação de acesso**: por CNPJ, com vencimento, controlada só no computador do escritório (tela Licenças → Publicar). Sem liberação, a empresa fica travada (só o cadastro de Empresas abre).
- **Contas e login**: e-mail e senha. A primeira conta é administradora e cadastra a equipe na tela Usuários. Num cliente, ele próprio cria a conta ao instalar.
- **Histórico** com filtro por período, busca e situação, e totais de faturamento e ISS.
- **Pendências**: se a Receita não responder, a DPS assinada fica guardada e é reenviada a cada 3 minutos, sem risco de duplicar.

## Segurança

- O servidor escuta só em `127.0.0.1`, então outro computador da rede não acessa.
- O certificado e a senha ficam cifrados (AES-256-GCM) em `dados/certificados/`. A chave-mestra fica em `dados/.chave-mestra`. Para mais segurança, defina a variável `ES_NFSE_CHAVE` (64 caracteres hex) e apague esse arquivo.
- **Faça backup da pasta `dados/`**: ela guarda os XML autorizados, o histórico e a numeração da DPS.

## Regras fiscais aplicadas

- Série da DPS entre 1 e 49999, que é a faixa de aplicativo próprio. O Emissor Web usa de 70000 a 79999, então a numeração não colide com notas emitidas no portal.
- `tpAmb` = 1 só em Produção. A biblioteca usaria 2 (homologação) por padrão.
- MEI não informa alíquota de ISS (regra E0600) e usa `indTotTrib`. ME/EPP informa `pTotTribSN`. Não optante informa `pTotTrib` federal/estadual/municipal.
- Rejeição da Receita consome o número da DPS e fica registrada no histórico. Erro de validação local não consome número.
- Desde 01/11/2026, as ME/EPP do Simples emitem obrigatoriamente pelo Emissor Nacional, seja pela web ou por API (Resolução CGSN nº 191/2026).

## Testes

```
npm test
```

Os testes validam no XSD oficial e assinam DPS de ME/EPP, MEI e não optante com um certificado de teste, sem acessar a rede.

## Estrutura

```
src/server.js   rotas HTTP e tradução de erros
src/nfse.js     integração open-nfse: clientes, contador DPS, pendências, DANFSe
src/cofre.js    cifragem do certificado A1
src/db.js       armazenamento em JSON com escrita atômica
src/auth.js     contas, senhas (scrypt) e sessões
instalador/     instalador, iniciador com atualização automática e atalho
scripts/        publicação de versões no GitHub
public/         interface (HTML/CSS/JS puros)
dados/          criado na primeira execução (não versionar)
```

## Limitações conhecidas (próximas versões)

- Cancelamento simples (sem substituta) ainda não está na tela.
- O DANFSe local ainda não segue o novo leiaute multitributo da NT 008/2026, que está no roadmap da open-nfse.
- Os grupos IBS/CBS não são preenchidos. A ausência deles é tolerada até 31/12/2026, e o Simples só destaca a partir de 2027.
- Não há serviços com dedução/redução, obra, evento ou exterior.
