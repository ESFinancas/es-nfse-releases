﻿# Iniciador do ES NFS-e: verifica atualização, sobe o servidor e abre a janela.
. (Join-Path $PSScriptRoot 'comum.ps1')
Set-Location $Base
try {
  try {
    $rel = Ultima-Release
    if (Versao-Maior $rel.Versao (Versao-Instalada)) {
      Baixar-E-Instalar-App $rel
      Criar-Atalhos
    }
  } catch {
    Registrar "Sem verificação de atualização: $($_.Exception.Message)"
  }
  $node = Node-Exe
  if (-not $node) { $node = Instalar-Node }
  Iniciar-Servidor $node
  Abrir-Janela
} catch {
  Registrar "ERRO: $($_.Exception.Message)"
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show("Não foi possível iniciar o ES NFS-e.`n`n$($_.Exception.Message)`n`nDetalhes em $Log", 'ES NFS-e') | Out-Null
}
