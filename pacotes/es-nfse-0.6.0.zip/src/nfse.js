// Integração com a biblioteca open-nfse: um cliente por empresa/ambiente,
// contador de DPS e fila de pendentes persistidos em disco.
import { promises as fs } from 'node:fs';
import path from 'node:path';
import {
  Ambiente,
  NfseClient,
  OpcaoSimplesNacional,
  ReceitaRejectionError,
  TipoAmbienteDps,
  buildDps,
  parseNfseXml,
  parsePfx,
} from 'open-nfse';
import { NfseClientFake } from 'open-nfse/testing';
import * as db from './db.js';
import { lerCertificado } from './cofre.js';
import { VERSAO } from './versao.js';
import { gerarDanfsePdf } from './danfse.js';

export const AMBIENTES = {
  simulacao: 'Simulação (sem envio)',
  producao_restrita: 'Produção Restrita (homologação)',
  producao: 'Produção (nota com valor fiscal)',
};

const VER_APLIC = `ES-NFSe-${VERSAO}`; // máx. 20 caracteres (TSVerAplic)
const DIR_XML = () => path.join(db.DATA_DIR, 'xml');
const escopo = (empresa) => `${empresa.id}:${empresa.ambiente}`;

// ---------------------------------------------------------------------------
// Contador de DPS (série 00001–49999 = aplicativo próprio; o Emissor Web usa
// 70000+, então não há colisão com notas emitidas pelo portal).
// ---------------------------------------------------------------------------
const chaveContador = (empresa) => `${escopo(empresa)}:${empresa.serie}`;

export async function proximoNDps(empresa) {
  return (await db.mapaObter('_contadores', chaveContador(empresa))) ?? Number(empresa.nDpsInicial ?? 1);
}

function consumirNDps(empresa) {
  let usado;
  return db
    .mapaAtualizar('_contadores', chaveContador(empresa), (atual) => {
      usado = atual ?? Number(empresa.nDpsInicial ?? 1);
      return usado + 1;
    })
    .then(() => String(usado));
}

const contadorPara = (empresa) => ({ next: () => consumirNDps(empresa) });

// ---------------------------------------------------------------------------
// RetryStore persistente (datas voltam como Date, exigência da lib).
// ---------------------------------------------------------------------------
const DATAS = ['firstAttemptAt', 'lastAttemptAt', 'notBefore'];

function storePara(empresa) {
  const k = escopo(empresa);
  return {
    async save(entrada) {
      await db.mapaAtualizar('_pendentes', k, (lista = []) => [...lista.filter((e) => e.id !== entrada.id), entrada]);
    },
    async list() {
      const lista = (await db.mapaObter('_pendentes', k)) ?? [];
      return lista.map((e) => {
        const r = { ...e };
        for (const d of DATAS) if (r[d]) r[d] = new Date(r[d]);
        return r;
      });
    },
    async delete(id) {
      await db.mapaAtualizar('_pendentes', k, (lista = []) => lista.filter((e) => e.id !== id));
    },
  };
}

// ---------------------------------------------------------------------------
// Clientes
// ---------------------------------------------------------------------------
const clientes = new Map();

export async function validarCertificado(pfx, senha) {
  const cert = parsePfx(pfx, senha); // lança senha errada / vencido / inválido
  return { titular: cert.subject, validade: cert.expiresOn.toISOString() };
}

async function clientePara(empresa) {
  const versao = `${empresa.ambiente}|${empresa.atualizadoEm ?? empresa.criadoEm}`;
  const cache = clientes.get(empresa.id);
  if (cache?.versao === versao) return cache.cliente;
  if (cache) await cache.cliente.close?.();

  let cliente;
  if (empresa.ambiente === 'simulacao') {
    cliente = new NfseClientFake();
  } else {
    const certificado = await lerCertificado(empresa.id);
    if (!certificado) throw erroUsuario('Esta empresa não tem certificado A1 cadastrado.');
    cliente = new NfseClient({
      ambiente: empresa.ambiente === 'producao' ? Ambiente.Producao : Ambiente.ProducaoRestrita,
      certificado,
      dpsCounter: contadorPara(empresa),
      retryStore: storePara(empresa),
    });
  }
  clientes.set(empresa.id, { versao, cliente });
  return cliente;
}

export async function fecharClientes() {
  for (const { cliente } of clientes.values()) await cliente.close?.();
  clientes.clear();
}

// ---------------------------------------------------------------------------
// Montagem dos parâmetros
// ---------------------------------------------------------------------------
const so = (s) => String(s ?? '').replace(/\D/g, '');
const num = (v) => (v === '' || v === null || v === undefined ? undefined : Number(String(v).replace(',', '.')));

export function erroUsuario(msg, detalhes = []) {
  const e = new Error(msg);
  e.usuario = true;
  e.detalhes = detalhes;
  return e;
}

function regimeDe(empresa) {
  const r = { opSimpNac: empresa.opSimpNac, regEspTrib: empresa.regEspTrib ?? '0' };
  if (empresa.opSimpNac === OpcaoSimplesNacional.MeEpp) r.regApTribSN = empresa.regApTribSN ?? '1';
  return r;
}

function totTribDe(empresa) {
  if (empresa.opSimpNac === OpcaoSimplesNacional.MeEpp) {
    const p = num(empresa.pTotTribSN);
    if (p === undefined) throw erroUsuario('Informe no cadastro da empresa o % aproximado de tributos do Simples (pTotTribSN).');
    return { pTotTribSN: p };
  }
  if (empresa.opSimpNac === OpcaoSimplesNacional.NaoOptante) {
    return {
      pTotTrib: {
        pTotTribFed: num(empresa.pTotTribFed) ?? 0,
        pTotTribEst: num(empresa.pTotTribEst) ?? 0,
        pTotTribMun: num(empresa.pTotTribMun) ?? 0,
      },
    };
  }
  return {}; // MEI: indTotTrib='0' (default da lib)
}

export function montarParams(empresa, entrada) {
  const { servico = {}, valores = {}, tomador } = entrada;
  const vServ = num(valores.vServ);
  if (!vServ || vServ <= 0) throw erroUsuario('Informe o valor do serviço.');
  if (!servico.cTribNac) throw erroUsuario('Informe o código de tributação nacional do serviço.');
  if (!servico.descricao?.trim()) throw erroUsuario('Descreva o serviço prestado.');

  const params = {
    emitente: {
      cnpj: so(empresa.cnpj),
      codMunicipio: so(empresa.codMunicipio),
      ...(empresa.inscricaoMunicipal ? { inscricaoMunicipal: empresa.inscricaoMunicipal } : {}),
      regime: regimeDe(empresa),
    },
    serie: String(empresa.serie ?? '1'),
    tpAmb: empresa.ambiente === 'producao' ? TipoAmbienteDps.Producao : TipoAmbienteDps.Homologacao,
    dCompet: entrada.dataCompetencia ? new Date(`${entrada.dataCompetencia}T12:00:00-03:00`) : new Date(),
    verAplic: VER_APLIC,
    servico: {
      cTribNac: so(servico.cTribNac),
      descricao: servico.descricao.trim(),
      ...(so(servico.cNBS) ? { cNBS: so(servico.cNBS) } : {}),
      ...(servico.cTribMun ? { cTribMun: String(servico.cTribMun) } : {}),
      ...(so(servico.codMunicipioPrestacao) ? { codMunicipioPrestacao: so(servico.codMunicipioPrestacao) } : {}),
    },
    valores: {
      vServ,
      // MEI não informa alíquota de ISS (regra E0600).
      ...(num(valores.aliqIss) !== undefined && empresa.opSimpNac !== OpcaoSimplesNacional.Mei
        ? { aliqIss: num(valores.aliqIss) }
        : {}),
      tpRetISSQN: valores.tpRetISSQN ?? '1',
      ...totTribDe(empresa),
    },
  };

  if (tomador && so(tomador.documento)) {
    const doc = so(tomador.documento);
    const end = tomador.endereco;
    params.tomador = {
      documento: doc.length === 11 ? { CPF: doc } : { CNPJ: doc },
      nome: String(tomador.nome ?? '').trim(),
      ...(tomador.email ? { email: tomador.email.trim() } : {}),
      ...(so(tomador.fone) ? { fone: so(tomador.fone) } : {}),
      ...(tomador.inscricaoMunicipal ? { inscricaoMunicipal: tomador.inscricaoMunicipal } : {}),
      ...(end && so(end.cep)
        ? {
            endereco: {
              codMunicipio: so(end.codMunicipio),
              cep: so(end.cep),
              logradouro: end.logradouro,
              numero: end.numero || 'S/N',
              bairro: end.bairro,
              ...(end.complemento ? { complemento: end.complemento } : {}),
            },
          }
        : {}),
    };
    if (!params.tomador.nome) throw erroUsuario('Informe o nome do tomador.');
  }
  return params;
}

// ---------------------------------------------------------------------------
// Registro das notas
// ---------------------------------------------------------------------------
async function salvarXml(chave, xml) {
  await fs.mkdir(DIR_XML(), { recursive: true });
  await fs.writeFile(path.join(DIR_XML(), `${chave}.xml`), xml);
}

export async function lerXml(chave) {
  return fs.readFile(path.join(DIR_XML(), `${path.basename(chave)}.xml`), 'utf8');
}

function resumo(nfse) {
  const inf = nfse.infNFSe;
  const dps = inf.DPS.infDPS;
  const toma = dps.toma;
  return {
    chaveAcesso: inf.chaveAcesso,
    numero: inf.nNFSe,
    dhProc: new Date(inf.dhProc).toISOString(),
    serie: dps.serie,
    nDPS: dps.nDPS,
    competencia: new Date(dps.dCompet).toISOString().slice(0, 10),
    tomadorDoc: toma ? (toma.identificador.CNPJ ?? toma.identificador.CPF ?? '') : '',
    tomadorNome: toma?.xNome ?? 'Tomador não identificado',
    descricao: dps.serv.cServ.xDescServ,
    cTribNac: dps.serv.cServ.cTribNac,
    vServ: dps.valores.vServPrest.vServ,
    vLiq: inf.valores.vLiq,
    vISSQN: inf.valores.vISSQN ?? null,
    pAliq: inf.valores.pAliqAplic ?? dps.valores.trib?.tribMun?.pAliq ?? null,
  };
}

async function registrarAutorizada(empresa, emissao, entrada, extra = {}) {
  await salvarXml(emissao.chaveAcesso, emissao.xmlNfse);
  if (empresa.ambiente === 'simulacao') {
    // XML do simulador é sintético; guarda o objeto para gerar o DANFSe de teste.
    await fs.writeFile(path.join(DIR_XML(), `${emissao.chaveAcesso}.json`), JSON.stringify(emissao.nfse));
  }
  const dados = {
    empresaId: empresa.id,
    ambiente: empresa.ambiente,
    status: 'autorizada',
    origem: 'sistema',
    papel: 'emitida',
    idDps: emissao.idDps,
    alertas: (emissao.alertas ?? []).map((a) => `[${a.codigo}] ${a.descricao}`),
    entrada,
    ...extra,
    ...resumo(emissao.nfse),
  };
  const pendente = (await db.listar('notas', (n) => n.idDps === emissao.idDps && n.status === 'pendente'))[0];
  return pendente ? db.atualizar('notas', pendente.id, dados) : db.inserir('notas', dados);
}

async function salvarTomadorSeNovo(empresa, tomador) {
  const doc = so(tomador?.documento);
  if (!doc) return;
  const existe = await db.listar('tomadores', (t) => t.empresaId === empresa.id && so(t.documento) === doc);
  const dados = { empresaId: empresa.id, ...tomador, documento: doc };
  if (existe.length) await db.atualizar('tomadores', existe[0].id, dados);
  else await db.inserir('tomadores', dados);
}

// ---------------------------------------------------------------------------
// Emissão
// ---------------------------------------------------------------------------
export async function emitir(empresa, entrada, { previa = false } = {}) {
  const params = montarParams(empresa, entrada);
  const cliente = await clientePara(empresa);

  if (previa) {
    const r = await cliente.emitir({ ...params, nDPS: String(await proximoNDps(empresa)), dryRun: true });
    return { previa: true, xmlDps: r.xmlDpsAssinado };
  }

  try {
    const r =
      empresa.ambiente === 'simulacao'
        ? await cliente.emitir({ ...params, nDPS: await consumirNDps(empresa) })
        : await cliente.emitir(params);

    if (entrada.salvarTomador) await salvarTomadorSeNovo(empresa, entrada.tomador);

    if (r.status === 'retry_pending') {
      const nota = await db.inserir('notas', {
        empresaId: empresa.id,
        ambiente: empresa.ambiente,
        status: 'pendente',
        idDps: r.pending.idDps,
        nDPS: r.pending.nDPS,
        serie: r.pending.serie,
        tomadorNome: params.tomador?.nome ?? 'Tomador não identificado',
        tomadorDoc: so(entrada.tomador?.documento),
        descricao: params.servico.descricao,
        vServ: params.valores.vServ,
        erro: r.error.message,
        entrada,
      });
      return { status: 'pendente', nota };
    }
    return { status: 'autorizada', nota: await registrarAutorizada(empresa, r.nfse, entrada) };
  } catch (err) {
    if (err instanceof ReceitaRejectionError) {
      const mensagens = err.mensagens.map((m) => `[${m.codigo}] ${m.descricao}${m.complemento ? ` — ${m.complemento}` : ''}`);
      const nota = await db.inserir('notas', {
        empresaId: empresa.id,
        ambiente: empresa.ambiente,
        status: 'rejeitada',
        idDps: err.idDps ?? null,
        tomadorNome: params.tomador?.nome ?? 'Tomador não identificado',
        tomadorDoc: so(entrada.tomador?.documento),
        descricao: params.servico.descricao,
        vServ: params.valores.vServ,
        erro: mensagens.join(' | '),
        entrada,
      });
      return { status: 'rejeitada', nota, mensagens };
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Importação do Portal Nacional (distribuição por NSU no ADN)
// ---------------------------------------------------------------------------
const EVENTOS_CANCELAM = new Set([
  'CANCELAMENTO',
  'CANCELAMENTO_POR_SUBSTITUICAO',
  'CANCELAMENTO_DEFERIDO_ANALISE_FISCAL',
  'CANCELAMENTO_POR_OFICIO',
]);

const docDe = (ident = {}) => ident.CNPJ ?? ident.CPF ?? '';

/** Reconstrói os dados de preenchimento a partir de uma NFS-e (para "usar como modelo"). */
function entradaDeNfse(nfse) {
  const dps = nfse.infNFSe.DPS.infDPS;
  const toma = dps.toma;
  const end = toma?.end;
  const endNac = end?.localidade?.endNac;
  const trib = dps.valores.trib?.tribMun ?? {};
  return {
    dataCompetencia: new Date(dps.dCompet).toISOString().slice(0, 10),
    tomador: toma ? {
      documento: docDe(toma.identificador),
      nome: toma.xNome,
      email: toma.email ?? '',
      fone: toma.fone ?? '',
      inscricaoMunicipal: toma.IM ?? '',
      ...(endNac ? { endereco: {
        cep: endNac.CEP, codMunicipio: endNac.cMun, logradouro: end.xLgr, numero: end.nro,
        bairro: end.xBairro, complemento: end.xCpl ?? '',
      } } : {}),
    } : null,
    servico: {
      cTribNac: dps.serv.cServ.cTribNac,
      cNBS: dps.serv.cServ.cNBS ?? '',
      cTribMun: dps.serv.cServ.cTribMun ?? '',
      descricao: dps.serv.cServ.xDescServ,
      codMunicipioPrestacao: dps.serv.locPrest?.cLocPrestacao ?? '',
    },
    valores: {
      vServ: dps.valores.vServPrest.vServ,
      aliqIss: trib.pAliq ?? '',
      tpRetISSQN: trib.tpRetISSQN ?? '1',
    },
  };
}

async function importarNfse(empresa, doc, placar) {
  const nfse = parseNfseXml(doc.xmlDocumento);
  const inf = nfse.infNFSe;
  const chave = inf.chaveAcesso;
  const existentes = await db.listar('notas', (n) => n.chaveAcesso === chave && n.empresaId === empresa.id);
  if (existentes.length) { placar.jaExistiam++; return; }

  const emitida = docDe(inf.emit.identificador) === empresa.cnpj;
  const canceladas = (await db.mapaObter('_canceladas', escopo(empresa))) ?? [];
  await salvarXml(chave, doc.xmlDocumento);
  await db.inserir('notas', {
    empresaId: empresa.id,
    ambiente: empresa.ambiente,
    origem: 'portal',
    papel: emitida ? 'emitida' : 'recebida',
    status: canceladas.includes(chave) ? 'cancelada' : 'autorizada',
    idDps: inf.DPS.infDPS.Id,
    nsu: doc.nsu,
    alertas: [],
    ...(emitida ? { entrada: entradaDeNfse(nfse) } : {}),
    ...resumo(nfse),
    // Em nota recebida, a contraparte exibida é o prestador.
    ...(emitida ? {} : { tomadorNome: inf.emit.xNome, tomadorDoc: docDe(inf.emit.identificador) }),
  });
  if (emitida) placar.emitidas++; else placar.recebidas++;
}

async function registrarCancelamento(empresa, chave, placar) {
  await db.mapaAtualizar('_canceladas', escopo(empresa), (lista = []) => (lista.includes(chave) ? lista : [...lista, chave]));
  const nota = (await db.listar('notas', (n) => n.chaveAcesso === chave && n.empresaId === empresa.id))[0];
  if (nota && nota.status !== 'cancelada') {
    await db.atualizar('notas', nota.id, { status: 'cancelada' });
    placar.canceladas++;
  }
}

/**
 * Busca no Ambiente de Dados Nacional todas as NFS-e em que a empresa é
 * prestadora ou tomadora, a partir do último NSU lido (0 na primeira vez).
 * Processa até `maxPaginas` lotes por chamada; `concluido` indica se zerou a fila.
 */
export async function sincronizarPortal(empresa, { maxPaginas = 25 } = {}) {
  if (empresa.ambiente === 'simulacao') throw erroUsuario('No modo Simulação não há portal para consultar. Use Produção ou Produção Restrita.');
  const cliente = await clientePara(empresa);
  const k = escopo(empresa);
  let ultimoNsu = Number((await db.mapaObter('_nsu', k)) ?? 0);
  const placar = { emitidas: 0, recebidas: 0, canceladas: 0, jaExistiam: 0, ignorados: 0, concluido: false };

  for (let pagina = 0; pagina < maxPaginas; pagina++) {
    // Desde a v1.1 da API do ADN (nov/2026), a consulta sem `cnpjConsulta` volta
    // REJEICAO sem mensagem; informando o próprio CNPJ ela funciona (TipoConsulta=CnpjBase).
    const r = await cliente.fetchByNsu({ ultimoNsu, ...(empresa.cnpj.length === 14 ? { cnpjConsulta: empresa.cnpj } : { }) });
    if (r.status === 'REJEICAO') {
      const msgs = [...r.erros, ...r.alertas].map((e) => `[${e.codigo}] ${e.descricao}${e.complemento ? ` — ${e.complemento}` : ''}`);
      throw erroUsuario('O Portal Nacional recusou a consulta.', msgs.length ? msgs : [`NSU ${ultimoNsu}: rejeição sem mensagem — use o diagnóstico do Portal (Empresas → Diagnóstico).`]);
    }
    for (const doc of r.documentos) {
      try {
        if (doc.tipoDocumento === 'NFSE') await importarNfse(empresa, doc, placar);
        else if (doc.tipoDocumento === 'EVENTO' && EVENTOS_CANCELAM.has(doc.tipoEvento)) await registrarCancelamento(empresa, doc.chaveAcesso, placar);
        else placar.ignorados++;
      } catch (err) {
        placar.ignorados++;
        console.error(`NSU ${doc.nsu} não importado:`, err.message);
      }
    }
    await db.mapaAtualizar('_nsu', k, () => r.ultimoNsu);
    if (r.status === 'NENHUM_DOCUMENTO_LOCALIZADO' || r.ultimoNsu === ultimoNsu) { placar.concluido = true; break; }
    ultimoNsu = r.ultimoNsu;
  }
  placar.ultimoNsu = Number((await db.mapaObter('_nsu', k)) ?? 0);
  return placar;
}

// ---------------------------------------------------------------------------
// Substituição (nova DPS com <subst>; o Sistema Nacional cancela a original
// com o evento 105102 de forma atômica)
// ---------------------------------------------------------------------------
export const MOTIVOS_SUBSTITUICAO = {
  '01': 'Desenquadramento do Simples Nacional',
  '02': 'Enquadramento no Simples Nacional',
  '03': 'Inclusão retroativa de imunidade/isenção',
  '04': 'Exclusão retroativa de imunidade/isenção',
  '05': 'Rejeição pelo tomador/intermediário',
  '99': 'Outros',
};

export async function substituir(empresa, original, entrada, { cMotivo, xMotivo }) {
  if (!original?.chaveAcesso || original.status !== 'autorizada' || (original.papel ?? 'emitida') !== 'emitida') {
    throw erroUsuario('Só é possível substituir uma NFS-e emitida e autorizada.');
  }
  if (!MOTIVOS_SUBSTITUICAO[cMotivo]) throw erroUsuario('Escolha o motivo da substituição.');
  const motivo = String(xMotivo ?? '').trim();
  if (cMotivo === '99' && motivo.length < 15) throw erroUsuario('Descreva o motivo da substituição (mínimo de 15 caracteres).');

  const params = montarParams(empresa, entrada);
  const cliente = await clientePara(empresa);
  const nDPS = await consumirNDps(empresa);
  const novaDps = buildDps({ ...params, nDPS });
  const vinculo = { substituiChave: original.chaveAcesso, substituiNumero: original.numero, motivoSubstituicao: `${MOTIVOS_SUBSTITUICAO[cMotivo]}${motivo ? ` — ${motivo}` : ''}` };

  try {
    const r = await cliente.substituir({ chaveOriginal: original.chaveAcesso, novaDps, cMotivo, ...(motivo ? { xMotivo: motivo } : {}) });
    if (r.status === 'retry_pending') {
      const nota = await db.inserir('notas', {
        empresaId: empresa.id, ambiente: empresa.ambiente, status: 'pendente', origem: 'sistema', papel: 'emitida',
        idDps: r.pending.idDps, nDPS, serie: params.serie,
        tomadorNome: params.tomador?.nome ?? 'Tomador não identificado', tomadorDoc: so(entrada.tomador?.documento),
        descricao: params.servico.descricao, vServ: params.valores.vServ, erro: r.error.message, entrada, ...vinculo,
      });
      return { status: 'pendente', nota };
    }
    const nova = await registrarAutorizada(empresa, r.novaNfse, entrada, vinculo);
    await db.atualizar('notas', original.id, { status: 'substituida', substituidaPor: nova.chaveAcesso, substituidaPorNumero: nova.numero });
    return { status: 'autorizada', nota: nova, substituida: original.numero };
  } catch (err) {
    if (err instanceof ReceitaRejectionError) {
      const mensagens = err.mensagens.map((m) => `[${m.codigo}] ${m.descricao}${m.complemento ? ` — ${m.complemento}` : ''}`);
      return { status: 'rejeitada', mensagens, nota: { erro: mensagens.join(' | ') } };
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Cancelamento simples (evento 101101)
// ---------------------------------------------------------------------------
export const MOTIVOS_CANCELAMENTO = {
  '1': 'Erro na emissão',
  '2': 'Serviço não prestado',
  '9': 'Outros',
};

export async function cancelar(empresa, nota, { cMotivo, xMotivo }) {
  if (!nota?.chaveAcesso || nota.status !== 'autorizada' || (nota.papel ?? 'emitida') !== 'emitida') {
    throw erroUsuario('Só é possível cancelar uma NFS-e emitida e autorizada.');
  }
  if (nota.ambiente !== empresa.ambiente) throw erroUsuario('Esta nota é de outro ambiente que não o atual da empresa.');
  if (!MOTIVOS_CANCELAMENTO[cMotivo]) throw erroUsuario('Escolha o motivo do cancelamento.');
  const motivo = String(xMotivo ?? '').trim();
  if (motivo.length < 15) throw erroUsuario('Descreva o motivo do cancelamento (mínimo de 15 caracteres).');

  const cliente = await clientePara(empresa);
  try {
    const r = await cliente.cancelar({
      chaveAcesso: nota.chaveAcesso, autor: { CNPJ: empresa.cnpj }, cMotivo, xMotivo: motivo,
      tpAmb: empresa.ambiente === 'producao' ? TipoAmbienteDps.Producao : TipoAmbienteDps.Homologacao, verAplic: VER_APLIC,
    });
    const dados = { motivoCancelamento: `${MOTIVOS_CANCELAMENTO[cMotivo]} — ${motivo}` };
    if (r.status === 'retry_pending') {
      await db.atualizar('notas', nota.id, { ...dados, cancelamentoPendente: true });
      return { status: 'pendente', mensagem: 'A Receita não respondeu. O pedido ficou guardado e será reenviado automaticamente.' };
    }
    await marcarCancelada(empresa, nota, dados, r.evento);
    return { status: 'cancelada', numero: nota.numero };
  } catch (err) {
    if (err instanceof ReceitaRejectionError) {
      const mensagens = err.mensagens.map((m) => `[${m.codigo}] ${m.descricao}${m.complemento ? ` — ${m.complemento}` : ''}`);
      return { status: 'rejeitada', mensagens };
    }
    throw err;
  }
}

async function marcarCancelada(empresa, nota, dados = {}, evento) {
  if (evento?.xmlEvento) {
    await fs.mkdir(path.join(db.DATA_DIR, 'xml'), { recursive: true });
    await fs.writeFile(path.join(db.DATA_DIR, 'xml', `${nota.chaveAcesso}-cancelamento.xml`), evento.xmlEvento);
  }
  await db.mapaAtualizar('_canceladas', escopo(empresa), (lista = []) => (lista.includes(nota.chaveAcesso) ? lista : [...lista, nota.chaveAcesso]));
  await db.atualizar('notas', nota.id, { ...dados, status: 'cancelada', cancelamentoPendente: false, canceladaEm: new Date().toISOString() });
}

/** Reenvia emissões pendentes (falha de rede/instabilidade da Receita). */
export async function reprocessarPendentes() {
  const empresas = await db.listar('empresas', (e) => e.ambiente !== 'simulacao');
  const resultado = [];
  for (const empresa of empresas) {
    const pend = (await db.mapaObter('_pendentes', escopo(empresa))) ?? [];
    if (!pend.length) continue;
    const cliente = await clientePara(empresa);
    for (const item of await cliente.replayPendingEvents()) {
      if (item.status === 'success') {
        const nota = (await db.listar('notas', (n) => n.cancelamentoPendente && n.chaveAcesso && item.id.includes(n.chaveAcesso)))[0];
        if (nota) await marcarCancelada(empresa, nota, {}, item.evento);
      } else if (item.status === 'success_emission') {
        const nota = (await db.listar('notas', (n) => n.idDps === item.emission.idDps))[0];
        const nova = await registrarAutorizada(empresa, item.emission, nota?.entrada);
        if (nota?.substituiChave) {
          const original = (await db.listar('notas', (n) => n.chaveAcesso === nota.substituiChave))[0];
          if (original) await db.atualizar('notas', original.id, { status: 'substituida', substituidaPor: nova.chaveAcesso, substituidaPorNumero: nova.numero });
        }
      } else if (item.status === 'failed_permanent') {
        const nota = (await db.listar('notas', (n) => n.status === 'pendente' && item.id.endsWith(n.idDps)))[0];
        if (nota) await db.atualizar('notas', nota.id, { status: 'rejeitada', erro: item.error.message });
      }
      resultado.push({ empresa: empresa.razaoSocial, status: item.status });
    }
  }
  return resultado;
}

export async function danfsePdf(nota) {
  let nfse;
  if (nota.ambiente === 'simulacao') {
    const data = (_k, v) => (typeof v === 'string' && /^\d{4}-\d\d-\d\dT/.test(v) ? new Date(v) : v);
    nfse = JSON.parse(await fs.readFile(path.join(DIR_XML(), `${path.basename(nota.chaveAcesso)}.json`), 'utf8'), data);
  } else {
    nfse = parseNfseXml(await lerXml(nota.chaveAcesso));
  }
  return gerarDanfsePdf(nfse, {
    ambiente: nota.ambiente,
    situacao: ['cancelada', 'substituida'].includes(nota.status) ? nota.status : undefined,
    ...(nota.ambiente === 'simulacao' ? { observacoes: 'DOCUMENTO DE SIMULAÇÃO — SEM VALOR FISCAL' } : {}),
  });
}

/** Uso exclusivo dos testes: injeta um cliente (ex.: NfseClientFake) para a empresa. */
export function _injetarCliente(empresa, cliente) {
  clientes.set(empresa.id, { versao: `${empresa.ambiente}|${empresa.atualizadoEm ?? empresa.criadoEm}`, cliente });
}

/**
 * Diagnóstico: chama o ADN direto (mTLS com o A1 da empresa) e devolve a
 * resposta crua de GET /DFe/{nsu}, para entender rejeições sem mensagem.
 */
export async function diagnosticoAdn(empresa, nsus = [0, 1], consulta = '') {
  const { Agent, request } = await import('undici');
  const cert = await lerCertificado(empresa.id);
  if (!cert) throw erroUsuario('Empresa sem certificado A1.');
  const a1 = parsePfx(cert.pfx, cert.password);
  const agente = new Agent({ allowH2: false, connect: { key: a1.keyPem, cert: a1.certPem, ALPNProtocols: ['http/1.1'] } });
  const base = empresa.ambiente === 'producao' ? 'https://adn.nfse.gov.br/contribuintes' : 'https://adn.producaorestrita.nfse.gov.br/contribuintes';
  const saida = { ambiente: empresa.ambiente, base, certificado: a1.subject, respostas: [] };
  try {
    for (const nsu of nsus) {
      try {
        const r = await request(`${base}/DFe/${nsu}${consulta ? `?${consulta}` : ''}`, { dispatcher: agente, headers: { accept: 'application/json' } });
        const texto = await r.body.text();
        saida.respostas.push({ nsu, http: r.statusCode, corpo: texto.slice(0, 4000) });
      } catch (err) {
        saida.respostas.push({ nsu, falha: `${err.name}: ${err.message}` });
      }
    }
  } finally {
    await agente.close();
  }
  return saida;
}
