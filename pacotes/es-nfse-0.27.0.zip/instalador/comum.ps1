﻿# Funções compartilhadas pelo instalador e pelo iniciador do ES NFS-e (PowerShell 5.1+).
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'

$RepoReleases = 'ESFinancas/es-nfse-releases'
$Base   = Join-Path $env:LOCALAPPDATA 'ESNFSe'
$App    = Join-Path $Base 'app'
$Dados  = Join-Path $Base 'dados'
$NodeDir = Join-Path $Base 'node'
$Log    = Join-Path $Base 'esnfse.log'
$Porta  = 3737
$Url    = "http://localhost:$Porta"     # janela do sistema (origem usada no login Google)
$UrlApi = "http://127.0.0.1:$Porta"     # checagem: o servidor escuta só em IPv4; "localhost" tenta ::1 antes e estoura o tempo

function Registrar([string]$msg) {
  New-Item -ItemType Directory -Force -Path $Base | Out-Null
  Add-Content -Path $Log -Value ("{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), $msg)
}

function Versao-Instalada {
  $pkg = Join-Path $App 'package.json'
  if (-not (Test-Path $pkg)) { return $null }
  return (Get-Content $pkg -Raw | ConvertFrom-Json).version
}

function Ultima-Release {
  # Canal de atualização: latest.json no repositório público de releases.
  $raw = "https://raw.githubusercontent.com/$RepoReleases/main"
  $h = @{ 'User-Agent' = 'ES-NFSe'; 'Cache-Control' = 'no-cache' }
  $r = Invoke-RestMethod -Uri "$raw/latest.json?t=$([DateTime]::UtcNow.Ticks)" -Headers $h -TimeoutSec 8
  return [pscustomobject]@{ Versao = $r.versao; Zip = "$raw/$($r.pacote)" }
}

function Versao-Maior([string]$a, [string]$b) {
  # true se a > b (semver MAJOR.MINOR.PATCH)
  if (-not $b) { return $true }
  return ([version]($a -replace '[^0-9.].*$','')) -gt ([version]($b -replace '[^0-9.].*$',''))
}

function Node-Exe {
  $local = Join-Path $NodeDir 'node.exe'
  if (Test-Path $local) { return $local }
  $cmd = Get-Command node -ErrorAction SilentlyContinue
  if ($cmd) {
    $maior = [int]((& $cmd.Source -v).TrimStart('v').Split('.')[0])
    if ($maior -ge 20) { return $cmd.Source }
  }
  return $null
}

function Instalar-Node {
  Registrar 'Baixando Node.js LTS portátil'
  $idx = Invoke-RestMethod -Uri 'https://nodejs.org/dist/index.json' -TimeoutSec 20
  $v = ($idx | Where-Object { $_.lts -and $_.version -like 'v22.*' } | Select-Object -First 1).version
  $nome = "node-$v-win-x64"
  $zip = Join-Path $env:TEMP "$nome.zip"
  Invoke-WebRequest -Uri "https://nodejs.org/dist/$v/$nome.zip" -OutFile $zip -UseBasicParsing
  $tmp = Join-Path $env:TEMP "esnfse-node-$([guid]::NewGuid())"
  Expand-Archive -Path $zip -DestinationPath $tmp -Force
  if (Test-Path $NodeDir) { Remove-Item $NodeDir -Recurse -Force }
  Move-Item (Join-Path $tmp $nome) $NodeDir
  Remove-Item $zip, $tmp -Recurse -Force -ErrorAction SilentlyContinue
  return (Join-Path $NodeDir 'node.exe')
}

function Servidor-Ativo {
  try { Invoke-RestMethod -Uri "$UrlApi/api/sistema" -TimeoutSec 3 -UseBasicParsing | Out-Null; return $true } catch { return $false }
}

function Parar-Servidor {
  # Encerra o servidor pelo PID salvo e, por garantia, quem estiver ouvindo a porta.
  $pidArq = Join-Path $Base 'servidor.pid'
  if (Test-Path $pidArq) {
    Stop-Process -Id ([int](Get-Content $pidArq)) -Force -ErrorAction SilentlyContinue
    Remove-Item $pidArq -Force -ErrorAction SilentlyContinue
  }
  try {
    Get-NetTCPConnection -LocalPort $Porta -State Listen -ErrorAction Stop |
      ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
  } catch { }
  Start-Sleep -Milliseconds 800
}

function Baixar-Arquivo([string]$url, [string]$destino, [scriptblock]$aoProgresso) {
  # Download em blocos, avisando o percentual (para a janela de progresso).
  $req = [System.Net.HttpWebRequest]::Create($url)
  $req.UserAgent = 'ES-NFSe'
  $req.Timeout = 30000
  $resp = $req.GetResponse()
  try {
    $total = $resp.ContentLength
    $entrada = $resp.GetResponseStream()
    $saida = [System.IO.File]::Create($destino)
    try {
      $buf = New-Object byte[] 65536
      $lido = 0
      $ultimo = -1
      while (($n = $entrada.Read($buf, 0, $buf.Length)) -gt 0) {
        $saida.Write($buf, 0, $n)
        $lido += $n
        if ($aoProgresso -and $total -gt 0) {
          $pct = [int](100 * $lido / $total)
          if ($pct -ne $ultimo) { $ultimo = $pct; try { & $aoProgresso $pct } catch { } }
        }
      }
    } finally { $saida.Close(); $entrada.Close() }
  } finally { $resp.Close() }
}

function Baixar-E-Instalar-App($release, [scriptblock]$aoProgresso = $null) {
  Registrar "Instalando versão $($release.Versao)"
  $zip = Join-Path $env:TEMP "es-nfse-$($release.Versao).zip"
  if ($aoProgresso) { Baixar-Arquivo $release.Zip $zip $aoProgresso }
  else { Invoke-WebRequest -Uri $release.Zip -OutFile $zip -UseBasicParsing }
  if ($aoProgresso) { try { & $aoProgresso -1 } catch { } }
  $novo = Join-Path $Base 'app-novo'
  if (Test-Path $novo) { Remove-Item $novo -Recurse -Force }
  Expand-Archive -Path $zip -DestinationPath $novo -Force
  if (-not (Test-Path (Join-Path $novo 'src\server.js'))) { throw 'Pacote de atualização inválido' }
  Parar-Servidor
  # Qualquer node.exe que ainda esteja rodando o sistema (janela antiga, servidor órfão) segura os arquivos.
  Get-Process -Name node -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -like "$Base*" } |
    ForEach-Object { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }
  $antigo = Join-Path $Base 'app-anterior'
  # O Windows (antivírus, indexação) pode segurar arquivos por alguns segundos: tenta de novo antes de desistir.
  $trocou = $false
  for ($i = 1; $i -le 15 -and -not $trocou; $i++) {
    try {
      if (Test-Path $antigo) { Remove-Item $antigo -Recurse -Force -ErrorAction Stop }
      if (Test-Path $App) { Rename-Item $App 'app-anterior' -ErrorAction Stop }
      Rename-Item $novo 'app' -ErrorAction Stop
      $trocou = $true
    } catch {
      if ((-not (Test-Path $App)) -and (Test-Path $antigo) -and (Test-Path $novo)) {
        try { Rename-Item $novo 'app' -ErrorAction Stop; $trocou = $true; break } catch { }
      }
      Registrar "Arquivos em uso, tentativa $i de 15: $($_.Exception.Message)"
      Start-Sleep -Seconds 1
    }
  }
  if (-not $trocou) {
    if ((-not (Test-Path $App)) -and (Test-Path $antigo)) { Rename-Item $antigo 'app' -ErrorAction SilentlyContinue }
    throw 'Arquivos do sistema em uso; a atualização será feita na próxima abertura.'
  }
  Remove-Item $zip -Force -ErrorAction SilentlyContinue
  Registrar "Versão $($release.Versao) instalada (dados preservados em $Dados)"
}

function Iniciar-Servidor([string]$node) {
  if (Servidor-Ativo) { return }
  $env:ES_NFSE_DADOS = $Dados
  $env:PORTA = "$Porta"
  $p = Start-Process -FilePath $node -ArgumentList 'src\server.js' -WorkingDirectory $App -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput (Join-Path $Base 'servidor.out.log') -RedirectStandardError (Join-Path $Base 'servidor.err.log')
  Set-Content -Path (Join-Path $Base 'servidor.pid') -Value $p.Id
  for ($i = 0; $i -lt 40; $i++) { if (Servidor-Ativo) { return }; Start-Sleep -Milliseconds 250 }
  throw 'O servidor do ES NFS-e não respondeu. Veja servidor.err.log.'
}

function Abrir-Janela {
  $candidatos = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
  )
  $nav = $candidatos | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  if ($nav) {
    $perfil = Join-Path $Base 'janela'
    Start-Process -FilePath $nav -ArgumentList "--app=$Url", "--user-data-dir=`"$perfil`"", '--window-size=1366,900', '--no-first-run'
  } else {
    Start-Process $Url
  }
}

function Criar-Atalhos {
  $icone = Join-Path $App 'public\icone.ico'
  $vbs = Join-Path $App 'instalador\iniciar-oculto.vbs'
  $ws = New-Object -ComObject WScript.Shell
  $destinos = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'ES NFS-e.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) 'ES NFS-e.lnk')
  )
  foreach ($d in $destinos) {
    $s = $ws.CreateShortcut($d)
    $s.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
    $s.Arguments = "`"$vbs`""
    $s.WorkingDirectory = $Base
    $s.IconLocation = "$icone,0"
    $s.Description = 'ES NFS-e — Emissor de NFS-e Padrão Nacional · Everton Sousa Contabilidade'
    $s.Save()
  }
}

function Migrar-Dados-Antigos {
  # Instalação manual anterior em C:\ESNFSe: traz empresas, certificados e notas.
  $antigo = 'C:\ESNFSe\dados'
  if ((Test-Path (Join-Path $antigo 'empresas.json')) -and -not (Test-Path (Join-Path $Dados 'empresas.json'))) {
    New-Item -ItemType Directory -Force -Path $Dados | Out-Null
    Copy-Item -Path (Join-Path $antigo '*') -Destination $Dados -Recurse -Force
    Registrar "Dados migrados de $antigo"
  }
}
