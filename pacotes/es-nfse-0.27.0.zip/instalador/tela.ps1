﻿# Janela de progresso do iniciador ("Verificando atualizações", "Baixando 45%", "Iniciando").
# Carregada dentro de try/catch pelo iniciar.ps1: se algo falhar aqui, o sistema abre sem a janela.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:TelaForm = $null
$script:TelaRotulo = $null
$script:TelaBarra = $null

function Tela-Abrir([string]$texto) {
  $f = New-Object System.Windows.Forms.Form
  $f.Text = 'ES NFS-e'
  $f.Size = New-Object System.Drawing.Size(460, 170)
  $f.StartPosition = 'CenterScreen'
  $f.FormBorderStyle = 'FixedDialog'
  $f.MaximizeBox = $false
  $f.MinimizeBox = $false
  $f.ControlBox = $false
  $f.ShowInTaskbar = $true
  $f.BackColor = [System.Drawing.Color]::FromArgb(15, 42, 68)
  $icone = Join-Path $PSScriptRoot '..\public\icone.ico'
  # Lê o ícone para a memória: abrir o arquivo direto o deixaria preso e impediria trocar a pasta do app.
  if (Test-Path $icone) { try { $f.Icon = New-Object System.Drawing.Icon((New-Object System.IO.MemoryStream(,[System.IO.File]::ReadAllBytes($icone)))) } catch { } }

  $titulo = New-Object System.Windows.Forms.Label
  $titulo.Text = 'ES NFS-e · Everton Sousa Contabilidade'
  $titulo.ForeColor = [System.Drawing.Color]::FromArgb(212, 176, 106)
  $titulo.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
  $titulo.AutoSize = $false
  $titulo.Size = New-Object System.Drawing.Size(420, 26)
  $titulo.Location = New-Object System.Drawing.Point(18, 14)
  $f.Controls.Add($titulo)

  $rot = New-Object System.Windows.Forms.Label
  $rot.Text = $texto
  $rot.ForeColor = [System.Drawing.Color]::White
  $rot.Font = New-Object System.Drawing.Font('Segoe UI', 10)
  $rot.AutoSize = $false
  $rot.Size = New-Object System.Drawing.Size(420, 40)
  $rot.Location = New-Object System.Drawing.Point(18, 44)
  $f.Controls.Add($rot)

  $barra = New-Object System.Windows.Forms.ProgressBar
  $barra.Size = New-Object System.Drawing.Size(410, 18)
  $barra.Location = New-Object System.Drawing.Point(18, 92)
  $barra.Style = 'Marquee'
  $barra.MarqueeAnimationSpeed = 30
  $f.Controls.Add($barra)

  $script:TelaForm = $f
  $script:TelaRotulo = $rot
  $script:TelaBarra = $barra
  $f.Show()
  [System.Windows.Forms.Application]::DoEvents()
}

function Tela-Texto([string]$texto, [int]$pct = -1) {
  if (-not $script:TelaForm) { return }
  $script:TelaRotulo.Text = $texto
  if ($pct -ge 0) {
    $script:TelaBarra.Style = 'Continuous'
    $script:TelaBarra.Value = [Math]::Max(0, [Math]::Min(100, $pct))
  } else {
    $script:TelaBarra.Style = 'Marquee'
  }
  [System.Windows.Forms.Application]::DoEvents()
}

function Tela-Fechar {
  if ($script:TelaForm) {
    $script:TelaForm.Close()
    $script:TelaForm.Dispose()
    $script:TelaForm = $null
  }
}
