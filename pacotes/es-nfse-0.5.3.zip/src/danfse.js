// DANFSe próprio do ES NFS-e (A4), desenhado com medição de texto para que
// nada ultrapasse as caixas. Campos do leiaute nacional (RTC v1.01).
import PDFDocument from 'pdfkit';
import QRCode from 'qrcode';

const M = 28;                    // margem
const W = 595.28 - M * 2;        // largura útil
const AZUL = '#1a3a6b';
const CINZA = '#5d6b7a';
const LINHA = '#9aa6b2';

const moeda = (v) => (v == null || v === '' ? '—' : Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
const pct = (v) => (v == null || v === '' ? '—' : `${Number(v).toLocaleString('pt-BR', { maximumFractionDigits: 4 })}%`);
const data = (d) => (d ? new Date(d).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : '—');
const dataHora = (d) => (d ? new Date(d).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : '—');
const so = (s) => String(s ?? '').replace(/\D/g, '');
function doc(id = {}) {
  const v = id.CNPJ ?? id.CPF ?? id.NIF ?? '';
  const d = so(v);
  if (d.length === 14) return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  if (d.length === 11) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  return v || '—';
}
const cep = (c) => (so(c).length === 8 ? so(c).replace(/(\d{5})(\d{3})/, '$1-$2') : c || '—');
const chaveFmt = (c) => String(c ?? '').replace(/(.{4})/g, '$1 ').trim();
const REGIME = { 1: 'Não optante pelo Simples Nacional', 2: 'MEI — Simples Nacional', 3: 'ME/EPP — Simples Nacional' };
const TRIB = { 1: 'Operação tributável', 2: 'Imunidade', 3: 'Exportação de serviço', 4: 'Não incidência' };
const RET = { 1: 'Não retido', 2: 'Retido pelo tomador', 3: 'Retido pelo intermediário' };

/** Desenha uma linha de células {rotulo, valor, w(fração), negrito?, tam?} e devolve a nova altura. */
function linhaCelulas(pdf, y, celulas, { pad = 5 } = {}) {
  const alturas = celulas.map((c) => {
    const w = W * c.w - pad * 2;
    pdf.font('Helvetica-Bold').fontSize(c.tam ?? 9);
    const hv = pdf.heightOfString(String(c.valor ?? '—'), { width: w });
    return 9 + hv;
  });
  const h = Math.max(...alturas) + pad * 2 - 2;
  let x = M;
  for (const c of celulas) {
    const w = W * c.w;
    pdf.font('Helvetica').fontSize(6.5).fillColor(CINZA).text(c.rotulo.toUpperCase(), x + pad, y + pad - 1, { width: w - pad * 2, lineBreak: false, ellipsis: true });
    pdf.font(c.negrito ? 'Helvetica-Bold' : 'Helvetica').fontSize(c.tam ?? 9).fillColor('#111')
      .text(String(c.valor ?? '—'), x + pad, y + pad + 8, { width: w - pad * 2 });
    x += w;
  }
  return y + h;
}

function secao(pdf, y, titulo, linhas) {
  const topo = y;
  pdf.rect(M, y, W, 13).fill('#e9eef4');
  pdf.font('Helvetica-Bold').fontSize(7.5).fillColor(AZUL).text(titulo.toUpperCase(), M + 5, y + 3.5, { width: W - 10, lineBreak: false });
  y += 13;
  for (const l of linhas) y = linhaCelulas(pdf, y, l);
  pdf.lineWidth(0.6).strokeColor(LINHA).rect(M, topo, W, y - topo).stroke();
  return y + 6;
}

function enderecoEmit(e = {}) {
  return [e.xLgr, e.nro, e.xCpl].filter(Boolean).join(', ') || '—';
}
function enderecoToma(end) {
  if (!end) return { linha: '—', cep: '—', mun: '—' };
  const nac = end.localidade?.endNac;
  return { linha: [end.xLgr, end.nro, end.xCpl, end.xBairro].filter(Boolean).join(', '), cep: cep(nac?.CEP), mun: nac?.cMun ?? '—' };
}

/**
 * @param nfse NFSe parseada (open-nfse)
 * @param opts { ambiente: 'producao'|'producao_restrita'|'simulacao', situacao?: 'cancelada'|'substituida', observacoes?: string }
 */
export async function gerarDanfsePdf(nfse, opts = {}) {
  const inf = nfse.infNFSe;
  const dps = inf.DPS.infDPS;
  const emit = inf.emit ?? {};
  const toma = dps.toma;
  const cServ = dps.serv.cServ;
  const tribMun = dps.valores.trib?.tribMun ?? {};
  const totTrib = dps.valores.trib?.totTrib ?? {};
  // Mesmo endereço de consulta pública usado pela biblioteca open-nfse.
  const urlConsulta = `${opts.ambiente === 'producao' ? 'https://adn.nfse.gov.br' : 'https://adn.producaorestrita.nfse.gov.br'}/contribuintes/consulta?chave=${inf.chaveAcesso}`;
  const qr = await QRCode.toBuffer(urlConsulta, { margin: 0, width: 220, errorCorrectionLevel: 'M' });

  const pdf = new PDFDocument({ size: 'A4', margin: M, info: { Title: `DANFSe ${inf.nNFSe} - ${inf.chaveAcesso}`, Producer: 'ES NFS-e' } });
  const partes = [];
  pdf.on('data', (b) => partes.push(b));
  const fim = new Promise((ok) => pdf.on('end', () => ok(Buffer.concat(partes))));

  // ------------------------------------------------------------- cabeçalho
  let y = M;
  const hCab = 92;
  pdf.lineWidth(0.6).strokeColor(LINHA).rect(M, y, W, hCab).stroke();
  pdf.font('Helvetica-Bold').fontSize(15).fillColor(AZUL).text('DANFSe', M + 10, y + 10);
  pdf.font('Helvetica').fontSize(7.5).fillColor(CINZA)
    .text('Documento Auxiliar da Nota Fiscal de Serviço Eletrônica', M + 10, y + 29, { width: 200 })
    .text('Padrão Nacional — nfse.gov.br', M + 10, y + 39, { width: 200 });
  pdf.font('Helvetica').fontSize(6.5).fillColor(CINZA).text('NÚMERO DA NFS-e', M + 10, y + 56);
  pdf.font('Helvetica-Bold').fontSize(16).fillColor('#111').text(String(inf.nNFSe), M + 10, y + 64, { width: 200 });

  const xMeio = M + 215;
  const wMeio = W - 215 - 98;
  pdf.font('Helvetica').fontSize(6.5).fillColor(CINZA).text('CHAVE DE ACESSO', xMeio, y + 10);
  pdf.font('Helvetica-Bold').fontSize(8.2).fillColor('#111').text(chaveFmt(inf.chaveAcesso), xMeio, y + 19, { width: wMeio });
  const linhasMeio = [
    ['Emissão da NFS-e', dataHora(inf.dhProc)],
    ['Competência', data(dps.dCompet)],
    ['DPS (série / nº)', `${dps.serie} / ${dps.nDPS}`],
  ];
  let ym = y + 44;
  for (const [r, v] of linhasMeio) {
    pdf.font('Helvetica').fontSize(6.5).fillColor(CINZA).text(r.toUpperCase(), xMeio, ym, { width: 92, lineBreak: false });
    pdf.font('Helvetica').fontSize(8).fillColor('#111').text(v, xMeio + 92, ym - 1, { width: wMeio - 92, lineBreak: false, ellipsis: true });
    ym += 14;
  }
  pdf.image(qr, M + W - 90, y + 8, { width: 80, height: 80 });
  y += hCab + 6;

  // ------------------------------------------------------------- avisos
  const avisos = [];
  if (opts.ambiente !== 'producao') avisos.push(opts.ambiente === 'simulacao' ? 'SIMULAÇÃO — SEM VALOR FISCAL' : 'HOMOLOGAÇÃO (PRODUÇÃO RESTRITA) — SEM VALOR FISCAL');
  if (opts.situacao === 'cancelada') avisos.push('NFS-e CANCELADA');
  if (opts.situacao === 'substituida') avisos.push('NFS-e SUBSTITUÍDA');
  for (const a of avisos) {
    pdf.rect(M, y, W, 16).fill('#fdecea');
    pdf.font('Helvetica-Bold').fontSize(9).fillColor('#b42318').text(a, M, y + 4, { width: W, align: 'center' });
    y += 20;
  }

  // ------------------------------------------------------------- prestador
  const end = emit.enderNac ?? {};
  y = secao(pdf, y, 'Prestador do serviço', [
    [
      { rotulo: 'Nome / razão social', valor: emit.xNome, w: 0.55, negrito: true },
      { rotulo: 'CPF / CNPJ', valor: doc(emit.identificador), w: 0.25 },
      { rotulo: 'Inscrição municipal', valor: emit.IM ?? '—', w: 0.2 },
    ],
    [
      { rotulo: 'Endereço', valor: enderecoEmit(end), w: 0.45 },
      { rotulo: 'Bairro', valor: end.xBairro ?? '—', w: 0.2 },
      { rotulo: 'Município / UF', valor: `${inf.xLocEmi ?? end.cMun ?? '—'}${end.UF ? ` / ${end.UF}` : ''}`, w: 0.23 },
      { rotulo: 'CEP', valor: cep(end.CEP), w: 0.12 },
    ],
    [
      { rotulo: 'Telefone', valor: emit.fone ?? '—', w: 0.25 },
      { rotulo: 'E-mail', valor: emit.email ?? '—', w: 0.4 },
      { rotulo: 'Regime tributário', valor: REGIME[dps.prest?.regTrib?.opSimpNac] ?? '—', w: 0.35 },
    ],
  ]);

  // ------------------------------------------------------------- tomador
  if (toma) {
    const et = enderecoToma(toma.end);
    y = secao(pdf, y, 'Tomador do serviço', [
      [
        { rotulo: 'Nome / razão social', valor: toma.xNome, w: 0.55, negrito: true },
        { rotulo: 'CPF / CNPJ', valor: doc(toma.identificador), w: 0.25 },
        { rotulo: 'Inscrição municipal', valor: toma.IM ?? '—', w: 0.2 },
      ],
      [
        { rotulo: 'Endereço', valor: et.linha || '—', w: 0.55 },
        { rotulo: 'Município (IBGE)', valor: et.mun, w: 0.2 },
        { rotulo: 'CEP', valor: et.cep, w: 0.25 },
      ],
      [
        { rotulo: 'Telefone', valor: toma.fone ?? '—', w: 0.35 },
        { rotulo: 'E-mail', valor: toma.email ?? '—', w: 0.65 },
      ],
    ]);
  } else {
    y = secao(pdf, y, 'Tomador do serviço', [[{ rotulo: 'Identificação', valor: 'Tomador não identificado', w: 1 }]]);
  }

  // ------------------------------------------------------------- serviço
  y = secao(pdf, y, 'Serviço prestado', [
    [
      { rotulo: 'Código de tributação nacional', valor: `${cServ.cTribNac}${inf.xTribNac ? ` — ${inf.xTribNac}` : ''}`, w: 0.62 },
      { rotulo: 'Código NBS', valor: cServ.cNBS ? `${cServ.cNBS}${inf.xNBS ? ` — ${inf.xNBS}` : ''}` : '—', w: 0.38 },
    ],
    [
      { rotulo: 'Local da prestação', valor: inf.xLocPrestacao ?? dps.serv.locPrest?.cLocPrestacao ?? '—', w: 0.34 },
      { rotulo: 'Local de incidência do ISSQN', valor: inf.xLocIncid ?? inf.cLocIncid ?? '—', w: 0.33 },
      { rotulo: 'Código municipal', valor: cServ.cTribMun ?? '—', w: 0.33 },
    ],
    [{ rotulo: 'Discriminação do serviço', valor: cServ.xDescServ, w: 1, tam: 9.5 }],
  ]);

  // ------------------------------------------------------------- valores
  const v = inf.valores ?? {};
  const desc = dps.valores.vDescCondIncond ?? {};
  y = secao(pdf, y, 'Valores e tributação municipal', [
    [
      { rotulo: 'Valor do serviço', valor: moeda(dps.valores.vServPrest.vServ), w: 0.2, negrito: true },
      { rotulo: 'Desconto incondicionado', valor: moeda(desc.vDescIncond), w: 0.2 },
      { rotulo: 'Base de cálculo', valor: moeda(v.vBC), w: 0.2 },
      { rotulo: 'Alíquota ISSQN', valor: pct(v.pAliqAplic ?? tribMun.pAliq), w: 0.2 },
      { rotulo: 'Valor do ISSQN', valor: moeda(v.vISSQN), w: 0.2 },
    ],
    [
      { rotulo: 'Tributação do ISSQN', valor: TRIB[tribMun.tribISSQN] ?? '—', w: 0.3 },
      { rotulo: 'Retenção do ISSQN', valor: RET[tribMun.tpRetISSQN] ?? '—', w: 0.3 },
      { rotulo: 'Total retido', valor: moeda(v.vTotalRet), w: 0.2 },
      { rotulo: 'Valor líquido', valor: moeda(v.vLiq), w: 0.2, negrito: true, tam: 11 },
    ],
  ]);

  // ------------------------------------------------------------- tributos aproximados + observações
  let tribTexto = '—';
  if (totTrib.pTotTribSN != null) tribTexto = `Simples Nacional: ${pct(totTrib.pTotTribSN)} (alíquota aproximada)`;
  else if (totTrib.pTotTrib) tribTexto = `Federais ${pct(totTrib.pTotTrib.pTotTribFed)} · Estaduais ${pct(totTrib.pTotTrib.pTotTribEst)} · Municipais ${pct(totTrib.pTotTrib.pTotTribMun)}`;
  else if (totTrib.vTotTrib) tribTexto = `Federais ${moeda(totTrib.vTotTrib.vTotTribFed)} · Estaduais ${moeda(totTrib.vTotTrib.vTotTribEst)} · Municipais ${moeda(totTrib.vTotTrib.vTotTribMun)}`;
  else if (totTrib.indTotTrib != null) tribTexto = 'Não informado (MEI)';
  const obs = [dps.serv.infoCompl?.xInfComp, inf.xOutInf, opts.observacoes].filter(Boolean).join('\n') || '—';
  y = secao(pdf, y, 'Informações complementares', [
    [{ rotulo: 'Valor aproximado dos tributos (Lei 12.741/2012)', valor: tribTexto, w: 1 }],
    [{ rotulo: 'Observações', valor: obs, w: 1 }],
  ]);

  // ------------------------------------------------------------- autenticidade
  const hAut = 46;
  if (y + hAut > 841.89 - M - 14) { pdf.addPage(); y = M; }
  pdf.lineWidth(0.6).strokeColor(LINHA).rect(M, y, W, hAut).stroke();
  pdf.font('Helvetica-Bold').fontSize(7.5).fillColor(AZUL).text('CONSULTA DE AUTENTICIDADE', M + 6, y + 6);
  pdf.font('Helvetica').fontSize(7.5).fillColor('#111')
    .text('Leia o QR Code do cabeçalho ou consulte a chave de acesso no portal da NFS-e:', M + 6, y + 17, { width: W - 12 });
  pdf.fillColor('#1d5a6e').text(urlConsulta, M + 6, y + 28, { width: W - 12, link: urlConsulta, lineBreak: false, ellipsis: true });
  y += hAut;

  pdf.page.margins.bottom = 0; // rodapé fora da margem, sem criar página nova
  pdf.font('Helvetica').fontSize(6.5).fillColor(CINZA)
    .text(`Gerado pelo ES NFS-e em ${dataHora(new Date())} a partir do XML oficial da NFS-e.`, M, 841.89 - M - 8, { width: W, align: 'center', lineBreak: false });

  pdf.end();
  return fim;
}
