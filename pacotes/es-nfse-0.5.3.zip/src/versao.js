// Versionamento semântico do ES NFS-e (MAJOR.MINOR.PATCH).
export const VERSAO = '0.5.3';
