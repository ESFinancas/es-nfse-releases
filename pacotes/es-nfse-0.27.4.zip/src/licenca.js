// Liberação de acesso por CNPJ emitente.
//
// O administrador (só o computador que tem a chave privada em dados/.licenca-admin.key)
// mantém a lista e publica `licencas.json`, assinado com Ed25519, no repositório
// público de releases. Cada instalação baixa a lista ao abrir e a cada 6 horas,
// confere a assinatura com a chave pública abaixo e libera ou trava cada empresa.
// Os CNPJs vão embaralhados (hash), para a lista de clientes não ficar legível.
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { existsSync, promises as fs, readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import * as db from './db.js';

export const CHAVE_PUBLICA = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAGFXbBV4gKlYvWjvGqXz56QbVZJtUk0hnGb+SnUFlzjI=
-----END PUBLIC KEY-----`;
export const REPO_RELEASES = 'ESFinancas/es-nfse-releases';
const URL_LICENCAS = () => process.env.ES_NFSE_URL_LICENCAS ?? `https://raw.githubusercontent.com/${REPO_RELEASES}/main/licencas.json`;
const TOLERANCIA_OFFLINE_MS = 7 * 24 * 60 * 60 * 1000;
export const DIAS_AVISO = 5;

const so = (s) => String(s ?? '').replace(/\D/g, '');
export const hashCnpj = (cnpj) => crypto.createHash('sha256').update(`es-nfse:licenca:${so(cnpj)}`).digest('hex');

/** JSON com chaves em ordem: é exatamente o que se assina e o que se confere. */
export function canonico(v) {
  if (Array.isArray(v)) return `[${v.map(canonico).join(',')}]`;
  if (v && typeof v === 'object') return `{${Object.keys(v).sort().map((k) => `${JSON.stringify(k)}:${canonico(v[k])}`).join(',')}}`;
  return JSON.stringify(v);
}

export function assinaturaValida(arquivo, chavePublica = CHAVE_PUBLICA) {
  try {
    if (!arquivo?.conteudo || typeof arquivo.assinatura !== 'string') return false;
    return crypto.verify(null, Buffer.from(canonico(arquivo.conteudo)), chavePublica, Buffer.from(arquivo.assinatura, 'base64'));
  } catch { return false; }
}

export const hojeBrasil = (d = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo' }).format(d);
const diasEntre = (de, ate) => Math.round((new Date(`${ate}T12:00:00Z`) - new Date(`${de}T12:00:00Z`)) / 86400000);

// ---------------------------------------------------------------------------
// Administrador
// ---------------------------------------------------------------------------
const arqChave = () => path.join(db.DATA_DIR, '.licenca-admin.key');
let chavePublicaAdmin = CHAVE_PUBLICA;
let cacheAdmin = null;
/** Só para testes automatizados: troca a chave pública de referência do administrador. */
export function __chavePublicaTeste(pem) { chavePublicaAdmin = pem ?? CHAVE_PUBLICA; cacheAdmin = null; }
export function limparCacheAdmin() { cacheAdmin = null; }
/** Administrador = existe a chave privada E ela corresponde à chave pública oficial (um arquivo qualquer não basta). */
export function ehAdmin() {
  const arq = arqChave();
  if (!existsSync(arq)) { cacheAdmin = null; return false; }
  let st;
  try { st = statSync(arq); } catch { return false; }
  const marca = `${st.size}:${st.mtimeMs}:${chavePublicaAdmin.length}`;
  if (cacheAdmin?.marca === marca) return cacheAdmin.ok;
  let ok = false;
  try {
    const pub = crypto.createPublicKey(crypto.createPrivateKey(readFileSync(arq, 'utf8'))).export({ type: 'spki', format: 'der' });
    ok = pub.equals(crypto.createPublicKey(chavePublicaAdmin).export({ type: 'spki', format: 'der' }));
  } catch { ok = false; }
  cacheAdmin = { marca, ok };
  return ok;
}

// ---------------------------------------------------------------------------
// Instalações (clientes): baixar, conferir e decidir
// ---------------------------------------------------------------------------
export async function atualizarLista({ buscar = fetch } = {}) {
  try {
    const ctrl = AbortSignal.timeout(15000);
    const r = await buscar(`${URL_LICENCAS()}?t=${Date.now()}`, { signal: ctrl, headers: { 'Cache-Control': 'no-cache' } });
    await registrarHoraServidor(r.headers?.get?.('date'));
    if (r.status === 404) {
      await db.mapaAtualizar('_config', 'licencas', (a = {}) => ({ naoPublicado: true, baixadoEm: Date.now(), dataServidor: a.dataServidor }));
      return { ok: true, naoPublicado: true };
    }
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const arquivo = await r.json();
    if (!assinaturaValida(arquivo)) throw new Error('assinatura inválida');
    const atual = await db.mapaObter('_config', 'licencas');
    // nunca volta para uma lista mais antiga que a guardada
    if (atual?.arquivo && atual.arquivo.conteudo.emitidoEm > arquivo.conteudo.emitidoEm) {
      await db.mapaAtualizar('_config', 'licencas', (a) => ({ ...a, baixadoEm: Date.now() }));
      return { ok: true };
    }
    await db.mapaAtualizar('_config', 'licencas', (a = {}) => ({ arquivo, baixadoEm: Date.now(), dataServidor: a.dataServidor }));
    return { ok: true };
  } catch (err) {
    return { ok: false, erro: err.message };
  }
}

function statusDe(e, agora) {
  if (e.bloqueado) return { status: 'bloqueado', bloqueia: true, mensagem: 'O acesso desta empresa está suspenso.' };
  const hoje = hojeBrasil(agora);
  const dias = diasEntre(hoje, e.ate);
  const br = e.ate.split('-').reverse().join('/');
  if (e.teste) {
    if (dias < 0) return { status: 'vencido', teste: true, bloqueia: true, ate: e.ate, mensagem: `O período de teste terminou em ${br}. Para continuar usando, fale com o escritório e contrate um plano.` };
    return { status: 'teste', teste: true, bloqueia: false, ate: e.ate, dias, mensagem: `Período de teste: ${dias === 0 ? 'termina hoje' : `faltam ${dias} dia${dias > 1 ? 's' : ''}`} (até ${br}).` };
  }
  if (dias < 0) return { status: 'vencido', bloqueia: true, ate: e.ate, mensagem: `A liberação desta empresa venceu em ${br}.` };
  if (dias <= DIAS_AVISO) return { status: 'vencendo', bloqueia: false, ate: e.ate, dias, mensagem: `A liberação desta empresa vence ${dias === 0 ? 'hoje' : `em ${dias} dia${dias > 1 ? 's' : ''}`} (${br}).` };
  return { status: 'liberado', bloqueia: false, ate: e.ate };
}
const excluidaStatus = (e) => {
  const fim = new Date(fimQuarentena(e)).toISOString().slice(0, 10).split('-').reverse().join('/');
  return { status: 'excluida', bloqueia: true, liberaVagaEm: new Date(fimQuarentena(e)).toISOString(), mensagem: `Empresa excluída; a vaga fica ocupada até ${fim}.` };
};
const NAO_LIBERADO = { status: 'nao_liberado', bloqueia: true, mensagem: 'Esta empresa ainda não foi liberada para usar o ES NFS-e.' };

// ---------------------------------------------------------------------------
// Relógio confiável: a data do servidor do GitHub (cabeçalho Date) vista na última
// consulta. Adiantar o relógio do Windows não libera vaga; atrasar não estica prazo.
// ---------------------------------------------------------------------------
async function registrarHoraServidor(cabecalho) {
  const t = Date.parse(cabecalho ?? '');
  if (!Number.isFinite(t)) return;
  await db.mapaAtualizar('_config', 'relogio', (a = {}) => ({ servidor: Math.max(a.servidor ?? 0, t), localNaLeitura: Date.now() }));
}
/** Agora "confiável": nunca antes da última data vista no servidor (nem da lista publicada). */
export async function agoraConfiavel(local = Date.now()) {
  const r = (await db.mapaObter('_config', 'relogio')) ?? {};
  const c = await db.mapaObter('_config', 'licencas');
  const emitida = Date.parse(c?.arquivo?.conteudo?.emitidoEm ?? '') || 0;
  return Math.max(local, r.servidor ?? 0, emitida);
}
/** Agora para LIBERAR vagas: só conta o tempo comprovado pelo servidor (o relógio local não adianta). */
async function agoraParaLiberar() {
  const r = (await db.mapaObter('_config', 'relogio')) ?? {};
  const c = await db.mapaObter('_config', 'licencas');
  const emitida = Date.parse(c?.arquivo?.conteudo?.emitidoEm ?? '') || 0;
  const servidor = Math.max(r.servidor ?? 0, emitida);
  return servidor || Date.now();
}

// ---------------------------------------------------------------------------
// Exclusão com quarentena: a empresa excluída ocupa a vaga por 30 dias
// ---------------------------------------------------------------------------
export const QUARENTENA_DIAS = 30;
const QUARENTENA_MS = QUARENTENA_DIAS * 24 * 60 * 60 * 1000;
export const ativa = (e) => !e.excluidaEm;
export const fimQuarentena = (e) => Date.parse(e.excluidaEm) + QUARENTENA_MS;

/**
 * Avalia a instalação inteira. A versão sai da lista publicada:
 *  - admin: computador com a chave do administrador (tudo liberado);
 *  - contador: alguma empresa cadastrada é um CNPJ liberado como "contador"; ela é a titular e
 *    as demais empresas (clientes do contador) seguem a liberação dela até o limite contratado;
 *  - cliente: cada empresa precisa da própria liberação ("cliente").
 *  - livre: nenhuma lista publicada ainda (nada é travado).
 */
export async function avaliar(empresasTodas, agoraLocal = new Date()) {
  const agora = new Date(await agoraConfiavel(agoraLocal.getTime()));
  const liberarAte = await agoraParaLiberar();
  // excluídas há mais de 30 dias (pelo relógio do servidor) já não contam
  const empresas = empresasTodas.filter((e) => ativa(e) || fimQuarentena(e) > liberarAte);
  const ordenadas = [...empresas].sort((a, b) => String(a.criadoEm ?? '').localeCompare(String(b.criadoEm ?? '')));
  const por = new Map();
  const todas = (s) => { for (const e of ordenadas) por.set(e.id, s); };
  if (ehAdmin()) { todas({ status: 'liberado', admin: true, bloqueia: false }); return { edicao: 'admin', porEmpresa: por }; }
  const c = await db.mapaObter('_config', 'licencas');
  if (c?.naoPublicado) { todas({ status: 'liberado', bloqueia: false }); return { edicao: 'livre', porEmpresa: por }; }
  if (!c?.arquivo || agora.getTime() - (c.baixadoEm ?? 0) > TOLERANCIA_OFFLINE_MS) {
    todas({ status: 'sem_verificacao', bloqueia: true, mensagem: 'Não foi possível confirmar a liberação de acesso. Conecte o computador à internet e abra o sistema de novo.' });
    return { edicao: 'sem_verificacao', porEmpresa: por };
  }
  const lista = c.arquivo.conteudo.cnpjs ?? {};
  const ent = (cnpj) => lista[hashCnpj(cnpj)];
  const titular = ordenadas.find((e) => ent(e.cnpj)?.perfil === 'contador');
  if (titular) {
    const et = ent(titular.cnpj);
    const base = statusDe(et, agora);
    const limite = Number(et.limite ?? 0);
    let usados = 0;
    let quarentena = 0;
    for (const e of ordenadas) {
      if (e.id === titular.id) { por.set(e.id, { ...base, titular: true }); continue; }
      const proprio = ent(e.cnpj);
      if (proprio && ativa(e)) { por.set(e.id, statusDe(proprio, agora)); continue; }
      if (proprio) continue;
      usados += 1;
      if (!ativa(e)) { quarentena += 1; por.set(e.id, excluidaStatus(e)); continue; }
      por.set(e.id, usados <= limite ? { ...base, viaContador: true }
        : { status: 'limite', bloqueia: true, mensagem: `Limite de ${limite} empresa(s) da licença do escritório atingido.` });
    }
    return { edicao: 'contador', titular: titular.cnpj, limite, usados, quarentena, porEmpresa: por };
  }
  for (const e of ordenadas) por.set(e.id, !ativa(e) ? excluidaStatus(e) : ent(e.cnpj) ? statusDe(ent(e.cnpj), agora) : NAO_LIBERADO);
  return { edicao: 'cliente', porEmpresa: por };
}

/** Situação de um CNPJ considerando as empresas desta instalação. */
export async function situacao(cnpj, agora = new Date()) {
  const empresas = await db.listar('empresas');
  let alvo = empresas.find((e) => so(e.cnpj) === so(cnpj));
  const lista = alvo ? empresas : [...empresas, (alvo = { id: '__consulta__', cnpj: so(cnpj), criadoEm: '9999' })];
  return (await avaliar(lista, agora)).porEmpresa.get(alvo.id);
}

/** Resumo da versão desta instalação (para a interface). */
export async function instalacao() {
  const empresas = await db.listar('empresas');
  const r = await avaliar(empresas);
  return { edicao: r.edicao, titular: r.titular ?? null, limite: r.limite ?? null, usados: r.usados ?? null, quarentena: r.quarentena ?? 0, total: empresas.filter(ativa).length };
}

/** Exclui a empresa: no computador do administrador apaga; nos demais, guarda 30 dias ocupando a vaga. */
export async function excluirEmpresa(empresa, { apagarCertificado }) {
  const inst = await instalacao();
  if (inst.edicao === 'contador' && so(empresa.cnpj) === so(inst.titular)) {
    throw Object.assign(new Error('A empresa do escritório (titular da licença) não pode ser excluída.'), { usuario: true, status: 403 });
  }
  if (inst.edicao === 'admin') {
    await apagarCertificado(empresa.id);
    await db.remover('empresas', empresa.id);
    return { apagada: true };
  }
  const agora = new Date(await agoraConfiavel()).toISOString();
  await db.atualizar('empresas', empresa.id, { excluidaEm: agora });
  return { quarentena: true, liberaVagaEm: new Date(Date.parse(agora) + QUARENTENA_MS).toISOString() };
}

export async function restaurarEmpresa(empresa) {
  if (ativa(empresa)) return empresa;
  if (fimQuarentena(empresa) <= await agoraParaLiberar()) throw Object.assign(new Error('O prazo de 30 dias já passou; cadastre a empresa de novo.'), { usuario: true });
  const { excluidaEm: _x, ...resto } = empresa;
  return db.atualizar('empresas', empresa.id, { ...resto, excluidaEm: null });
}

/** Remove de vez as empresas cuja quarentena terminou (pelo relógio do servidor). */
export async function purgarExcluidas({ apagarCertificado }) {
  const limite = await agoraParaLiberar();
  for (const e of await db.listar('empresas', (x) => !ativa(x) && fimQuarentena(x) <= limite)) {
    await apagarCertificado(e.id).catch(() => {});
    for (const col of ['tomadores', 'servicos', 'modelos']) for (const t of await db.listar(col, (y) => y.empresaId === e.id)) await db.remover(col, t.id);
    await db.remover('empresas', e.id);
  }
}

/** Regra de cadastro de nova empresa conforme a versão. */
export async function podeCadastrar(cnpjNovo) {
  const empresas = await db.listar('empresas');
  const r = await avaliar(empresas);
  if (['admin', 'livre'].includes(r.edicao) || !empresas.filter(ativa).length) return;
  if (r.edicao === 'sem_verificacao') {
    throw Object.assign(new Error('Não foi possível confirmar a liberação de acesso. Conecte o computador à internet antes de cadastrar outra empresa.'), { usuario: true, status: 403 });
  }
  const c = await db.mapaObter('_config', 'licencas');
  const propria = c?.arquivo?.conteudo?.cnpjs?.[hashCnpj(cnpjNovo)];
  if (propria) return;
  if (r.edicao === 'contador') {
    if (r.usados >= r.limite) {
      throw Object.assign(new Error(`A licença do escritório permite até ${r.limite} empresa(s) cliente(s) e todas já estão em uso. Fale com o escritório para ampliar o limite.`), { usuario: true, status: 403 });
    }
    return;
  }
  throw Object.assign(new Error('Esta instalação é da versão Cliente: emite somente para o CNPJ liberado. Para emitir para outras empresas, fale com o escritório sobre a versão Contador.'), { usuario: true, status: 403 });
}

export async function exigirLiberada(empresa) {
  if (empresa && !ativa(empresa)) throw Object.assign(new Error('Esta empresa foi excluída.'), { status: 404, usuario: true });
  const s = await situacao(empresa?.cnpj);
  if (s.bloqueia) {
    const e = new Error(`${s.mensagem} Fale com o escritório Everton Sousa Contabilidade.`);
    e.status = 403; e.usuario = true; e.licenca = s;
    throw e;
  }
  return s;
}

// ---------------------------------------------------------------------------
// Painel do administrador: cadastro, montagem, assinatura e publicação
// ---------------------------------------------------------------------------
export async function listarAdmin() {
  return (await db.mapaObter('_config', 'licencasAdmin'))?.lista ?? [];
}

export async function salvarAdmin(item) {
  const cnpj = so(item.cnpj);
  if (cnpj.length !== 14 && cnpj.length !== 11) throw Object.assign(new Error('Informe um CNPJ (ou CPF) válido.'), { usuario: true });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(item.ate ?? ''))) throw Object.assign(new Error('Informe a data de vencimento.'), { usuario: true });
  const registro = {
    cnpj, nome: String(item.nome ?? '').trim().slice(0, 120), ate: item.ate, bloqueado: Boolean(item.bloqueado),
    perfil: item.perfil === 'contador' ? 'contador' : 'cliente',
    ...(item.teste ? { teste: true } : {}),
    ...(item.perfil === 'contador' ? { limite: Math.max(0, Math.min(9999, Number.parseInt(item.limite, 10) || 0)) } : {}),
    obs: String(item.obs ?? '').trim().slice(0, 300), alteradoEm: new Date().toISOString(),
  };
  await db.mapaAtualizar('_config', 'licencasAdmin', (atual = {}) => {
    const lista = (atual.lista ?? []).filter((x) => x.cnpj !== cnpj);
    const testes = { ...(atual.testes ?? {}) };
    if (registro.teste && !testes[cnpj]) testes[cnpj] = new Date().toISOString().slice(0, 10);
    return { ...atual, lista: [...lista, registro].sort((a, b) => a.nome.localeCompare(b.nome)), testes, pendente: true };
  });
  return registro;
}

export async function removerAdmin(cnpj) {
  await db.mapaAtualizar('_config', 'licencasAdmin', (atual = {}) => ({ ...atual, lista: (atual.lista ?? []).filter((x) => x.cnpj !== so(cnpj)), pendente: true }));
}

/** Contato do suporte definido pelo administrador (vai na lista publicada). */
export async function contatoAdmin() {
  return (await db.mapaObter('_config', 'licencasAdmin'))?.contato ?? null;
}
export async function salvarContato({ whatsapp, email, nome }) {
  const c = { whatsapp: so(whatsapp), email: String(email ?? '').trim().toLowerCase(), nome: String(nome ?? '').trim().slice(0, 80) };
  if (c.whatsapp && (c.whatsapp.length < 12 || c.whatsapp.length > 13)) throw Object.assign(new Error('WhatsApp com DDI e DDD, ex.: 55 83 99999-9999.'), { usuario: true });
  if (c.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(c.email)) throw Object.assign(new Error('E-mail inválido.'), { usuario: true });
  await db.mapaAtualizar('_config', 'licencasAdmin', (a = {}) => ({ ...a, contato: c, pendente: true }));
  return c;
}
/** Contato do suporte nesta instalação: o do administrador ou o da última lista válida. */
export async function contatoSuporte() {
  if (ehAdmin()) { const c = await contatoAdmin(); if (c) return c; }
  return (await db.mapaObter('_config', 'licencas'))?.arquivo?.conteudo?.contato ?? null;
}

export async function estadoPublicacao() {
  const a = (await db.mapaObter('_config', 'licencasAdmin')) ?? {};
  return { pendente: Boolean(a.pendente), publicadoEm: a.publicadoEm ?? null, ultimoErro: a.ultimoErro ?? null };
}

/** Monta e assina o arquivo público a partir do cadastro do administrador. */
export async function montarArquivo(lista, chavePrivadaPem, contato) {
  const conteudo = {
    versao: 1,
    emitidoEm: new Date().toISOString(),
    ...(contato && (contato.whatsapp || contato.email) ? { contato: { whatsapp: contato.whatsapp ?? '', email: contato.email ?? '', nome: contato.nome ?? '' } } : {}),
    cnpjs: Object.fromEntries(lista.map((x) => [hashCnpj(x.cnpj), {
      ate: x.ate, ...(x.bloqueado ? { bloqueado: true } : {}), ...(x.teste ? { teste: true } : {}),
      ...(x.perfil === 'contador' ? { perfil: 'contador', limite: Number(x.limite ?? 0) } : {}),
    }])),
  };
  const assinatura = crypto.sign(null, Buffer.from(canonico(conteudo)), chavePrivadaPem).toString('base64');
  return { conteudo, assinatura };
}

function acharGit() {
  const candidatos = ['git'];
  if (process.platform === 'win32') {
    const pf = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Programs')].filter(Boolean);
    for (const base of pf) candidatos.push(path.join(base, 'Git', 'cmd', 'git.exe'));
    const gd = process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'GitHubDesktop');
    if (gd && existsSync(gd)) {
      for (const d of readdirSync(gd).filter((n) => n.startsWith('app-')).sort().reverse()) {
        candidatos.push(path.join(gd, d, 'resources', 'app', 'git', 'cmd', 'git.exe'));
      }
    }
  }
  return candidatos;
}

const rodar = (exe, args, cwd) => new Promise((ok, erro) => {
  execFile(exe, args, { cwd, timeout: 120000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
    if (err) { err.saida = `${stdout}\n${stderr}`.trim(); erro(err); } else ok(stdout);
  });
});

async function gitDisponivel() {
  for (const exe of acharGit()) {
    if (exe !== 'git' && !existsSync(exe)) continue;
    try { await rodar(exe, ['--version']); return exe; } catch { /* tenta o próximo */ }
  }
  return null;
}

/**
 * Publica a lista no repositório de releases usando o Git do computador do
 * administrador (com o login do GitHub já salvo nele).
 */
export async function publicar({ repoUrl = `https://github.com/${REPO_RELEASES}.git`, pasta } = {}) {
  if (!ehAdmin()) throw Object.assign(new Error('Somente o computador do administrador publica liberações.'), { status: 403, usuario: true });
  const git = await gitDisponivel();
  if (!git) throw Object.assign(new Error('Git não encontrado neste computador. Instale o Git for Windows (git-scm.com) e tente de novo.'), { usuario: true });
  const destino = pasta ?? path.join(path.dirname(db.DATA_DIR), 'admin', 'releases');
  const chave = await fs.readFile(arqChave(), 'utf8');
  const lista = await listarAdmin();
  const arquivo = await montarArquivo(lista, chave, await contatoAdmin());
  if (!assinaturaValida(arquivo, crypto.createPublicKey(chave))) throw new Error('Falha ao assinar a lista.');
  try {
    // Até 4 tentativas: se uma atualização do sistema for publicada no mesmo instante, o GitHub recusa
    // o envio ("cannot lock ref" / "fetch first"); aí busca de novo e reenvia.
    for (let tentativa = 1; ; tentativa++) {
      if (!existsSync(path.join(destino, '.git'))) {
        await fs.mkdir(path.dirname(destino), { recursive: true });
        await rodar(git, ['clone', '--depth', '20', repoUrl, destino]);
      } else {
        await rodar(git, ['fetch', 'origin', 'main'], destino);
        await rodar(git, ['reset', '--hard', 'origin/main'], destino);
      }
      await fs.writeFile(path.join(destino, 'licencas.json'), `${JSON.stringify(arquivo, null, 2)}\n`);
      await rodar(git, ['add', 'licencas.json'], destino);
      const status = await rodar(git, ['status', '--porcelain'], destino);
      if (!status.trim()) break;
      await rodar(git, ['-c', 'user.name=ES NFS-e Admin', '-c', 'user.email=admin@es-nfse.local', 'commit', '-m', `Liberações: ${lista.length} CNPJ(s)`], destino);
      try {
        await rodar(git, ['push', 'origin', 'HEAD:main'], destino);
        break;
      } catch (err) {
        const corrida = /cannot lock ref|fetch first|non-fast-forward|rejected/i.test(err.saida ?? err.message ?? '');
        if (!corrida || tentativa >= 4) throw err;
        await new Promise((r) => { setTimeout(r, 2000 * tentativa); });
      }
    }
    await db.mapaAtualizar('_config', 'licencasAdmin', (a = {}) => ({ ...a, pendente: false, publicadoEm: new Date().toISOString(), ultimoErro: null }));
    return { ok: true, total: lista.length };
  } catch (err) {
    const msg = /Authentication|could not read Username|403|denied/i.test(err.saida ?? '')
      ? 'O GitHub recusou o envio: entre com sua conta do GitHub no Git deste computador (o Git pede o login na primeira vez) e tente de novo.'
      : `Falha ao publicar: ${(err.saida || err.message).split('\n').slice(-3).join(' ')}`;
    await db.mapaAtualizar('_config', 'licencasAdmin', (a = {}) => ({ ...a, ultimoErro: msg }));
    throw Object.assign(new Error(msg), { usuario: true });
  }
}

/** Liberação de teste: N dias a partir de hoje, uma vez por CNPJ (o administrador pode repetir conscientemente). */
export const DIAS_TESTE = [7, 15, 30];
export async function liberarTeste({ cnpj, nome, perfil, limite, dias, repetir } = {}) {
  const doc = so(cnpj);
  const d = Number.parseInt(dias, 10);
  if (!DIAS_TESTE.includes(d)) throw Object.assign(new Error('Escolha 7, 15 ou 30 dias de teste.'), { usuario: true });
  const adm = (await db.mapaObter('_config', 'licencasAdmin')) ?? {};
  const atual = (adm.lista ?? []).find((x) => x.cnpj === doc);
  if (atual && !atual.teste && atual.ate >= hojeBrasil()) throw Object.assign(new Error('Este CNPJ já tem uma liberação paga vigente; o teste não substitui.'), { usuario: true });
  const usado = adm.testes?.[doc];
  if (usado && !repetir) throw Object.assign(new Error(`Este CNPJ já teve um teste liberado em ${usado.split('-').reverse().join('/')}.`), { usuario: true, testeRepetido: true, status: 409 });
  const x = new Date(`${hojeBrasil()}T12:00:00Z`); x.setUTCDate(x.getUTCDate() + d);
  return salvarAdmin({ cnpj: doc, nome, perfil, limite: perfil === 'contador' ? (limite ?? 4) : undefined, ate: x.toISOString().slice(0, 10), teste: true, obs: `Teste de ${d} dias` });
}
