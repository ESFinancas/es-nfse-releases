# Changelog

## 0.24.0 — 2026-11-26
- Emissão mais segura:
  - A tela "Emitir nota" abre sempre em branco (a última nota só entra pelo botão "Repetir última nota"
    ou ao escolher o tomador).
  - A nota só é enviada pelo clique em "Emitir NFS-e": a tecla Enter nos campos não envia mais.
  - Confirmação em Produção mostra tomador com CPF/CNPJ, valor, código e descrição do serviço; o foco fica
    em "Cancelar", Enter não confirma e o botão "Emitir nota" só libera após 2 segundos.

## 0.23.1 — 2026-11-26
- Correção: "Cód. municipal" (cTribMun) aceita só 3 dígitos, opcional. Antes um valor como inscrição
  municipal ou CNAE chegava ao validador e aparecia o erro técnico "Schemas validity error … cTribMun".
  Agora o campo limita a 3 dígitos (emissão e serviço favorito) e, se vier um valor inválido de um
  favorito ou nota antiga, a mensagem explica o que é o campo e pede para deixar em branco.
- Erros de leiaute (XSD) passam a citar o nome do campo da tela e o valor informado.

## 0.23.0 — 2026-11-26
- Emissão: **Buscar serviço na Lista Nacional** (338 códigos do Anexo B v1.01) pela atividade ou código.
  Ao escolher, preenche o código de tributação nacional e sugere, pelas tabelas oficiais, a **NBS**, o
  **cIndOp** (Anexo VII v1.03, NT 009) e o **CST/cClassTrib** (Anexo VIII v1.02.00), com opções clicáveis.
  A classificação configurada na empresa nunca é trocada automaticamente; avisa quando ela não consta da
  tabela. Código fora da lista avisa a rejeição E0310.
- Histórico: ações da nota enxutas — Ver PDF, Recibo e menu **⋯ Mais** (baixar PDF/XML, modelo, favorito,
  anexos, substituir, cancelar).
- Celular: filtros do Histórico recolhidos no botão "Filtrar notas".

## 0.22.1 — 2026-11-26
- Recibo: endereço da empresa obrigatório (preenchido do XML da NFS-e), exigido pela Receita para dedução
  de despesas médicas (nome, endereço e CPF/CNPJ de quem recebeu).
- Recibo: sócio administrador (nome e CPF) opcional abaixo da assinatura; CPF mascarado por padrão
  (***.456.789-**), com opção de CPF completo. Dados lembrados por empresa.

## 0.22.0 — 2026-11-26
- **Recibo assinado digitalmente** vinculado à NFS-e (ícone de recibo no Histórico, notas autorizadas):
  - Valor recebido (até o valor da nota), forma e data do pagamento, "referente a", quem assina,
    registro profissional (CRP/CRM etc.), cidade e observação; preferências lembradas por empresa.
  - O PDF cita número, data e chave de acesso da nota, valor por extenso e QR Code da Consulta Pública.
  - Assinatura PAdES (PKCS#7 destacado, SHA-256) com o certificado A1 ICP-Brasil da própria empresa,
    verificável em validar.iti.gov.br; menção ao art. 10, § 1º, da MP 2.200-2/2001.
  - Empresa sem certificado próprio (procuração): recibo sem assinatura digital, com aviso.
  - Marca d'água "SEM VALOR" em simulação e homologação.

## 0.21.0 — 2026-11-26
- Suporte: chamado de **Inconsistência** exige **print da tela** e descrição com pelo menos 30 caracteres
  (o que fez, o que esperava, o que aconteceu). O print é colado com Ctrl+V (Windows + Shift + S),
  arrastado ou escolhido; é convertido para PNG, conferido e guardado com o chamado.
- Ao enviar pelo WhatsApp ou e-mail, o print vai copiado para a área de transferência: basta colar
  (Ctrl+V) na conversa. Reenviar um chamado copia o print de novo. Ícone "Ver o print" na lista.
- Melhoria: print opcional. Lista "Onde" troca "Usuários" por "Backup".

## 0.20.0 — 2026-11-26
- **Backup para todas as versões** (botão Backup na barra lateral):
  - "Fazer backup agora e baixar": .zip com empresas, certificados (protegidos pela chave-mestra), notas,
    XML, cadastros e configurações, com LEIA-ME de restauração.
  - Backup automático semanal na pasta %LOCALAPPDATA%\ESNFSe\backups, guardando os 8 últimos.
  - Restaurar a partir de um .zip, com backup automático do estado atual antes ("antes de restaurar").
    A liberação de acesso e o relógio confiável nunca voltam no tempo com um backup antigo.
- Segurança: a versão Administrador só é reconhecida quando a chave privada corresponde à chave pública
  oficial (antes bastava existir um arquivo com o nome da chave). A chave só entra no backup do administrador.
- Ajuda: tópico "Backup e restauração".

## 0.19.2 — 2026-11-26
- Telas e menus do administrador (Usuários, Licenças, Contratos) marcados como exclusivos: ficam ocultos
  por regra de estilo em qualquer versão que não seja a Administrador, inclusive antes de a versão ser
  identificada (sem piscar ao entrar). Acessar o endereço direto leva para Emitir nota.
- Ajuda dos clientes e contadores sem menção ao painel do administrador ("Sua versão do sistema").

## 0.19.1 — 2026-11-26
- Versões Contador e Cliente sem a aba Equipe/Acessos: o cadastro de usuários fica só na versão
  Administrador (também bloqueado no servidor). Telas de Usuários, Licenças e Contratos redirecionam para
  Emitir nota fora da versão Administrador. "Alterar senha" continua para todos.

## 0.19.0 — 2026-11-26
- Novo módulo **Contratos e cobrança** (só no computador do administrador):
  - Contrato por CNPJ/CPF com plano (Até 5 R$ 57, Até 20 R$ 97, Até 50 R$ 147, Até 100 R$ 257, acima de
    100 sob consulta), implantação (R$ 197), dia de vencimento, carência, início e prazo; numeração CT-AAAA-NNN.
  - O contrato cria e mantém a liberação em Licenças: versão, limite de clientes (o escritório conta como
    uma das empresas do plano), vencimento e bloqueio.
  - Mensalidades com registro e estorno de pagamento (data e forma); cada mensalidade paga em sequência
    libera até o vencimento seguinte + carência. Implantação com controle próprio.
  - Suspender, reativar e encerrar (bloqueia o acesso); excluir só sem pagamentos.
  - Painel com contratos ativos, receita mensal, a receber no mês, em atraso e recebido no mês.
  - Contrato em PDF (licença de uso + implantação e suporte, Lei 9.609/1998 arts. 7º a 9º, LGPD, reajuste
    IPCA, inadimplência e bloqueio, vigência com renovação automática, foro), com os dados da contratada.

## 0.18.0 — 2026-11-26
- Menu próprio para cada versão:
  - Administrador: tudo (Empresas, Usuários, Licenças, configuração de leiaute).
  - Contador: "Clientes do escritório" com quadro de vagas (usadas, livres e em quarentena) e "Equipe";
    sem Licenças e sem configuração de leiaute.
  - Cliente: "Meus clientes" (tomadores), "Minha empresa" (sem excluir) e "Acessos"; sem Licenças,
    procuração ou leiaute.
- Ajuda mostra só os tópicos da versão em uso; novo tópico "Painel de Licenças" para o administrador.
- Configuração de leiaute da DPS restrita ao computador do administrador também no servidor.

## 0.17.1 — 2026-11-26
- Ajuda: novo tópico "Excluir empresa e limite de vagas" (quarentena de 30 dias e restauração).

## 0.17.0 — 2026-11-26
- Segurança da licença (brechas fechadas):
  - Empresa excluída continua ocupando a vaga por 30 dias (fica oculta e travada; pode ser restaurada).
    Recadastrar o mesmo CNPJ nesse prazo volta para a mesma vaga. Depois de 30 dias é removida de vez.
    A empresa do escritório (titular da licença Contador) não pode ser excluída. No computador do
    administrador a exclusão é imediata.
  - Nas versões Cliente e Contador o CNPJ de uma empresa já cadastrada não pode ser trocado.
  - Relógio confiável: prazos e quarentena usam a data do servidor do GitHub vista na última consulta.
    Adiantar o relógio do Windows não libera vaga (a lista "envelhece" e o sistema trava até conectar);
    atrasar o relógio não estica o vencimento.
  - Sem confirmação de liberação (offline há mais de 7 dias), não é possível cadastrar outra empresa.
- Empresas: quadro "Excluídas recentemente" com a data em que a vaga é liberada e botão Restaurar; a barra
  lateral mostra as excluídas que ainda ocupam vaga.

## 0.16.0 — 2026-11-26
- Três versões definidas pela liberação publicada:
  - Cliente: emite somente para o próprio CNPJ (sem seletor de empresa nem "Nova empresa").
  - Contador: o CNPJ do escritório contábil é o titular e emite para os clientes dele até o limite
    contratado; acima do limite o cadastro é recusado e a empresa excedente fica travada.
  - Administrador: computador do escritório Everton Sousa (chave de administrador), visão de contador +
    painel de Licenças.
  A versão aparece na barra lateral (Contador mostra "N de M clientes").
- Painel Licenças: versão (Cliente/Contador) e limite de clientes por liberação.
- Procuração eletrônica (Contador e Administrador): em Empresas → Acesso à Receita, a empresa cliente usa o
  certificado A1 da empresa do escritório (procuradora) para conectar e assinar; o emitente continua sendo o
  CNPJ do cliente. Validade da procuração com aviso (30 dias) e dica específica quando a Receita devolve
  E0718.
- Ajuda: versões e procuração.

## 0.15.0 — 2026-11-26
- Ajuda: guia de todas as funcionalidades (primeiros passos, emissão, histórico, cadastros, suporte e
  dúvidas frequentes), com índice e busca que destaca o termo.
- Suporte: chamado de Inconsistência (com impacto) ou Solicitação de melhoria, protocolo CH-AAAAMMDD-NNN,
  diagnóstico opcional (versão, leiaute, empresa e últimos erros, sem senhas nem certificado) e envio pelo
  WhatsApp ou e-mail do escritório; "Meus chamados" com copiar texto, reenviar e marcar como resolvido.
- Contato do suporte definido no painel Licenças e publicado assinado junto com a lista; aparece também
  na tela de acesso não liberado, com link direto para o WhatsApp.

## 0.14.0 — 2026-11-26
- Liberação de acesso por CNPJ emitente, com vencimento. Empresa não liberada, vencida, bloqueada ou sem
  verificação há mais de 7 dias fica travada: só o cadastro de Empresas abre, com uma tela que mostra o
  CNPJ para enviar ao escritório e o botão "Verificar agora". Aviso 5 dias antes de vencer. Também barrado
  no servidor (403) e no reenvio automático de pendências.
- Painel "Licenças" só no computador do administrador (chave privada Ed25519 em dados/): cadastrar, +1 mês,
  editar prazo (atalhos 1/3/6/12 meses), bloquear/desbloquear, remover, "Adicionar empresas deste
  computador" e Publicar — a lista vai assinada para o repositório de releases via Git do computador.
- Instalações baixam a lista ao abrir e a cada 6 h, conferem a assinatura e guardam a última válida. Os
  CNPJs vão embaralhados (hash). Enquanto nenhuma lista for publicada, nada é travado.
- Teste que sobe o servidor de verdade (pega erro de inicialização antes de publicar).

## 0.13.0 — 2026-11-26
- Removido o login com Google (botão, configuração do Client ID e rotas). Acesso só por e-mail e senha.
- Usuários: o administrador redefine a senha de alguém da equipe (senha provisória; encerra as sessões
  abertas da pessoa). Senha passa a ser obrigatória ao criar usuário.

## 0.12.0 — 2026-11-26
- Município pelo nome: digite a cidade (sem acento, com ou sem UF) e escolha na lista — o código IBGE é
  preenchido; digitar o código mostra o nome. Lista oficial dos 5.570 municípios embutida (funciona sem
  internet). Vale na emissão (município da prestação e endereço do tomador), no cadastro da empresa, do
  tomador e do serviço favorito.
- Cadastrar serviço favorito a partir de uma nota: ícone de estrela no Histórico e botão no resultado da
  emissão; traz código, NBS, descrição (sem os dados bancários), valor, ISS, município e IBS/CBS.
- Serviço favorito passa a guardar o município da prestação.

## 0.11.0 — 2026-11-26
- Layout responsivo: até 900 px a barra lateral vira barra superior com menu (empresa, telas e usuário)
  e as tabelas viram cartões com o nome de cada campo; até 700 px formulários em uma coluna, botões
  largos, campos com fonte 16 px (sem zoom no celular) e janelas em tela cheia. Sem rolagem lateral em
  nenhuma tela (testado em 390, 820 e 1366 px).

## 0.10.0 — 2026-11-26
- Modelos de IBS/CBS por empresa: "Simples Nacional puro — IBS e CBS no DAS" (regime 1) e "Simples Nacional
  híbrido — IBS e CBS fora do DAS" (regime 3, ou 2 se só a CBS for pelo regime regular), com CST 000,
  cClassTrib 000001 e cIndOp 100301 como padrão e orientação de uso; o serviço favorito pode trocar a
  classificação (atalhos 000001, 200052 e 200029) e a atividade do Simples.
- Regime de apuração do IBS/CBS (regApIBSCBSSN) e atividade do Simples (cAtvSN, códigos 7 a 14 e 90) da
  NT 009: guardados por empresa/serviço e incluídos no XML automaticamente quando o XSD publicado trouxer
  esses campos (o XSD de produção restrita de 20/10/2026 ainda não traz).
- Bloco IBS/CBS da emissão mostra o modelo em uso.

## 0.9.0 — 2026-11-25
- Leiaute da NT 009 (releases 1 a 3; produção prevista para 01/12/2026): DPS convertida e validada no XSD
  oficial de produção restrita (20/10/2026) — finNFSe na raiz, xDescServ no fim de cServ, CST/cClassTrib
  em trib. Modo automático (NT 004 até 30/11/2026, NT 009 depois), escolha manual em Usuários e nova
  tentativa no outro leiaute se a Receita recusar por estrutura. Fluxo próprio de envio (montar →
  converter → validar → assinar → enviar), também na substituição e no reenvio de pendentes.
- IBS/CBS: padrão por empresa (quando informar, data de início, CST, cClassTrib, cIndOp, uso/consumo
  pessoal), por serviço favorito e por nota (bloco na emissão com situação: vai / não vai / falta código).
  Datas automáticas: 01/01/2027, e 01/03/2027 para os itens 1.03, 1.05, 1.09 e 16.01. Valida cClassTrib
  x CST e exige NBS. Funciona nos dois leiautes (cIndOp obrigatório só na NT 004).
- Leitura tolerante de NFS-e no leiaute novo (importação do portal, emissão e DANFSe); o bloco IBS/CBS do
  DANFSe lê também os valores do Simples (gTribSN).
- DANFSe: QR Code corrigido para o endereço exigido pela NT 008 (Consulta Pública
  www.nfse.gov.br/ConsultaPublica/?tpc=1&chave=…) e tamanho mínimo de 1,52 cm.

## 0.8.0 — 2026-11-25
- Descrição do serviço com ferramentas: contador (máx. 2.000 caracteres, com quebras de linha),
  "Modelos de descrição", "Assistente saúde", "Dados bancários" e "Salvar como modelo".
- Modelos: reaproveita a descrição da última nota do tomador ou da empresa e modelos salvos por empresa;
  troca só o que mudar.
- Assistente saúde (psicologia, fisioterapia, fonoaudiologia, terapia ocupacional, nutrição, medicina,
  odontologia): gera o texto "Prestação de serviços de…, referente a N (extenso) sessões…", a
  discriminação data a data e profissional/conselho. Preenche todas as datas do mês por dia da semana,
  calcula o valor (valor por sessão × sessões) e, a partir da nota anterior — inclusive importada do
  portal —, já sugere o mês seguinte com os mesmos dias e horários.
- Cadastro da empresa: banco, agência, conta, tipo, chave PIX, favorecido, profissional e conselho; opção
  de incluir os dados bancários automaticamente no fim de toda descrição (sem duplicar ao repetir nota).

## 0.7.0 — 2026-11-25
- Cancelamento com duas formas: direto (evento 101101) ou Solicitação de Análise Fiscal à prefeitura
  (evento 101103, validado no XSD nacional), para municípios que exigem requerimento/termo assinado ou
  quando o prazo do cancelamento direto venceu. Se o direto for recusado, a tela passa para a análise fiscal.
  A forma escolhida fica lembrada por empresa.
- Requerimento de cancelamento em PDF já preenchido (prestador, dados da nota, motivo, justificativa,
  assinatura do prestador e declaração de concordância do tomador), para protocolar na prefeitura.
- Anexos por nota (PDF/PNG/JPG até 10 MB): requerimento assinado, termo do tomador, protocolo etc.
- Histórico mostra "cancelamento em análise / deferido / indeferido pela prefeitura"; a importação do
  Portal Nacional atualiza essa situação (eventos 101103, 105104 e 105105).

## 0.6.1 — 2026-11-25
- Histórico: notas substituídas importadas do Portal Nacional aparecem como "substituída pela nº X" e a
  substituta como "substitui a nº Y" (lido do grupo <subst> do XML; corrige também as já importadas).
- Tabela do Histórico: descrição limitada a 3 linhas (texto completo ao passar o mouse) e coluna Nº
  ajustada; os ícones não cortam mais com descrições longas.

## 0.6.0 — 2026-11-25
- Cancelamento de NFS-e (evento 101101) direto pelo Histórico: motivo (erro na emissão, serviço não
  prestado, outros), justificativa obrigatória (mín. 15 caracteres), confirmação extra em Produção,
  XML do evento guardado e reenvio automático se a Receita não responder.
- Botões de ação viraram ícones com dica ao passar o mouse (Histórico, Tomadores, Serviços, Empresas,
  Usuários); a tabela do Histórico não corta mais em telas menores.

## 0.5.4 — 2026-11-25
- DANFSe no leiaute oficial da Nota Técnica SE/CGNFS-e nº 008 (v1.02): cabeçalho "DANFSe v2.0",
  chave e dados da NFS-e com QR Code ao lado, blocos Prestador/Fornecedor, Tomador/Adquirente,
  Destinatário, Intermediário, Serviço Prestado, Tributação Municipal (ISSQN), Tributação Federal
  (exceto CBS), Tributação IBS/CBS, Valor Total e Informações Complementares (com a linha obrigatória
  de Totais Aproximados dos Tributos), descrições no lugar de códigos, sombreamento 5% e marca d'água
  CANCELADA/SUBSTITUÍDA.

## 0.5.3 — 2026-11-25
- DANFSe próprio: novo layout A4 com medição de texto (nada sai das caixas), QR Code de consulta,
  prestador, tomador, serviço (descrições do código nacional e NBS), valores, tributos aproximados e
  faixa de aviso para nota cancelada, substituída ou de homologação.
- Botões separados "Ver PDF" e "Baixar PDF" no histórico e após a emissão.

## 0.5.2 — 2026-11-25
- Correção: ativar Produção no cadastro da empresa não depende mais da caixa de confirmação do
  navegador (bloqueada em algumas janelas); agora há uma marcação de confirmação no próprio formulário.
- Importação do Portal Nacional tenta de novo automaticamente (até 3 vezes) quando o ADN oscila.

## 0.5.1 — 2026-11-25
- Correção do atalho: a checagem do servidor usava "localhost", que no Windows tenta IPv6 (::1) antes
  e estourava o tempo, gerando "o servidor não respondeu" e um segundo servidor na mesma porta.
  Agora a checagem usa 127.0.0.1.
- Atualização encerra também o processo que estiver ouvindo a porta 3737 antes de trocar o programa.

## 0.5.0 — 2026-11-25
- Contas e login: no primeiro acesso cria-se a conta de administrador (e-mail e senha ou Google);
  depois, login obrigatório. Tela Usuários (admin) para cadastrar a equipe, desativar contas e
  configurar o Client ID do Google. Senhas com scrypt; sessão de 12 h em cookie HttpOnly.
- Instalador para Windows ("Instalar ES NFS-e.cmd"): instala em %LOCALAPPDATA%\ESNFSe sem precisar
  de administrador, baixa o Node.js portátil se faltar, cria atalho "ES NFS-e" (Área de Trabalho e
  Menu Iniciar) que abre o sistema em janela própria, sem console.
- Atualização automática: a cada abertura, o atalho consulta o latest.json no GitHub (ESFinancas/es-nfse-releases);
  havendo versão nova, baixa e troca o programa. Os dados ficam em pasta separada e nunca são tocados.
- Migração automática dos dados da instalação manual em C:\ESNFSe.

## 0.4.0 — 2026-11-25
- Substituição de NFS-e: botão "Substituir" no Histórico abre a nota original para correção, com motivo
  (códigos 01–05 e 99); a nova DPS sai com vínculo <subst> e o Sistema Nacional cancela a original (evento 105102).
  Histórico mostra "substituída pela nº X" / "substitui a nº Y".
- Identidade visual: logo Everton Sousa Contabilidade na barra lateral e ícone ES.

## 0.3.2 — 2026-11-25
- Correção da importação: o ADN (API v1.1, nov/2026) rejeita sem mensagem a consulta por NSU sem
  `cnpjConsulta`; agora o CNPJ da empresa é sempre informado.
- Diagnóstico do Portal (GET /api/empresas/:id/diagnostico-adn) mostra a resposta crua do ADN.

## 0.3.1 — 2026-11-25
- Mensagens de rejeição do Portal mais completas.

## 0.3.0 — 2026-11-25
- Importação do Portal Nacional: botão no Histórico busca no Ambiente de Dados Nacional (ADN, distribuição
  por NSU) todas as NFS-e em que a empresa é prestadora ou tomadora, desde a primeira, inclusive as emitidas
  pelo portal/app do governo. Continua de onde parou nas próximas vezes (cursor NSU por empresa e ambiente).
- Cancelamentos registrados no portal marcam a nota como "cancelada".
- Histórico separa Emitidas (prestados) e Recebidas (tomados); notas importadas ganham o selo "portal".
- Notas emitidas importadas servem de modelo e alimentam o pré-preenchimento pela última nota do tomador.

## 0.2.2 — 2026-11-25
- Correção: antes de emitir, a tela confere o ambiente atual da empresa no servidor (evita usar o ambiente desatualizado quando ele foi trocado em outra janela).

## 0.2.1 — 2026-11-25
- Correção: a pré-visualização da DPS (que não envia nada) não exige mais a confirmação de Produção.

## 0.2.0 — 2026-11-25
- Cadastro automático pela Receita: ao informar o CNPJ (empresa ou tomador), traz razão social,
  município (código IBGE), regime (MEI / Simples / fora), situação cadastral, e-mail, telefone e endereço.
- Leitura do certificado A1: ao escolher o .pfx e digitar a senha, identifica razão social, CNPJ e
  validade, confere se bate com o CNPJ digitado e dispara a consulta cadastral.
- Alerta quando a situação cadastral não é ATIVA.

## 0.1.0 — 2026-11-25
- Primeira versão: multiempresa, emissão no Padrão Nacional (open-nfse 0.11.1), DANFSe/XML,
  tomadores e serviços favoritos, pré-preenchimento pela última nota (da empresa ou do tomador),
  histórico com totais, reenvio automático de pendências, modos Simulação/Produção Restrita/Produção.
