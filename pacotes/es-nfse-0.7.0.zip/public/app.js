// ES NFS-e — interface (JavaScript puro, sem build).
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const so = (s) => String(s ?? '').replace(/\D/g, '');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const moeda = (v) => (v == null ? '—' : Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
const dataBr = (iso) => (iso ? new Date(iso).toLocaleDateString('pt-BR') : '—');
const hoje = () => new Date().toLocaleDateString('sv-SE'); // AAAA-MM-DD local
function docFmt(d) {
  d = so(d);
  if (d.length === 14) return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  if (d.length === 11) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  return d;
}
const REGIMES = { 1: 'Não optante', 2: 'MEI', 3: 'ME/EPP (Simples)' };

const memo = {
  get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* sem storage */ } },
};

const estado = { sistema: null, empresas: [], empresa: null, tomadores: [], servicos: [] };

async function api(metodo, url, corpo) {
  const r = await fetch(url, {
    method: metodo,
    headers: corpo ? { 'content-type': 'application/json' } : {},
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  if (r.status === 204) return null;
  const dados = await r.json().catch(() => ({}));
  if (r.status === 401 && !url.startsWith('/api/auth/')) { mostrarLogin(); }
  if (!r.ok) {
    const e = new Error(dados.erro ?? `Erro ${r.status}`);
    e.detalhes = dados.detalhes ?? [];
    throw e;
  }
  return dados;
}

let toastTimer;
function toast(msg, erro = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = `toast${erro ? ' erro' : ''}`;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 4500);
}
const falha = (e) => toast(e.detalhes?.length ? `${e.message} ${e.detalhes.join('; ')}` : e.message, true);

async function ocupado(botao, fn) {
  botao.disabled = true;
  try { return await fn(); } finally { botao.disabled = false; }
}

// ------------------------------------------------------------------ modal
function modal(html, aoConfirmar) {
  const dlg = $('#modal');
  const form = $('#formModal');
  form.innerHTML = html;
  dlg.showModal();
  return new Promise((resolve) => {
    form.onsubmit = async (ev) => {
      const acao = ev.submitter?.value;
      if (acao !== 'ok') { resolve(null); return; }
      if (!aoConfirmar) { resolve(true); return; }
      ev.preventDefault();
      try {
        const r = await ocupado(ev.submitter, () => aoConfirmar(form));
        dlg.close();
        resolve(r ?? true);
      } catch (e) { falha(e); }
    };
    dlg.onclose = () => resolve(null);
  });
}
const rodapeModal = (ok = 'Salvar', classe = 'pri') =>
  `<div class="rodape"><button class="btn sec" value="cancelar" formnovalidate>Cancelar</button><button class="btn ${classe}" value="ok">${ok}</button></div>`;
const valorCampo = (form, nome) => form.elements[nome]?.value?.trim() ?? '';

// Ícones (traço 2px, 24x24) para os botões de ação das tabelas.
const ICONES = {
  ver: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  baixar: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>',
  xml: '<path d="m8 8-4 4 4 4"/><path d="m16 8 4 4-4 4"/><path d="m14 4-4 16"/>',
  modelo: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
  substituir: '<path d="M3 12a9 9 0 0 1 15.5-6.2L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.2L3 16"/><path d="M3 21v-5h5"/>',
  cancelar: '<circle cx="12" cy="12" r="9"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',
  editar: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  excluir: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/>',
  emitir: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/><path d="M12 18v-6"/><path d="m9 15 3-3 3 3"/>',
  desativar: '<circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/>',
  reativar: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  anexo: '<path d="m21 11-8.6 8.6a5 5 0 0 1-7-7l8.6-8.6a3.3 3.3 0 0 1 4.7 4.7l-8.6 8.6a1.7 1.7 0 0 1-2.4-2.4l8-8"/>',
};
const svg = (nome) => `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONES[nome]}</svg>`;
/** Botão só com ícone; a dica aparece ao passar o mouse. `attrs` vai direto no elemento. */
const ico = (nome, dica, attrs, classe = '') => `<button type="button" class="ico ${classe}" data-dica="${esc(dica)}" aria-label="${esc(dica)}" ${attrs}>${svg(nome)}</button>`;
const icoLink = (nome, dica, href, extra = '') => `<a class="ico" data-dica="${esc(dica)}" aria-label="${esc(dica)}" href="${href}" ${extra}>${svg(nome)}</a>`;

// ------------------------------------------------------------------ empresas
async function carregarEmpresas() {
  estado.empresas = await api('GET', '/api/empresas');
  const sel = $('#seletorEmpresa');
  sel.innerHTML = estado.empresas.length
    ? estado.empresas.map((e) => `<option value="${e.id}">${esc(e.razaoSocial)}</option>`).join('')
    : '<option value="">Cadastre uma empresa</option>';
  const salvo = memo.get('empresaId');
  const escolhida = estado.empresas.find((e) => e.id === (estado.empresa?.id ?? salvo)) ?? estado.empresas[0];
  if (escolhida) sel.value = escolhida.id;
  await trocarEmpresa(escolhida);
}

async function trocarEmpresa(empresa) {
  estado.empresa = empresa ?? null;
  if (empresa) memo.set('empresaId', empresa.id);
  const faixa = $('#faixaAmbiente');
  if (!empresa) {
    $('#infoEmpresa').textContent = '';
    faixa.className = 'faixa-ambiente simulacao';
    faixa.textContent = 'Nenhuma empresa cadastrada';
    return;
  }
  $('#infoEmpresa').innerHTML = `<span class="mono">${docFmt(empresa.cnpj)}</span><br>${REGIMES[empresa.opSimpNac]} · série ${esc(empresa.serie)}`;
  faixa.className = `faixa-ambiente ${empresa.ambiente}`;
  faixa.textContent = {
    simulacao: 'MODO SIMULAÇÃO — nada é enviado à Receita',
    producao_restrita: 'PRODUÇÃO RESTRITA (homologação) — notas sem valor fiscal',
    producao: 'PRODUÇÃO — as notas emitidas têm valor fiscal',
  }[empresa.ambiente];
  const mei = empresa.opSimpNac === '2';
  $('#campoAliq').hidden = mei;
  $('#dicaAliq').textContent = mei
    ? 'MEI não informa alíquota de ISS: o recolhimento é pelo DAS-MEI.'
    : 'Deixe a alíquota vazia quando o município for conveniado ao Sistema Nacional e parametrizar a alíquota; para optante do Simples, informe a alíquota efetiva do ISS da faixa do Anexo.';
  [estado.tomadores, estado.servicos] = await Promise.all([
    api('GET', `/api/empresas/${empresa.id}/tomadores`),
    api('GET', `/api/empresas/${empresa.id}/servicos`),
  ]);
  $('#listaTomadores').innerHTML = estado.tomadores
    .map((t) => `<option value="${esc(t.nome)} · ${docFmt(t.documento)}"></option>`).join('');
  $('#favorito').innerHTML = '<option value="">— escolher —</option>' +
    estado.servicos.map((s) => `<option value="${s.id}">${esc(s.apelido)} (${esc(s.cTribNac)})</option>`).join('');
}

const exigeEmpresa = () => {
  if (!estado.empresa) { toast('Cadastre e selecione uma empresa primeiro.', true); location.hash = '#empresas'; return false; }
  return true;
};

// ------------------------------------------------------------------ emissão
function coletarEntrada() {
  const semTomador = $('#semTomador').checked;
  const cep = so($('#eCep').value);
  return {
    dataCompetencia: $('#dComp').value || hoje(),
    salvarTomador: !semTomador && $('#salvarTomador').checked,
    tomador: semTomador ? null : {
      documento: so($('#tDoc').value),
      nome: $('#tNome').value.trim(),
      email: $('#tEmail').value.trim(),
      fone: $('#tFone').value.trim(),
      inscricaoMunicipal: $('#tIm').value.trim(),
      ...(cep ? { endereco: {
        cep, codMunicipio: so($('#eIbge').value), logradouro: $('#eLgr').value.trim(), numero: $('#eNro').value.trim(),
        bairro: $('#eBairro').value.trim(), complemento: $('#eCpl').value.trim(), cidade: $('#eCidade').value.trim(),
      } } : {}),
    },
    servico: {
      cTribNac: so($('#sTrib').value), cNBS: so($('#sNbs').value), cTribMun: $('#sTribMun').value.trim(),
      descricao: $('#sDesc').value.trim(), codMunicipioPrestacao: so($('#sMun').value),
    },
    valores: { vServ: $('#vServ').value.replace(/\./g, '').replace(',', '.'), aliqIss: $('#aliq').value.replace(',', '.'), tpRetISSQN: $('#ret').value },
  };
}

const valorBr = (v) => (v === '' || v == null ? '' : Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2 }));

function preencherTomador(t) {
  $('#semTomador').checked = !t;
  $('#blocoTomador').hidden = !t;
  if (!t) return;
  $('#tDoc').value = docFmt(t.documento);
  $('#tNome').value = t.nome ?? '';
  $('#tEmail').value = t.email ?? '';
  $('#tFone').value = t.fone ?? '';
  $('#tIm').value = t.inscricaoMunicipal ?? '';
  const e = t.endereco ?? {};
  $('#eCep').value = e.cep ?? ''; $('#eLgr').value = e.logradouro ?? ''; $('#eNro').value = e.numero ?? '';
  $('#eBairro').value = e.bairro ?? ''; $('#eCpl').value = e.complemento ?? ''; $('#eCidade').value = e.cidade ?? '';
  $('#eIbge').value = e.codMunicipio ?? '';
  $('#detEndereco').open = Boolean(e.cep);
}

function preencherServicoValores(entrada) {
  const s = entrada.servico ?? {};
  const v = entrada.valores ?? {};
  $('#sTrib').value = s.cTribNac ?? ''; $('#sNbs').value = s.cNBS ?? ''; $('#sTribMun').value = s.cTribMun ?? '';
  $('#sDesc').value = s.descricao ?? ''; $('#sMun').value = s.codMunicipioPrestacao ?? '';
  $('#vServ').value = valorBr(v.vServ); $('#aliq').value = v.aliqIss ? String(v.aliqIss).replace('.', ',') : '';
  $('#ret').value = v.tpRetISSQN ?? '1';
}

function mostrarOrigem(texto) {
  const a = $('#avisoOrigem');
  a.classList.remove('subst');
  a.hidden = !texto;
  a.innerHTML = texto ? `<span>${texto}</span><button type="button" class="btn mini sec" id="desfazerOrigem">Limpar</button>` : '';
  if (texto) $('#desfazerOrigem').onclick = () => limparEmissao(false);
}

function sairSubstituicao() {
  estado.substituindo = null;
  $('#blocoSubst').hidden = true;
  $('#btnEmitir').textContent = 'Emitir NFS-e';
  $('#btnPrevia').hidden = false;
}

function limparEmissao(sugerir = true) {
  sairSubstituicao();
  $('#formEmissao').reset();
  preencherTomador({});
  $('#tDoc').value = '';
  estado.ultimoDocTomador = '';
  $('#detEndereco').open = false;
  $('#dComp').value = hoje();
  $('#resultado').innerHTML = '';
  mostrarOrigem('');
  if (sugerir) sugerirUltima(false);
}

/** Abre a tela já com serviço/valores da última nota (sem tomador). */
async function sugerirUltima(completa) {
  if (!estado.empresa) return;
  const s = await api('GET', `/api/empresas/${estado.empresa.id}/sugestao`);
  if (!s.origem) { if (completa) toast('Esta empresa ainda não tem nota autorizada.'); return; }
  preencherServicoValores(s.entrada);
  if (completa) preencherTomador(s.entrada.tomador);
  mostrarOrigem(`${completa ? 'Nota repetida' : 'Serviço e valores preenchidos'} a partir da última NFS-e emitida: nº <b>${esc(s.nota.numero)}</b> de ${dataBr(s.nota.dhProc)} para ${esc(s.nota.tomadorNome)}.`);
}

async function aoEscolherTomador(doc) {
  const t = estado.tomadores.find((x) => so(x.documento) === so(doc));
  if (t) preencherTomador(t);
  const s = await api('GET', `/api/empresas/${estado.empresa.id}/sugestao?tomador=${so(doc)}&somenteTomador=1`);
  if (s.origem === 'tomador') {
    preencherServicoValores(s.entrada);
    if (!t && s.entrada.tomador) preencherTomador(s.entrada.tomador);
    mostrarOrigem(`Preenchido a partir da última nota deste tomador: nº <b>${esc(s.nota.numero)}</b> de ${dataBr(s.nota.dhProc)} · ${moeda(s.nota.vServ)}. Confira valor e competência.`);
  } else if (t) {
    mostrarOrigem('Tomador do cadastro. Ainda não há nota emitida para ele.');
  } else if (so(doc).length === 14) {
    // Tomador novo: busca os dados na Receita.
    try {
      const d = await consultarCnpj(doc);
      preencherTomador({ documento: so(doc), nome: d.razaoSocial, email: d.email, fone: d.fone, endereco: d.endereco });
      mostrarOrigem(`Tomador novo: dados trazidos do cadastro da Receita (${esc(d.situacao || 'situação não informada')}). Confira o e-mail.${avisoSituacao(d.situacao)}`);
    } catch (e) { toast(e.message, true); }
  }
}

async function buscarCep() {
  const cep = so($('#eCep').value);
  if (cep.length !== 8) return;
  try {
    const r = await (await fetch(`https://viacep.com.br/ws/${cep}/json/`)).json();
    if (r.erro) return toast('CEP não encontrado.', true);
    $('#eLgr').value ||= r.logradouro ?? ''; $('#eBairro').value ||= r.bairro ?? '';
    $('#eCidade').value = `${r.localidade}/${r.uf}`; $('#eIbge').value = r.ibge ?? '';
  } catch { /* sem internet: preencha à mão */ }
}

// ------------------------------------------------------------------ consulta CNPJ
// BrasilAPI (dados abertos da Receita) direto do navegador; IBGE pelo ViaCEP se faltar.
const cacheCnpj = new Map();
const titulo = (s) => String(s ?? '').toLowerCase().replace(/(^|\s)\S/g, (c) => c.toUpperCase());

async function consultarCnpj(cnpj) {
  cnpj = so(cnpj);
  if (cnpj.length !== 14) return null;
  if (cacheCnpj.has(cnpj)) return cacheCnpj.get(cnpj);
  let r;
  try { r = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpj}`); } catch { throw new Error('Sem internet para consultar o CNPJ; preencha à mão.'); }
  if (r.status === 404 || r.status === 400) throw new Error('CNPJ não encontrado na base da Receita.');
  if (!r.ok) throw new Error('Consulta de CNPJ indisponível agora; preencha à mão.');
  const d = await r.json();
  const cep = so(d.cep);
  let ibge = d.codigo_municipio_ibge ? String(d.codigo_municipio_ibge) : '';
  if (!ibge && cep.length === 8) {
    try { ibge = (await (await fetch(`https://viacep.com.br/ws/${cep}/json/`)).json()).ibge ?? ''; } catch { /* segue sem IBGE */ }
  }
  const tipo = d.descricao_tipo_de_logradouro ?? '';
  const lgr = d.logradouro ?? '';
  const cidade = d.municipio ? `${titulo(d.municipio)}/${d.uf}` : '';
  const dados = {
    razaoSocial: d.razao_social ?? '',
    situacao: d.descricao_situacao_cadastral ?? '',
    codMunicipio: ibge,
    municipio: cidade,
    // MEI → 2; Simples → 3; fora do Simples → 1; sem informação → não mexe
    opSimpNac: d.opcao_pelo_mei ? '2' : d.opcao_pelo_simples ? '3' : d.opcao_pelo_simples === false ? '1' : '',
    email: String(d.email ?? '').toLowerCase(),
    fone: so(d.ddd_telefone_1),
    endereco: cep ? {
      cep, codMunicipio: ibge, cidade, bairro: titulo(d.bairro), complemento: titulo(d.complemento),
      logradouro: titulo(tipo && !lgr.toUpperCase().startsWith(tipo.toUpperCase()) ? `${tipo} ${lgr}` : lgr),
      numero: d.numero || 'S/N',
    } : undefined,
  };
  cacheCnpj.set(cnpj, dados);
  return dados;
}

const avisoSituacao = (s) => (s && s.toUpperCase() !== 'ATIVA' ? ` <b style="color:var(--erro)">Atenção: situação cadastral ${esc(s)}.</b>` : '');

function renderResultado(r) {
  const el = $('#resultado');
  if (r.status === 'autorizada') {
    const n = r.nota;
    el.innerHTML = `<div class="resultado ok"><h2>NFS-e nº ${esc(n.numero)} autorizada${n.substituiu ? ` — substitui a nº ${esc(n.substituiu)}, que foi cancelada` : ''}</h2>
      <p>${esc(n.tomadorNome)} · ${moeda(n.vServ)} · líquido ${moeda(n.vLiq)}</p>
      <p class="mono">Chave: ${esc(n.chaveAcesso)}</p>
      ${n.alertas?.length ? `<ul>${n.alertas.map((a) => `<li>${esc(a)}</li>`).join('')}</ul>` : ''}
      <div class="acoes"><a class="btn pri" href="/api/notas/${n.id}/pdf" target="_blank">Ver DANFSe (PDF)</a>
      <a class="btn sec" href="/api/notas/${n.id}/pdf?baixar=1" download>Baixar PDF</a>
      <a class="btn sec" href="/api/notas/${n.id}/xml">Baixar XML</a>
      <button class="btn sec" type="button" id="novaNota">Nova nota</button></div></div>`;
    $('#novaNota').onclick = () => limparEmissao();
  } else if (r.status === 'rejeitada') {
    el.innerHTML = `<div class="resultado erro"><h2>Rejeitada pela Receita</h2><ul>${r.mensagens.map((m) => `<li>${esc(m)}</li>`).join('')}</ul>
      <p class="dica">O número da DPS foi consumido. Corrija e emita de novo; a rejeição fica registrada no histórico.</p></div>`;
  } else if (r.status === 'pendente') {
    el.innerHTML = `<div class="resultado pend"><h2>Envio pendente</h2><p>A Receita não respondeu (${esc(r.nota.erro)}). A DPS assinada foi guardada e será reenviada automaticamente a cada 3 minutos, sem risco de duplicar a nota.</p></div>`;
  }
  el.scrollIntoView({ behavior: 'smooth' });
}

async function emitir(ev) {
  ev.preventDefault();
  if (!exigeEmpresa()) return;
  // Recarrega a empresa: o ambiente pode ter sido alterado em outra janela.
  const atual = (await api('GET', '/api/empresas')).find((x) => x.id === estado.empresa.id);
  if (atual && atual.ambiente !== estado.empresa.ambiente) {
    await carregarEmpresas();
    toast('O ambiente desta empresa mudou em outra janela. Tela atualizada: confira e clique em Emitir de novo.', true);
    return;
  }
  const entrada = coletarEntrada();
  const corpo = { ...entrada };
  if (estado.empresa.ambiente === 'producao') {
    const ok = await modal(`<h2>${estado.substituindo ? `Confirmar substituição da NFS-e nº ${esc(estado.substituindo.numero)}` : 'Confirmar emissão em Produção'}</h2>
      ${estado.substituindo ? '<p>A nota original será <b>cancelada</b> pelo Sistema Nacional e substituída por esta.</p>' : ''}
      <p>Esta nota terá <b>valor fiscal</b>. Emitente: <b>${esc(estado.empresa.razaoSocial)}</b>.</p>
      <p>Tomador: <b>${esc(entrada.tomador?.nome || 'não identificado')}</b> · Valor: <b>${moeda(entrada.valores.vServ)}</b></p>
      <p>Serviço: ${esc(entrada.servico.descricao)}</p>${rodapeModal('Emitir nota', 'perigo')}`);
    if (!ok) return;
    corpo.confirmar = true;
  }
  const subst = estado.substituindo;
  if (subst) {
    corpo.cMotivo = $('#cMotivo').value;
    corpo.xMotivo = $('#xMotivo').value.trim();
  }
  await ocupado($('#btnEmitir'), async () => {
    try {
      const r = subst
        ? await api('POST', `/api/notas/${subst.id}/substituir`, corpo)
        : await api('POST', `/api/empresas/${estado.empresa.id}/emitir`, corpo);
      if (subst && r.status === 'autorizada') { sairSubstituicao(); r.nota.substituiu = subst.numero; }
      renderResultado(r);
      if (r.status === 'autorizada') { mostrarOrigem(''); await trocarEmpresa(estado.empresa); }
    } catch (e) {
      $('#resultado').innerHTML = `<div class="resultado erro"><h2>${esc(e.message)}</h2>${e.detalhes.length ? `<ul>${e.detalhes.map((d) => `<li>${esc(d)}</li>`).join('')}</ul>` : ''}<p class="dica">Nada foi enviado e nenhum número de DPS foi consumido.</p></div>`;
    }
  });
}

async function previa() {
  if (!exigeEmpresa()) return;
  await ocupado($('#btnPrevia'), async () => {
    try {
      const r = await api('POST', `/api/empresas/${estado.empresa.id}/emitir?previa=1`, coletarEntrada());
      const bonito = r.xmlDps.replace(/></g, '>\n<');
      await modal(`<h2>Prévia da DPS assinada</h2><p class="dica">Validada contra o XSD nacional e assinada, mas não enviada.</p><pre class="xml">${esc(bonito)}</pre><div class="rodape"><button class="btn pri" value="cancelar">Fechar</button></div>`);
    } catch (e) { falha(e); }
  });
}

// ------------------------------------------------------------------ histórico
async function carregarHistorico() {
  if (!exigeEmpresa()) return;
  const papel = $('#fPapel').value;
  const q = new URLSearchParams({ de: $('#fDe').value, ate: $('#fAte').value, q: $('#fBusca').value, status: $('#fStatus').value, papel });
  const { notas, totais } = await api('GET', `/api/empresas/${estado.empresa.id}/notas?${q}`);
  const recebidas = papel === 'recebida';
  $('#thContraparte').textContent = { emitida: 'Tomador', recebida: 'Prestador', todas: 'Contraparte' }[papel];
  $('#totais').innerHTML = `<div><span>Notas autorizadas</span><b>${totais.quantidade}</b></div>
    <div><span>${recebidas ? 'Serviços tomados' : 'Faturamento'}</span><b>${moeda(totais.vServ)}</b></div><div><span>ISS destacado</span><b>${moeda(totais.vISSQN)}</b></div>`;
  $('#tabNotas tbody').innerHTML = notas.length ? notas.map((n) => `<tr>
    <td class="mono">${esc(n.numero ?? '—')}<span class="sub">DPS ${esc(n.serie ?? '')}/${esc(n.nDPS ?? '')}</span></td>
    <td>${dataBr(n.dhProc ?? n.criadoEm)}<span class="sub">comp. ${dataBr(n.competencia && `${n.competencia}T12:00`)}</span></td>
    <td>${esc(n.tomadorNome)}<span class="sub mono">${docFmt(n.tomadorDoc)}</span></td>
    <td><span class="desc" title="${esc(n.descricao ?? '')}">${esc(n.descricao ?? '')}</span>${n.erro ? `<span class="sub">${esc(n.erro)}</span>` : ''}</td>
    <td class="num">${moeda(n.vServ)}</td><td class="num">${moeda(n.vISSQN)}</td>
    <td><span class="selo ${n.status}">${n.status}</span>${n.papel === 'recebida' && papel === 'todas' ? ' <span class="selo amb">recebida</span>' : ''}${n.origem === 'portal' ? ' <span class="selo portal">portal</span>' : ''}${n.ambiente !== 'producao' ? ` <span class="selo amb">${n.ambiente === 'simulacao' ? 'simulação' : 'homolog.'}</span>` : ''}</td>
    <td class="acoes"><div class="icones">${n.chaveAcesso ? icoLink('ver', 'Ver DANFSe (PDF)', `/api/notas/${n.id}/pdf`, 'target="_blank"') + icoLink('baixar', 'Baixar DANFSe (PDF)', `/api/notas/${n.id}/pdf?baixar=1`, 'download') + icoLink('xml', 'Baixar XML', `/api/notas/${n.id}/xml`, 'download') : ''}${n.papel === 'recebida' ? '' : ico('modelo', 'Usar como modelo', `data-modelo="${n.id}"`)}${n.papel !== 'recebida' && n.chaveAcesso ? ico('anexo', n.anexos?.length ? `Anexos (${n.anexos.length})` : 'Anexos', `data-anexos="${n.id}"`, n.anexos?.length ? 'com-anexo' : '') : ''}${n.status === 'autorizada' && n.papel !== 'recebida' && n.ambiente === estado.empresa.ambiente ? ico('substituir', 'Substituir nota', `data-substituir="${n.id}"`) + (n.analiseFiscal?.status === 'solicitada' ? '' : ico('cancelar', 'Cancelar nota', `data-cancelar="${n.id}"`, 'perigo')) : ''}</div>${n.analiseFiscal ? `<span class="sub analise ${n.analiseFiscal.status}">${{ solicitada: 'cancelamento em análise na prefeitura', deferida: 'cancelamento deferido pela prefeitura', indeferida: 'cancelamento indeferido pela prefeitura' }[n.analiseFiscal.status] ?? ''}</span>` : ''}${n.cancelamentoPendente ? '<span class="sub">cancelamento aguardando a Receita</span>' : ''}${n.substituidaPorNumero ? `<span class="sub">substituída pela nº ${esc(n.substituidaPorNumero)}</span>` : ''}${n.substituiNumero ? `<span class="sub">substitui a nº ${esc(n.substituiNumero)}</span>` : ''}</td>
  </tr>`).join('') : '<tr><td colspan="8" class="vazio">Nenhuma nota no período.</td></tr>';
}

/** Puxa do Portal Nacional (ADN) todas as NFS-e da empresa, em lotes, até zerar a fila. */
async function importarPortal() {
  if (!exigeEmpresa()) return;
  const total = { emitidas: 0, recebidas: 0, canceladas: 0, jaExistiam: 0, ignorados: 0 };
  try {
    for (let rodada = 1; rodada <= 40; rodada++) {
      toast(`Consultando o Portal Nacional… lote ${rodada} (${total.emitidas + total.recebidas} notas novas até agora)`);
      let r;
      for (let tentativa = 1; ; tentativa++) {
        try { r = await api('POST', `/api/empresas/${estado.empresa.id}/sincronizar`); break; }
        catch (e) {
          if (tentativa >= 3 || !/comunicação/i.test(e.message)) throw e;
          toast(`Portal Nacional instável, tentando de novo (${tentativa}/3)…`);
          await new Promise((ok) => setTimeout(ok, 3000));
        }
      }
      for (const k of Object.keys(total)) total[k] += r[k] ?? 0;
      if (r.concluido) break;
    }
    toast(`Portal Nacional: ${total.emitidas} emitida(s) e ${total.recebidas} recebida(s) importadas, ${total.canceladas} cancelamento(s) aplicados, ${total.jaExistiam} já estavam no histórico.`);
    await carregarHistorico();
  } catch (e) { falha(e); }
}

async function iniciarSubstituicao(id) {
  const nota = await api('GET', `/api/notas/${id}`);
  if (!nota.entrada) return toast('Esta nota não guarda os dados de preenchimento. Importe-a do Portal Nacional primeiro.', true);
  location.hash = '#emitir';
  await mostrarTela('emitir', false);
  limparEmissao(false);
  preencherTomador(nota.entrada.tomador);
  preencherServicoValores(nota.entrada);
  if (nota.competencia) $('#dComp').value = nota.competencia;
  if (!estado.motivosSubst) estado.motivosSubst = await api('GET', '/api/sistema/motivos-substituicao');
  $('#cMotivo').innerHTML = Object.entries(estado.motivosSubst).map(([k, v]) => `<option value="${k}" ${k === '99' ? 'selected' : ''}>${k} — ${esc(v)}</option>`).join('');
  estado.substituindo = { id: nota.id, numero: nota.numero };
  $('#blocoSubst').hidden = false;
  $('#btnPrevia').hidden = true;
  $('#btnEmitir').textContent = `Emitir substituta da nº ${nota.numero}`;
  mostrarOrigem(`<b>Substituindo a NFS-e nº ${esc(nota.numero)}</b> de ${dataBr(nota.dhProc)} para ${esc(nota.tomadorNome)} (${moeda(nota.vServ)}). Corrija o que for preciso e informe o motivo no fim da página.`);
  $('#avisoOrigem').classList.add('subst');
}

// ------------------------------------------------------------------ cancelamento e anexos
async function enviarAnexos(notaId, arquivos, descricao = '') {
  for (const arq of arquivos) {
    if (arq.size > 10 * 1024 * 1024) { toast(`${arq.name}: máximo de 10 MB.`, true); continue; }
    await api('POST', `/api/notas/${notaId}/anexos`, { nome: arq.name, tipo: arq.type, base64: await lerArquivoBase64(arq), descricao });
  }
}

const listaAnexosHtml = (nota) => (nota.anexos?.length
  ? `<ul class="anexos">${nota.anexos.map((x) => `<li><a href="/api/notas/${nota.id}/anexos/${x.id}" target="_blank">${esc(x.nome)}</a><span>${(x.tamanho / 1024).toFixed(0)} KB · ${dataBr(x.criadoEm)}</span>${ico('excluir', 'Remover anexo', `data-del-anexo="${x.id}"`, 'perigo')}</li>`).join('')}</ul>`
  : '<p class="dica">Nenhum anexo ainda.</p>');

async function gerenciarAnexos(id) {
  let nota = await api('GET', `/api/notas/${id}`);
  const form = $('#formModal');
  const redesenhar = () => { form.querySelector('#listaAnexos').innerHTML = listaAnexosHtml(nota); };
  const pronto = modal(`<h2>Anexos da NFS-e nº ${esc(nota.numero)}</h2>
    <p class="dica">Guarde aqui o requerimento assinado, a declaração do tomador, comprovantes e o protocolo da prefeitura. Os arquivos ficam neste computador, junto com a nota.</p>
    <div id="listaAnexos"></div>
    <label class="btn sec arquivo">${svg('anexo')} Adicionar arquivo (PDF, PNG ou JPG)<input type="file" id="novoAnexo" accept="application/pdf,image/png,image/jpeg" multiple hidden></label>
    <div class="rodape"><button class="btn pri" value="cancelar">Fechar</button></div>`);
  redesenhar();
  form.querySelector('#novoAnexo').onchange = async (ev) => {
    try { await enviarAnexos(id, ev.target.files); nota = await api('GET', `/api/notas/${id}`); redesenhar(); } catch (e) { falha(e); }
    ev.target.value = '';
  };
  form.querySelector('#listaAnexos').onclick = async (ev) => {
    const b = ev.target.closest('[data-del-anexo]');
    if (!b) return;
    ev.preventDefault(); ev.stopPropagation();
    try { await api('DELETE', `/api/notas/${id}/anexos/${b.dataset.delAnexo}`); nota = await api('GET', `/api/notas/${id}`); redesenhar(); } catch (e) { falha(e); }
  };
  await pronto;
  await carregarHistorico();
}

async function cancelarNota(id) {
  let nota = await api('GET', `/api/notas/${id}`);
  if (!estado.motivosCanc) estado.motivosCanc = await api('GET', '/api/sistema/motivos-cancelamento');
  const prod = nota.ambiente === 'producao';
  const chaveModo = `modoCancelamento:${nota.empresaId}`;
  let modoPadrao = 'direto';
  try { modoPadrao = localStorage.getItem(chaveModo) ?? 'direto'; } catch { /* sem storage */ }
  const form = $('#formModal');
  const pronto = modal(`<h2>Cancelar a NFS-e nº ${esc(nota.numero)}</h2>
    <p class="dica">${esc(nota.tomadorNome)} · ${moeda(nota.vServ)} · emitida em ${dataBr(nota.dhProc)}. O pedido vai ao Sistema Nacional e <b>não pode ser desfeito</b>. Se a nota só tem um erro, prefira <b>Substituir</b>.</p>
    <div class="modos">
      <label class="modo"><input type="radio" name="modo" value="direto" ${modoPadrao === 'direto' ? 'checked' : ''}><span><b>Cancelamento direto</b><small>A nota é cancelada na hora, se o município permitir.</small></span></label>
      <label class="modo"><input type="radio" name="modo" value="analise" ${modoPadrao === 'analise' ? 'checked' : ''}><span><b>Solicitar análise fiscal à prefeitura</b><small>Para municípios que exigem requerimento ou termo assinado, ou quando o prazo do cancelamento direto já passou. A nota fica "em análise" até a prefeitura deferir.</small></span></label>
    </div>
    <div class="linha"><div class="campo grande"><label>Motivo *</label><select name="cMotivo">${Object.entries(estado.motivosCanc).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('')}</select></div></div>
    <div class="linha"><div class="campo grande"><label>Justificativa * (de 15 a 255 caracteres; vai no evento e no requerimento)</label><textarea name="xMotivo" rows="3" minlength="15" maxlength="255" required></textarea></div></div>
    <div class="bloco-analise">
      <p class="dica"><b>Documentos para a prefeitura.</b> O Sistema Nacional recebe só o motivo e a justificativa. O requerimento assinado e a declaração do tomador são protocolados na prefeitura; guarde as cópias aqui.</p>
      <div class="acoes-linha">
        <button type="button" class="btn sec" id="btnRequerimento">${svg('emitir')} Gerar requerimento (PDF)</button>
        <label class="btn sec arquivo">${svg('anexo')} Anexar requerimento assinado / termo<input type="file" id="anexoCanc" accept="application/pdf,image/png,image/jpeg" multiple hidden></label>
      </div>
      <div id="listaAnexos"></div>
    </div>
    ${prod ? '<label class="check"><input type="checkbox" name="confirma" required> Confirmo o pedido de cancelamento desta nota em Produção (com valor fiscal)</label>' : ''}
    <div class="rodape"><button class="btn sec" value="cancelar" formnovalidate>Voltar</button><button class="btn perigo" value="ok" id="btnConfCanc">Cancelar nota</button></div>`, async (f) => {
    const modo = f.elements.modo.value;
    const corpo = { cMotivo: f.elements.cMotivo.value, xMotivo: valorCampo(f, 'xMotivo'), confirmar: prod ? f.elements.confirma.checked : undefined };
    const resp = await api('POST', `/api/notas/${id}/${modo === 'analise' ? 'analise-fiscal' : 'cancelar'}`, corpo);
    if (resp.status === 'rejeitada') {
      if (modo === 'direto') {
        f.elements.modo.value = 'analise';
        atualizarModo();
        const e = new Error('A Receita/prefeitura recusou o cancelamento direto. Selecionei "Solicitar análise fiscal": gere o requerimento, anexe e envie de novo.');
        e.detalhes = resp.mensagens; throw e;
      }
      const e = new Error('A solicitação de análise fiscal foi recusada.'); e.detalhes = resp.mensagens; throw e;
    }
    try { localStorage.setItem(chaveModo, modo); } catch { /* sem storage */ }
    return resp;
  });
  const atualizarModo = () => {
    const analise = form.elements.modo.value === 'analise';
    form.querySelector('.bloco-analise').hidden = !analise;
    form.querySelector('#btnConfCanc').textContent = analise ? 'Enviar solicitação à prefeitura' : 'Cancelar nota';
  };
  const redesenhar = () => { form.querySelector('#listaAnexos').innerHTML = listaAnexosHtml(nota); };
  form.querySelectorAll('[name=modo]').forEach((r) => { r.onchange = atualizarModo; });
  atualizarModo(); redesenhar();
  form.querySelector('#btnRequerimento').onclick = () => {
    const just = valorCampo(form, 'xMotivo');
    if (just.length < 15) return toast('Escreva a justificativa (mínimo de 15 caracteres) antes de gerar o requerimento.', true);
    window.open(`/api/notas/${id}/requerimento?${new URLSearchParams({ cMotivo: form.elements.cMotivo.value, xMotivo: just })}`, '_blank');
  };
  form.querySelector('#anexoCanc').onchange = async (ev) => {
    try { await enviarAnexos(id, ev.target.files, 'Cancelamento'); nota = await api('GET', `/api/notas/${id}`); redesenhar(); } catch (e) { falha(e); }
    ev.target.value = '';
  };
  form.querySelector('#listaAnexos').onclick = async (ev) => {
    const b = ev.target.closest('[data-del-anexo]');
    if (!b) return;
    ev.preventDefault(); ev.stopPropagation();
    try { await api('DELETE', `/api/notas/${id}/anexos/${b.dataset.delAnexo}`); nota = await api('GET', `/api/notas/${id}`); redesenhar(); } catch (e) { falha(e); }
  };
  const r = await pronto;
  if (!r) { await carregarHistorico(); return; }
  toast(r.status === 'cancelada' ? `NFS-e nº ${nota.numero} cancelada.`
    : r.status === 'analise_solicitada' ? `Solicitação de cancelamento da NFS-e nº ${nota.numero} enviada. Protocole o requerimento na prefeitura; a nota fica "em análise" até o deferimento.`
      : r.mensagem);
  await carregarHistorico();
}

async function usarComoModelo(id) {
  const nota = await api('GET', `/api/notas/${id}`);
  if (!nota.entrada) return toast('Esta nota não guarda os dados de preenchimento.', true);
  location.hash = '#emitir';
  await mostrarTela('emitir', false);
  limparEmissao(false);
  preencherTomador(nota.entrada.tomador);
  preencherServicoValores(nota.entrada);
  mostrarOrigem(`Preenchido a partir da nota ${nota.numero ? `nº <b>${esc(nota.numero)}</b>` : 'selecionada'}. Confira valor e competência.`);
}

// ------------------------------------------------------------------ tomadores
function formTomador(t = {}) {
  const e = t.endereco ?? {};
  return `<h2>${t.id ? 'Editar' : 'Novo'} tomador</h2>
  <div class="linha"><div class="campo"><label>CPF / CNPJ *</label><input name="documento" class="mono" required value="${esc(docFmt(t.documento))}"></div>
  <div class="campo grande"><label>Nome / razão social *</label><input name="nome" required value="${esc(t.nome)}"></div></div>
  <div class="linha"><div class="campo grande"><label>E-mail</label><input name="email" type="email" value="${esc(t.email)}"></div>
  <div class="campo"><label>Telefone</label><input name="fone" value="${esc(t.fone)}"></div>
  <div class="campo"><label>Inscrição municipal</label><input name="inscricaoMunicipal" value="${esc(t.inscricaoMunicipal)}"></div></div>
  <div class="linha"><div class="campo pequeno"><label>CEP</label><input name="cep" class="mono" value="${esc(e.cep)}"></div>
  <div class="campo grande"><label>Logradouro</label><input name="logradouro" value="${esc(e.logradouro)}"></div>
  <div class="campo pequeno"><label>Número</label><input name="numero" value="${esc(e.numero)}"></div></div>
  <div class="linha"><div class="campo"><label>Bairro</label><input name="bairro" value="${esc(e.bairro)}"></div>
  <div class="campo"><label>Complemento</label><input name="complemento" value="${esc(e.complemento)}"></div>
  <div class="campo"><label>Cidade</label><input name="cidade" value="${esc(e.cidade)}"></div>
  <div class="campo pequeno"><label>Cód. IBGE</label><input name="codMunicipio" class="mono" value="${esc(e.codMunicipio)}"></div></div>
  ${rodapeModal()}`;
}

function dadosTomador(f) {
  const v = (n) => valorCampo(f, n);
  return {
    documento: so(v('documento')), nome: v('nome'), email: v('email'), fone: v('fone'), inscricaoMunicipal: v('inscricaoMunicipal'),
    endereco: so(v('cep')) ? { cep: so(v('cep')), logradouro: v('logradouro'), numero: v('numero'), bairro: v('bairro'),
      complemento: v('complemento'), cidade: v('cidade'), codMunicipio: so(v('codMunicipio')) } : undefined,
  };
}

async function editarTomador(t) {
  const aberto = modal(formTomador(t), (f) => (t?.id
    ? api('PUT', `/api/tomadores/${t.id}`, dadosTomador(f))
    : api('POST', `/api/empresas/${estado.empresa.id}/tomadores`, dadosTomador(f))));
  const f = $('#formModal');
  let ultimo = so(f.elements.documento.value);
  f.elements.documento.addEventListener('blur', async () => {
    const doc = so(f.elements.documento.value);
    f.elements.documento.value = docFmt(doc);
    if (doc.length !== 14 || doc === ultimo) return;
    ultimo = doc;
    try {
      const d = await consultarCnpj(doc);
      const e = d.endereco ?? {};
      const val = { nome: d.razaoSocial, email: d.email, fone: d.fone, cep: e.cep, logradouro: e.logradouro, numero: e.numero, bairro: e.bairro, complemento: e.complemento, cidade: e.cidade, codMunicipio: e.codMunicipio };
      for (const [k, v] of Object.entries(val)) if (v && f.elements[k]) f.elements[k].value = v;
      toast(`Dados trazidos da Receita (${d.situacao || 'situação não informada'}).`, Boolean(d.situacao && d.situacao.toUpperCase() !== 'ATIVA'));
    } catch (err) { toast(err.message, true); }
  });
  const ok = await aberto;
  if (ok) { await trocarEmpresa(estado.empresa); renderTomadores(); toast('Tomador salvo.'); }
}

function renderTomadores() {
  const termo = $('#buscaTom').value.toLowerCase();
  const lista = estado.tomadores.filter((t) => !termo || `${t.nome} ${t.documento}`.toLowerCase().includes(termo));
  $('#tabTomadores tbody').innerHTML = lista.length ? lista.map((t) => `<tr><td>${esc(t.nome)}</td><td class="mono">${docFmt(t.documento)}</td>
    <td>${esc(t.email)}</td><td>${esc(t.endereco?.cidade)}</td>
    <td class="acoes"><div class="icones">${ico('emitir', 'Emitir nota para este tomador', `data-emitir-tom="${t.id}"`)}${ico('editar', 'Editar tomador', `data-edit-tom="${t.id}"`)}${ico('excluir', 'Excluir tomador', `data-del-tom="${t.id}"`, 'perigo')}</div></td></tr>`).join('')
    : '<tr><td colspan="5" class="vazio">Nenhum tomador cadastrado. Eles também são salvos automaticamente ao emitir.</td></tr>';
}

// ------------------------------------------------------------------ serviços
function formServico(s = {}) {
  return `<h2>${s.id ? 'Editar' : 'Novo'} serviço favorito</h2>
  <div class="linha"><div class="campo grande"><label>Apelido *</label><input name="apelido" required value="${esc(s.apelido)}" placeholder="ex.: Honorário mensal"></div>
  <div class="campo"><label>Cód. tributação nacional *</label><input name="cTribNac" class="mono" required value="${esc(s.cTribNac)}"></div>
  <div class="campo"><label>NBS</label><input name="cNBS" class="mono" value="${esc(s.cNBS)}"></div>
  <div class="campo pequeno"><label>Cód. municipal</label><input name="cTribMun" class="mono" value="${esc(s.cTribMun)}"></div></div>
  <div class="campo"><label>Descrição padrão *</label><textarea name="descricao" rows="3" required>${esc(s.descricao)}</textarea></div>
  <div class="linha"><div class="campo"><label>Valor padrão (R$)</label><input name="vServ" class="mono" value="${esc(valorBr(s.vServ))}"></div>
  <div class="campo"><label>Alíquota ISS (%)</label><input name="aliqIss" class="mono" value="${esc(s.aliqIss)}"></div>
  <div class="campo"><label>Retenção ISS</label><select name="tpRetISSQN">${['Não retido', 'Retido pelo tomador', 'Retido pelo intermediário'].map((o, i) => `<option value="${i + 1}" ${String(s.tpRetISSQN ?? '1') === String(i + 1) ? 'selected' : ''}>${o}</option>`).join('')}</select></div></div>
  ${rodapeModal()}`;
}

async function editarServico(s) {
  const dados = (f) => ({
    apelido: valorCampo(f, 'apelido'), cTribNac: so(valorCampo(f, 'cTribNac')), cNBS: so(valorCampo(f, 'cNBS')), cTribMun: valorCampo(f, 'cTribMun'),
    descricao: valorCampo(f, 'descricao'), vServ: valorCampo(f, 'vServ').replace(/\./g, '').replace(',', '.'),
    aliqIss: valorCampo(f, 'aliqIss').replace(',', '.'), tpRetISSQN: valorCampo(f, 'tpRetISSQN'),
  });
  const ok = await modal(formServico(s), (f) => (s?.id ? api('PUT', `/api/servicos/${s.id}`, dados(f)) : api('POST', `/api/empresas/${estado.empresa.id}/servicos`, dados(f))));
  if (ok) { await trocarEmpresa(estado.empresa); renderServicos(); toast('Serviço salvo.'); }
}

function renderServicos() {
  $('#tabServicos tbody').innerHTML = estado.servicos.length ? estado.servicos.map((s) => `<tr><td>${esc(s.apelido)}</td><td class="mono">${esc(s.cTribNac)}</td><td class="mono">${esc(s.cNBS)}</td>
    <td>${esc(s.descricao?.slice(0, 80))}</td><td class="num">${s.vServ ? moeda(s.vServ) : '—'}</td>
    <td class="acoes"><div class="icones">${ico('editar', 'Editar serviço', `data-edit-serv="${s.id}"`)}${ico('excluir', 'Excluir serviço', `data-del-serv="${s.id}"`, 'perigo')}</div></td></tr>`).join('')
    : '<tr><td colspan="6" class="vazio">Cadastre os serviços que a empresa emite com frequência.</td></tr>';
}

// ------------------------------------------------------------------ empresas (tela)
function formEmpresa(e = {}) {
  const opt = (valor, rotulo, atual) => `<option value="${valor}" ${String(atual) === String(valor) ? 'selected' : ''}>${rotulo}</option>`;
  return `<h2>${e.id ? 'Editar' : 'Nova'} empresa emitente</h2>
  <p class="dica">Comece pelo certificado A1 <i>ou</i> pelo CNPJ: os dados cadastrais vêm da Receita automaticamente.</p>
  <div class="linha"><div class="campo grande"><label>Certificado A1 (.pfx / .p12) ${e.certificado ? '— já cadastrado; envie outro só para trocar' : ''}</label><input name="cert" type="file" accept=".pfx,.p12"></div>
  <div class="campo"><label>Senha do certificado</label><input name="senha" type="password" autocomplete="new-password"></div></div>
  <div class="linha"><div class="campo"><label>CNPJ *</label><input name="cnpj" class="mono" required value="${esc(docFmt(e.cnpj))}"></div>
  <div class="campo grande"><label>Razão social *</label><input name="razaoSocial" required value="${esc(e.razaoSocial)}"></div></div>
  <p class="dica" id="infoCadastro"></p>
  <div class="linha"><div class="campo"><label>Cód. IBGE do município *</label><input name="codMunicipio" class="mono" required value="${esc(e.codMunicipio ?? '2504009')}"></div>
  <div class="campo"><label>Município</label><input name="municipio" value="${esc(e.municipio ?? 'Campina Grande/PB')}"></div>
  <div class="campo"><label>Inscrição municipal</label><input name="inscricaoMunicipal" value="${esc(e.inscricaoMunicipal)}"></div></div>
  <div class="linha"><div class="campo"><label>Simples Nacional *</label><select name="opSimpNac">${opt(3, 'ME/EPP optante', e.opSimpNac ?? 3)}${opt(2, 'MEI', e.opSimpNac)}${opt(1, 'Não optante', e.opSimpNac)}</select></div>
  <div class="campo"><label>Apuração (ME/EPP)</label><select name="regApTribSN">${opt(1, 'Federal e municipal pelo SN', e.regApTribSN ?? 1)}${opt(2, 'Federal pelo SN, ISS fora', e.regApTribSN)}${opt(3, 'Federal e municipal fora do SN', e.regApTribSN)}</select></div>
  <div class="campo"><label>Regime especial</label><select name="regEspTrib">${[['0', 'Nenhum'], ['1', 'Ato cooperado'], ['2', 'Estimativa'], ['3', 'Microempresa municipal'], ['4', 'Notário/registrador'], ['5', 'Profissional autônomo'], ['6', 'Sociedade de profissionais'], ['9', 'Outros']].map(([v, r]) => opt(v, r, e.regEspTrib ?? '0')).join('')}</select></div></div>
  <div class="linha"><div class="campo"><label>% aprox. tributos SN (ME/EPP)</label><input name="pTotTribSN" class="mono" value="${esc(e.pTotTribSN ?? '')}" placeholder="ex.: 6"></div>
  <div class="campo"><label>% federal (não optante)</label><input name="pTotTribFed" class="mono" value="${esc(e.pTotTribFed ?? '')}"></div>
  <div class="campo"><label>% estadual</label><input name="pTotTribEst" class="mono" value="${esc(e.pTotTribEst ?? '')}"></div>
  <div class="campo"><label>% municipal</label><input name="pTotTribMun" class="mono" value="${esc(e.pTotTribMun ?? '')}"></div></div>
  <div class="linha"><div class="campo pequeno"><label>Série DPS</label><input name="serie" class="mono" value="${esc(e.serie ?? '1')}"></div>
  <div class="campo pequeno"><label>Nº DPS inicial</label><input name="nDpsInicial" class="mono" value="${esc(e.nDpsInicial ?? '1')}"></div>
  <div class="campo grande"><label>Ambiente</label><select name="ambiente">${Object.entries(estado.sistema.ambientes).map(([k, v]) => opt(k, v, e.ambiente ?? 'producao_restrita')).join('')}</select></div></div>
  <label class="check" id="linhaConfirmaProd" ${e.ambiente === 'producao' ? 'hidden' : ''}><input type="checkbox" name="confirmaProd"> Confirmo que, em Produção, as notas emitidas para esta empresa terão valor fiscal</label>
  <p class="dica">A série de 1 a 49999 é a faixa reservada a aplicativo próprio, por isso não colide com notas emitidas no portal (Emissor Web usa 70000 a 79999). O certificado e a senha ficam cifrados (AES-256) na pasta de dados deste computador.</p>
  ${rodapeModal()}`;
}

const lerArquivoBase64 = (arquivo) => new Promise((ok, erro) => {
  const r = new FileReader();
  r.onload = () => ok(String(r.result).split(',')[1]);
  r.onerror = erro;
  r.readAsDataURL(arquivo);
});

/** Liga a leitura do A1 e a consulta do CNPJ ao formulário de empresa. */
function ligarFormEmpresa(f) {
  const info = $('#infoCadastro', f);
  const campo = (n) => f.elements[n];
  let ultimo = so(campo('cnpj').value);

  async function porCnpj() {
    const cnpj = so(campo('cnpj').value);
    campo('cnpj').value = docFmt(cnpj);
    if (cnpj.length !== 14 || cnpj === ultimo) return;
    ultimo = cnpj;
    info.textContent = 'Consultando CNPJ na Receita…';
    try {
      const d = await consultarCnpj(cnpj);
      campo('razaoSocial').value = d.razaoSocial || campo('razaoSocial').value;
      if (d.codMunicipio) campo('codMunicipio').value = d.codMunicipio;
      if (d.municipio) campo('municipio').value = d.municipio;
      if (d.opSimpNac) campo('opSimpNac').value = d.opSimpNac;
      const regime = { 1: 'fora do Simples', 2: 'MEI', 3: 'optante do Simples (ME/EPP)' }[d.opSimpNac] ?? 'regime não informado';
      info.innerHTML = `Dados da Receita: ${esc(d.razaoSocial)} · ${esc(d.municipio)} · <b>${regime}</b> · situação ${esc(d.situacao || '—')}. Confira o regime e preencha a inscrição municipal.${avisoSituacao(d.situacao)}`;
    } catch (err) { info.textContent = err.message; }
  }

  async function porCertificado() {
    const arq = campo('cert').files[0];
    const senha = campo('senha').value;
    if (!arq || !senha) return;
    info.textContent = 'Lendo certificado…';
    try {
      const c = await api('POST', '/api/certificado/ler', { certificadoBase64: await lerArquivoBase64(arq), senhaCertificado: senha });
      const dias = Math.ceil((new Date(c.validade) - Date.now()) / 86400000);
      info.innerHTML = `Certificado de <b>${esc(c.razaoSocial)}</b>, válido até ${dataBr(c.validade)} (${dias} dias).`;
      if (c.cnpj.length === 14) {
        if (so(campo('cnpj').value) && so(campo('cnpj').value) !== c.cnpj) {
          info.innerHTML += ' <b style="color:var(--erro)">O CNPJ do certificado é diferente do informado — corrigido para o do certificado.</b>';
        }
        campo('cnpj').value = docFmt(c.cnpj);
        if (!campo('razaoSocial').value) campo('razaoSocial').value = c.razaoSocial;
        const msg = info.innerHTML;
        await porCnpj();
        info.innerHTML = `${msg}<br>${info.innerHTML}`;
      }
    } catch (err) { info.textContent = err.message; }
  }

  const linhaProd = $('#linhaConfirmaProd', f);
  const ajustarProd = () => { if (linhaProd) linhaProd.hidden = campo('ambiente').value !== 'producao' || linhaProd.dataset.jaProd === '1'; };
  if (linhaProd && linhaProd.hasAttribute('hidden')) linhaProd.dataset.jaProd = '1';
  campo('ambiente').addEventListener('change', ajustarProd);
  ajustarProd();
  campo('cnpj').addEventListener('blur', porCnpj);
  campo('cert').addEventListener('change', () => (campo('senha').value ? porCertificado() : campo('senha').focus()));
  campo('senha').addEventListener('change', porCertificado);
}

async function editarEmpresa(e) {
  const aberto = modal(formEmpresa(e), async (f) => {
    const campos = ['razaoSocial', 'cnpj', 'codMunicipio', 'municipio', 'inscricaoMunicipal', 'opSimpNac', 'regApTribSN', 'regEspTrib', 'pTotTribSN', 'pTotTribFed', 'pTotTribEst', 'pTotTribMun', 'serie', 'nDpsInicial', 'ambiente'];
    const dados = Object.fromEntries(campos.map((c) => [c, valorCampo(f, c)]));
    dados.cnpj = so(dados.cnpj);
    const arq = f.elements.cert.files[0];
    if (arq) { dados.certificadoBase64 = await lerArquivoBase64(arq); dados.senhaCertificado = f.elements.senha.value; }
    if (dados.ambiente === 'producao' && e?.ambiente !== 'producao') {
      // Sem confirm() nativo: em janelas de app ele pode ser bloqueado e travar a troca.
      if (!f.elements.confirmaProd?.checked) throw new Error('Para ativar a Produção, marque a confirmação de que as notas terão valor fiscal.');
      dados.confirmarProducao = true;
    }
    return e?.id ? api('PUT', `/api/empresas/${e.id}`, dados) : api('POST', '/api/empresas', dados);
  });
  ligarFormEmpresa($('#formModal'));
  const ok = await aberto;
  if (ok) { estado.empresa = typeof ok === 'object' ? ok : estado.empresa; await carregarEmpresas(); renderEmpresas(); toast('Empresa salva.'); }
}

function renderEmpresas() {
  const amb = { simulacao: 'Simulação', producao_restrita: 'Homologação', producao: 'Produção' };
  $('#tabEmpresas tbody').innerHTML = estado.empresas.length ? estado.empresas.map((e) => {
    const venc = e.certificado ? new Date(e.certificado.validade) : null;
    const dias = venc ? Math.ceil((venc - Date.now()) / 86400000) : null;
    return `<tr><td>${esc(e.razaoSocial)}<span class="sub">${esc(e.municipio)}</span></td><td class="mono">${docFmt(e.cnpj)}</td><td>${REGIMES[e.opSimpNac]}</td>
    <td><span class="selo ${e.ambiente === 'producao' ? 'autorizada' : 'amb'}">${amb[e.ambiente]}</span></td>
    <td>${venc ? `vence ${venc.toLocaleDateString('pt-BR')}${dias < 30 ? ` <span class="selo rejeitada">${dias} dias</span>` : ''}` : '<span class="sub">não cadastrado</span>'}</td>
    <td class="mono">${esc(e.serie)}/${e.proximoNDps}</td>
    <td class="acoes"><div class="icones">${ico('editar', 'Editar empresa', `data-edit-emp="${e.id}"`)}${ico('excluir', 'Excluir empresa', `data-del-emp="${e.id}"`, 'perigo')}</div></td></tr>`;
  }).join('') : '<tr><td colspan="7" class="vazio">Cadastre a primeira empresa. Comece no modo Simulação para conhecer o sistema sem certificado.</td></tr>';
}

// ------------------------------------------------------------------ navegação
async function mostrarTela(nome, recarregar = true) {
  $$('.tela').forEach((t) => { t.hidden = t.id !== `tela-${nome}`; });
  $$('nav a').forEach((a) => a.classList.toggle('ativo', a.dataset.tela === nome));
  if (!recarregar) return;
  try {
    if (nome === 'historico') await carregarHistorico();
    if (nome === 'tomadores') renderTomadores();
    if (nome === 'servicos') renderServicos();
    if (nome === 'empresas') renderEmpresas();
    if (nome === 'usuarios') await renderUsuarios();
    if (nome === 'emitir' && estado.empresa && !$('#sDesc').value) await sugerirUltima(false);
  } catch (e) { falha(e); }
}
const telaAtual = () => (location.hash.slice(1) || 'emitir');

function ligarEventos() {
  window.addEventListener('hashchange', () => mostrarTela(telaAtual()));
  $('#seletorEmpresa').onchange = async (ev) => {
    await trocarEmpresa(estado.empresas.find((e) => e.id === ev.target.value));
    limparEmissao(telaAtual() === 'emitir');
    mostrarTela(telaAtual());
  };
  $('#formEmissao').onsubmit = emitir;
  $('#btnPrevia').onclick = previa;
  $('#btnLimpar').onclick = () => limparEmissao(false);
  $('#btnUltima').onclick = () => sugerirUltima(true).catch(falha);
  $('#semTomador').onchange = (ev) => { $('#blocoTomador').hidden = ev.target.checked; };
  $('#buscaTomador').onchange = (ev) => {
    const doc = ev.target.value.split('·').pop();
    if (so(doc).length >= 11) aoEscolherTomador(doc).catch(falha);
    ev.target.value = '';
  };
  $('#tDoc').onblur = () => {
    const d = so($('#tDoc').value);
    $('#tDoc').value = docFmt(d);
    if ([11, 14].includes(d.length) && estado.empresa && d !== estado.ultimoDocTomador) {
      estado.ultimoDocTomador = d;
      aoEscolherTomador(d).catch(falha);
    }
  };
  $('#eCep').onblur = buscarCep;
  $('#vServ').onblur = (ev) => { const v = ev.target.value.replace(/\./g, '').replace(',', '.'); if (v && !isNaN(v)) ev.target.value = valorBr(v); };
  $('#favorito').onchange = (ev) => {
    const s = estado.servicos.find((x) => x.id === ev.target.value);
    if (!s) return;
    preencherServicoValores({ servico: s, valores: { vServ: s.vServ || '', aliqIss: s.aliqIss, tpRetISSQN: s.tpRetISSQN } });
    mostrarOrigem(`Serviço preenchido a partir do favorito “${esc(s.apelido)}”.`);
  };
  $('#btnImportar').onclick = (ev) => ocupado(ev.target, importarPortal);
  ['#fDe', '#fAte', '#fStatus', '#fPapel'].forEach((s) => { $(s).onchange = () => carregarHistorico().catch(falha); });
  let t; $('#fBusca').oninput = () => { clearTimeout(t); t = setTimeout(() => carregarHistorico().catch(falha), 300); };
  $('#btnReprocessar').onclick = (ev) => ocupado(ev.target, async () => {
    try { const r = await api('POST', '/api/pendentes/reprocessar'); toast(r.length ? `${r.length} pendência(s) processada(s).` : 'Nenhuma pendência.'); carregarHistorico(); } catch (e) { falha(e); }
  });
  $('#buscaTom').oninput = renderTomadores;
  $('#novoTomador').onclick = () => exigeEmpresa() && editarTomador();
  $('#novoServico').onclick = () => exigeEmpresa() && editarServico();
  $('#novaEmpresa').onclick = () => editarEmpresa();

  const balao = document.createElement('div');
  balao.id = 'dica';
  document.body.append(balao);
  document.body.addEventListener('mouseover', (ev) => {
    const alvo = ev.target.closest('[data-dica]');
    if (!alvo) { balao.classList.remove('visivel'); return; }
    balao.textContent = alvo.dataset.dica;
    const r = alvo.getBoundingClientRect();
    balao.classList.add('visivel');
    const w = balao.offsetWidth;
    const left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), innerWidth - w - 8);
    const top = r.top - balao.offsetHeight - 8;
    balao.style.left = `${left}px`;
    balao.style.top = `${top < 8 ? r.bottom + 8 : top}px`;
  });
  document.addEventListener('scroll', () => balao.classList.remove('visivel'), true);
  document.body.addEventListener('click', async (ev) => {
    const b = ev.target.closest('button');
    if (!b) return;
    const d = b.dataset;
    try {
      if (d.modelo) await usarComoModelo(d.modelo);
      if (d.substituir) await iniciarSubstituicao(d.substituir);
      if (d.cancelar) await cancelarNota(d.cancelar);
      if (d.anexos) await gerenciarAnexos(d.anexos);
      if (d.ativoUsr) { await api('PUT', `/api/usuarios/${d.ativoUsr}/ativo`, { ativo: d.ativo === '1' }); renderUsuarios(); }
      if (d.editTom) await editarTomador(estado.tomadores.find((x) => x.id === d.editTom));
      if (d.emitirTom) { location.hash = '#emitir'; await mostrarTela('emitir', false); limparEmissao(false); await aoEscolherTomador(estado.tomadores.find((x) => x.id === d.emitirTom).documento); }
      if (d.delTom && confirm('Excluir este tomador do cadastro?')) { await api('DELETE', `/api/tomadores/${d.delTom}`); await trocarEmpresa(estado.empresa); renderTomadores(); }
      if (d.editServ) await editarServico(estado.servicos.find((x) => x.id === d.editServ));
      if (d.delServ && confirm('Excluir este serviço favorito?')) { await api('DELETE', `/api/servicos/${d.delServ}`); await trocarEmpresa(estado.empresa); renderServicos(); }
      if (d.editEmp) await editarEmpresa(estado.empresas.find((x) => x.id === d.editEmp));
      if (d.delEmp && confirm('Excluir esta empresa e o certificado guardado?')) { await api('DELETE', `/api/empresas/${d.delEmp}`); estado.empresa = null; await carregarEmpresas(); renderEmpresas(); }
    } catch (e) { falha(e); }
  });
}

// ------------------------------------------------------------------ login
let googleCarregado = false;
function carregarGoogle(clientId) {
  if (!clientId) { $('#ouGoogle').hidden = true; $('#botaoGoogle').innerHTML = ''; return; }
  const desenhar = () => {
    window.google.accounts.id.initialize({ client_id: clientId, callback: (r) => entrarGoogle(r.credential) });
    window.google.accounts.id.renderButton($('#botaoGoogle'), { theme: 'outline', size: 'large', text: 'continue_with', locale: 'pt-BR', width: 340 });
    $('#ouGoogle').hidden = false;
  };
  if (googleCarregado) return desenhar();
  const sc = document.createElement('script');
  sc.src = 'https://accounts.google.com/gsi/client';
  sc.async = true;
  sc.onload = () => { googleCarregado = true; desenhar(); };
  sc.onerror = () => { $('#ouGoogle').hidden = true; };
  document.head.appendChild(sc);
}

async function mostrarLogin() {
  const e = await api('GET', '/api/auth/estado');
  const cadastro = !e.temUsuarios;
  estado.modoCadastro = cadastro;
  $('#telaLogin').hidden = false;
  $('#loginTitulo').textContent = cadastro ? 'Criar sua conta' : 'Entrar';
  $('#loginSub').textContent = cadastro
    ? 'Primeiro acesso nesta instalação: crie a conta de administrador, com o Google ou com e-mail e senha.'
    : 'Use sua conta do Google ou seu e-mail e senha.';
  $('#campoNome').hidden = !cadastro;
  $('#campoSenha2').hidden = !cadastro;
  $('#lSenha').autocomplete = cadastro ? 'new-password' : 'current-password';
  $('#btnLogin').textContent = cadastro ? 'Criar conta e entrar' : 'Entrar';
  $('#erroLogin').textContent = '';
  carregarGoogle(e.googleClientId);
}

async function aposLogin(usuario) {
  estado.usuario = usuario;
  $('#telaLogin').hidden = true;
  $('#usuarioLateral').innerHTML = `${esc(usuario.nome)}<br><span class="mono">${esc(usuario.email)}</span><br><button type="button" id="btnSenha">Alterar senha</button> · <button type="button" id="btnSair">Sair</button>`;
  $('#navUsuarios').hidden = usuario.papel !== 'admin';
  $('#btnSair').onclick = async () => { await api('POST', '/api/auth/sair'); location.reload(); };
  $('#btnSenha').onclick = alterarSenha;
  await carregarEmpresas();
  if (!estado.empresas.length && telaAtual() === 'emitir') location.hash = '#empresas';
  await mostrarTela(telaAtual());
}

async function entrarGoogle(credencial) {
  try { await aposLogin(await api('POST', '/api/auth/google', { credencial })); }
  catch (e) { $('#erroLogin').textContent = e.message; }
}

async function enviarLogin(ev) {
  ev.preventDefault();
  const corpo = { nome: $('#lNome').value.trim(), email: $('#lEmail').value.trim(), senha: $('#lSenha').value };
  if (estado.modoCadastro && corpo.senha !== $('#lSenha2').value) { $('#erroLogin').textContent = 'As senhas não conferem.'; return; }
  await ocupado($('#btnLogin'), async () => {
    try { await aposLogin(await api('POST', estado.modoCadastro ? '/api/auth/registrar' : '/api/auth/login', corpo)); }
    catch (e) { $('#erroLogin').textContent = e.message; }
  });
}

async function alterarSenha() {
  const ok = await modal(`<h2>Alterar senha</h2>
    <div class="campo"><label>Senha atual (vazio se a conta é só Google)</label><input name="atual" type="password" autocomplete="current-password"></div>
    <div class="campo"><label>Nova senha (mín. 8)</label><input name="nova" type="password" autocomplete="new-password" required minlength="8"></div>
    ${rodapeModal('Salvar')}`, (f) => api('PUT', '/api/eu/senha', { senhaAtual: f.elements.atual.value, novaSenha: f.elements.nova.value }));
  if (ok) toast('Senha alterada.');
}

// ------------------------------------------------------------------ usuários
async function renderUsuarios() {
  const [lista, e] = await Promise.all([api('GET', '/api/usuarios'), api('GET', '/api/auth/estado')]);
  $('#cfgGoogle').value = e.googleClientId;
  $('#tabUsuarios tbody').innerHTML = lista.map((u) => `<tr><td>${esc(u.nome)}</td><td class="mono">${esc(u.email)}</td>
    <td>${u.papel === 'admin' ? 'Administrador' : 'Usuário'}${u.inativo ? ' <span class="selo rejeitada">inativo</span>' : ''}</td>
    <td>${u.ultimoAcesso ? new Date(u.ultimoAcesso).toLocaleString('pt-BR') : '—'}</td>
    <td class="acoes">${u.id === estado.usuario.id ? '' : `<div class="icones">${u.inativo ? ico('reativar', 'Reativar usuário', `data-ativo-usr="${u.id}" data-ativo="1"`) : ico('desativar', 'Desativar usuário', `data-ativo-usr="${u.id}" data-ativo="0"`, 'perigo')}</div>`}</td></tr>`).join('');
}

async function novoUsuario() {
  const ok = await modal(`<h2>Novo usuário</h2>
    <div class="linha"><div class="campo"><label>Nome *</label><input name="nome" required></div>
    <div class="campo grande"><label>E-mail *</label><input name="email" type="email" required></div></div>
    <div class="campo"><label>Senha provisória (deixe vazio se ele vai entrar só com o Google desse e-mail)</label><input name="senha" type="password" autocomplete="new-password"></div>
    ${rodapeModal('Criar')}`, (f) => api('POST', '/api/usuarios', { nome: valorCampo(f, 'nome'), email: valorCampo(f, 'email'), senha: f.elements.senha.value || undefined }));
  if (ok) { toast('Usuário criado.'); renderUsuarios(); }
}

async function iniciar() {
  estado.sistema = await api('GET', '/api/sistema');
  $('#versao').textContent = `v${estado.sistema.versao}`;
  ligarEventos();
  $('#formLogin').onsubmit = enviarLogin;
  $('#novoUsuario').onclick = novoUsuario;
  $('#salvarGoogle').onclick = async () => {
    try { await api('PUT', '/api/config/google', { googleClientId: $('#cfgGoogle').value }); toast('Client ID do Google salvo.'); } catch (e) { falha(e); }
  };
  const e = await api('GET', '/api/auth/estado');
  if (!e.usuario) { $('#dComp').value = hoje(); return mostrarLogin(); }
  $('#dComp').value = hoje();
  return aposLogin(e.usuario);
}
iniciar().catch(falha);
