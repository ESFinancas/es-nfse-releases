// DANFSe conforme a Nota Técnica SE/CGNFS-e nº 008 (v1.02): blocos, títulos,
// ordem dos campos, sombreamento 5%, fontes (Arial ≈ Helvetica) e marcas d'água.
// O texto é medido antes de desenhar: nada ultrapassa as caixas.
import PDFDocument from 'pdfkit';
import QRCode from 'qrcode';

const PAG_W = 595.28;
const PAG_H = 841.89;
const M = 12;                 // margem (NT: 0,15–0,20 cm; pequena folga para impressoras)
const W = PAG_W - M * 2;
const CINZA5 = '#f2f2f2';     // sombreamento 5%
const PRETO = '#000000';
const PAD = 3;

// ---------------------------------------------------------------- formatação
const traco = '-';
const vazio = (v) => v === undefined || v === null || v === '';
const moeda = (v) => (vazio(v) ? traco : `R$ ${Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
const pct = (v) => (vazio(v) ? traco : `${Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 4 })}%`);
const fuso = { timeZone: 'America/Sao_Paulo' };
const data = (d) => (d ? new Date(d).toLocaleDateString('pt-BR', fuso) : traco);
const dataHora = (d) => (d ? new Date(d).toLocaleString('pt-BR', fuso).replace(',', '') : traco);
const so = (s) => String(s ?? '').replace(/\D/g, '');
function docId(id = {}) {
  const v = id.CNPJ ?? id.CPF ?? id.NIF ?? '';
  const d = so(v);
  if (d.length === 14) return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  if (d.length === 11) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  return v || traco;
}
const cep = (c) => (so(c).length === 8 ? so(c).replace(/(\d{5})(\d{3})/, '$1-$2') : c || traco);

// ---------------------------------------------------------------- domínios (imprime a descrição, não o código)
const TP_EMIT = { 1: 'Prestador', 2: 'Tomador', 3: 'Intermediário' };
const CSTAT = { 100: 'NFS-e Gerada', 101: 'NFS-e de Substituição Gerada', 102: 'NFS-e de Decisão Judicial', 103: 'NFS-e Avulsa', 107: 'NFS-e MEI' };
const FIN = { 0: 'NFS-e regular', 1: 'NFS-e de débito', 2: 'NFS-e de crédito' };
const OP_SN = { 1: 'Não Optante', 2: 'Optante - Microempreendedor Individual (MEI)', 3: 'Optante - Microempresa ou Empresa de Pequeno Porte (ME/EPP)' };
const REG_AP_SN = {
  1: 'Regime de apuração dos tributos federais e municipal pelo SN',
  2: 'Regime de apuração dos tributos federais pelo SN e o ISSQN pela NFS-e conforme legislação municipal',
  3: 'Regime de apuração dos tributos federais e municipal pela NFS-e conforme legislações federal e municipal',
};
const REG_ESP = { 0: 'Nenhum', 1: 'Ato Cooperado (Cooperativa)', 2: 'Estimativa', 3: 'Microempresa Municipal', 4: 'Notário ou Registrador', 5: 'Profissional Autônomo', 6: 'Sociedade de Profissionais', 9: 'Outros' };
const TRIB_ISSQN = { 1: 'Operação Tributável', 2: 'Imunidade', 3: 'Exportação de Serviço', 4: 'Não Incidência' };
const RET_ISSQN = { 1: 'Não Retido', 2: 'Retido pelo Tomador', 3: 'Retido pelo Intermediário' };
const RET_PISCOFINS = { 1: 'PIS/COFINS/CSLL retidos', 2: 'PIS/COFINS/CSLL não retidos' };
const desc = (tab, v) => (vazio(v) ? traco : tab[v] ?? String(v));

// ---------------------------------------------------------------- primitivas de desenho
function medir(pdf, texto, largura, tam = 7, fonte = 'Helvetica') {
  pdf.font(fonte).fontSize(tam);
  return pdf.heightOfString(String(texto ?? traco), { width: largura });
}

/**
 * Linha de células { r: rótulo, v: valor, w: fração da largura, sombra?, tam?, negrito? }.
 * `larguraTotal` permite linhas mais curtas (bloco de identificação ao lado do QR Code).
 */
function linha(pdf, y, cels, { rotuloTam = 6, larguraTotal = W } = {}) {
  // rótulo e valor são medidos: rótulos longos quebram linha sem invadir o valor
  const hRot = Math.max(...cels.map((c) => medir(pdf, c.r, larguraTotal * c.w - PAD * 2, rotuloTam, 'Helvetica-Bold')));
  const alturas = cels.map((c) => hRot + 0.5 + medir(pdf, c.v, larguraTotal * c.w - PAD * 2, c.tam ?? 7, c.negrito ? 'Helvetica-Bold' : 'Helvetica'));
  const h = Math.max(...alturas) + PAD * 2 - 1;
  let x = M;
  for (const c of cels) {
    const w = larguraTotal * c.w;
    if (c.sombra) pdf.rect(x, y, w, h).fill(CINZA5);
    pdf.fillColor(PRETO).font('Helvetica-Bold').fontSize(rotuloTam)
      .text(c.r, x + PAD, y + PAD, { width: w - PAD * 2 });
    pdf.font(c.negrito ? 'Helvetica-Bold' : 'Helvetica').fontSize(c.tam ?? 7)
      .text(String(c.v ?? traco), x + PAD, y + PAD + hRot + 0.5, { width: w - PAD * 2 });
    x += w;
  }
  pdf.lineWidth(0.5).strokeColor(PRETO);
  x = M;
  for (const c of cels.slice(0, -1)) { x += larguraTotal * c.w; pdf.moveTo(x, y).lineTo(x, y + h).stroke(); }
  pdf.moveTo(M, y + h).lineTo(M + larguraTotal, y + h).stroke();
  return y + h;
}

function titulo(pdf, y, texto) {
  const h = 11;
  pdf.rect(M, y, W, h).fill(CINZA5);
  pdf.fillColor(PRETO).font('Helvetica-Bold').fontSize(7).text(texto.toUpperCase(), M + PAD, y + 2.5, { width: W - PAD * 2, lineBreak: false });
  pdf.lineWidth(0.5).strokeColor(PRETO).moveTo(M, y + h).lineTo(M + W, y + h).stroke();
  return y + h;
}

function frase(pdf, y, texto) {
  const h = 12;
  pdf.fillColor(PRETO).font('Helvetica-Bold').fontSize(7).text(texto, M + PAD, y + 3, { width: W - PAD * 2, lineBreak: false });
  pdf.lineWidth(0.5).strokeColor(PRETO).moveTo(M, y + h).lineTo(M + W, y + h).stroke();
  return y + h;
}

function marcaDagua(pdf, texto) {
  pdf.save();
  pdf.rotate(-35, { origin: [PAG_W / 2, PAG_H / 2] });
  pdf.font('Helvetica-Bold').fontSize(80).fillColor('#a6a6a6').fillOpacity(0.45)
    .text(texto, 0, PAG_H / 2 - 45, { width: PAG_W, align: 'center', lineBreak: false });
  pdf.restore();
  pdf.fillOpacity(1);
}

// ---------------------------------------------------------------- blocos de pessoa (prestador, tomador, destinatário, intermediário)
function enderecoTexto(end) {
  if (!end) return traco;
  return [end.xLgr, end.nro, end.xCpl, end.xBairro].filter(Boolean).join(', ') || traco;
}

function blocoPessoa(pdf, y, p, { comSimples = false, rotuloEmail = 'E-mail', regTrib, municipio } = {}) {
  const end = p.end ?? {};
  const nac = end.localidade?.endNac ?? (end.cMun ? end : undefined);
  const ext = end.localidade?.endExt;
  const munUf = municipio ?? ext?.xCidade ?? (nac?.cMun ? `${nac.cMun}${end.UF ? ` / ${end.UF}` : ''}` : traco);
  y = linha(pdf, y, [
    { r: 'CNPJ / CPF / NIF', v: docId(p.identificador), w: 0.25 },
    { r: 'Indicador Municipal (Inscrição)', v: p.IM ?? traco, w: 0.25 },
    { r: 'Telefone', v: p.fone ?? traco, w: 0.2 },
    { r: 'Município / Sigla UF', v: munUf, w: 0.3 },
  ]);
  y = linha(pdf, y, [
    { r: 'Nome / Nome Empresarial', v: p.xNome ?? traco, w: 0.5, negrito: true },
    { r: 'Código IBGE / CEP', v: nac ? `${nac.cMun ?? traco} / ${cep(nac.CEP)}` : ext?.cEndPost ?? traco, w: 0.2 },
    { r: rotuloEmail, v: p.email ?? traco, w: 0.3 },
  ]);
  const cels = [{ r: 'Endereço', v: enderecoTexto(end), w: comSimples ? 0.4 : 1 }];
  if (comSimples) {
    cels.push(
      { r: 'Simples Nacional na Data de Competência', v: desc(OP_SN, regTrib?.opSimpNac), w: 0.3 },
      { r: 'Regime de Apuração Tributária pelo SN', v: desc(REG_AP_SN, regTrib?.regApTribSN), w: 0.3 },
    );
  }
  return linha(pdf, y, cels);
}

/**
 * Gera o DANFSe (Buffer PDF) a partir da NFS-e parseada pela open-nfse.
 * @param opts.ambiente 'producao' | 'producao_restrita' | 'simulacao'
 * @param opts.situacao 'cancelada' | 'substituida' (marca d'água)
 * @param opts.observacoes texto extra nas informações complementares
 */
export async function gerarDanfsePdf(nfse, opts = {}) {
  const inf = nfse.infNFSe;
  const dps = inf.DPS.infDPS;
  const emit = inf.emit ?? {};
  const prest = dps.prest ?? {};
  const toma = dps.toma;
  const interm = dps.interm;
  const cServ = dps.serv.cServ;
  const vDps = dps.valores ?? {};
  const tribMun = vDps.trib?.tribMun ?? {};
  const tribFed = vDps.trib?.tribFed ?? {};
  const piscofins = tribFed.piscofins ?? {};
  const totTrib = vDps.trib?.totTrib ?? {};
  const v = inf.valores ?? {};
  const ibscbs = inf.IBSCBS;       // grupo IBS/CBS da NFS-e (RTC), quando existir
  const ibsDps = dps.IBSCBS;       // grupo IBS/CBS da DPS (RTC), quando existir
  const producao = opts.ambiente === 'producao';
  const chave = String(inf.chaveAcesso ?? '').replace(/^NFS/, '');
  const urlConsulta = `${producao ? 'https://adn.nfse.gov.br' : 'https://adn.producaorestrita.nfse.gov.br'}/contribuintes/consulta?chave=${chave}`;
  const qr = await QRCode.toBuffer(urlConsulta, { margin: 0, width: 240, errorCorrectionLevel: 'M' });

  const pdf = new PDFDocument({ size: 'A4', margin: M, info: { Title: `DANFSe ${inf.nNFSe} - ${chave}`, Producer: 'ES NFS-e' } });
  const partes = [];
  pdf.on('data', (b) => partes.push(b));
  const fim = new Promise((ok) => pdf.on('end', () => ok(Buffer.concat(partes))));

  // ============================================================ cabeçalho
  let y = M;
  const hCab = 34;
  pdf.rect(M, y, W, hCab).fill(CINZA5);
  pdf.fillColor('#1351b4').font('Helvetica-Bold').fontSize(18).text('NFS', M + 8, y + 8, { continued: true })
    .fillColor('#168821').text('-e');
  pdf.fillColor(PRETO).font('Helvetica-Bold').fontSize(9)
    .text('DANFSe v2.0', M, y + 8, { width: W, align: 'center' })
    .text('Documento Auxiliar da NFS-e', M, y + 19, { width: W, align: 'center' });
  pdf.font('Helvetica').fontSize(8).text(inf.xLocEmi ?? '', M + W - 190, y + 5, { width: 182, align: 'right', lineBreak: false, ellipsis: true });
  pdf.fontSize(6)
    .text(`Ambiente gerador: ${inf.ambGer === '1' ? 'Prefeitura' : 'Sefin Nacional NFS-e'}`, M + W - 190, y + 16, { width: 182, align: 'right', lineBreak: false })
    .text(`Tipo de ambiente: ${producao ? 'Produção' : 'Homologação'}`, M + W - 190, y + 24, { width: 182, align: 'right', lineBreak: false });
  y += hCab;
  if (!producao) {
    pdf.fillColor('#d00000').font('Helvetica-Bold').fontSize(9)
      .text(opts.ambiente === 'simulacao' ? 'SIMULAÇÃO - NFS-e SEM VALIDADE JURÍDICA' : 'NFS-e SEM VALIDADE JURÍDICA', M, y + 2, { width: W, align: 'center' });
    y += 13;
  }
  pdf.lineWidth(0.5).strokeColor(PRETO).moveTo(M, y).lineTo(M + W, y).stroke();

  // ============================================================ chave + dados da NFS-e, com QR Code à direita
  const wQr = 80;
  const Wid = W - wQr;
  const yIdIni = y;
  const id = (cels) => linha(pdf, y, cels, { rotuloTam: 7, larguraTotal: Wid });
  y = id([{ r: 'CHAVE DE ACESSO DA NFS-E', v: chave, w: 1 }]);
  y = id([
    { r: 'NÚMERO DA NFS-E', v: inf.nNFSe, w: 0.3 },
    { r: 'COMPETÊNCIA DA NFS-E', v: data(dps.dCompet), w: 0.3 },
    { r: 'DATA E HORA DA EMISSÃO DA NFS-E', v: dataHora(inf.dhProc), w: 0.4 },
  ]);
  y = id([
    { r: 'NÚMERO DA DPS', v: dps.nDPS, w: 0.3 },
    { r: 'SÉRIE DA DPS', v: dps.serie, w: 0.3 },
    { r: 'DATA E HORA DA EMISSÃO DA DPS', v: dataHora(dps.dhEmi), w: 0.4 },
  ]);
  y = id([
    { r: 'EMITENTE DA NFS-E', v: desc(TP_EMIT, dps.tpEmit), w: 0.3, sombra: true },
    { r: 'SITUAÇÃO DA NFS-E', v: opts.situacao === 'cancelada' ? 'NFS-e Cancelada' : opts.situacao === 'substituida' ? 'NFS-e Substituída' : desc(CSTAT, inf.cStat), w: 0.3 },
    { r: 'FINALIDADE', v: desc(FIN, ibsDps?.finNFSe ?? 0), w: 0.4 },
  ]);
  const xQr = M + Wid;
  pdf.lineWidth(0.5).strokeColor(PRETO);
  // QR + legenda (6 pt, 3 linhas) dentro da altura do bloco de identificação
  const legenda = 'Autenticidade: leia o código QR ou consulte a chave de acesso no portal nacional da NFS-e';
  const hLeg = medir(pdf, legenda, wQr - 6, 5.2);
  const ladoQr = Math.max(40, Math.min(62, y - yIdIni - hLeg - 8));
  if (y - yIdIni < ladoQr + hLeg + 8) { // garante espaço: estica o bloco se preciso
    const extra = ladoQr + hLeg + 8 - (y - yIdIni);
    pdf.lineWidth(0.5).strokeColor(PRETO).moveTo(M, y + extra).lineTo(M + Wid, y + extra).stroke();
    y += extra;
  }
  pdf.moveTo(xQr, yIdIni).lineTo(xQr, y).stroke();
  pdf.image(qr, xQr + (wQr - ladoQr) / 2, yIdIni + 4, { width: ladoQr, height: ladoQr });
  pdf.font('Helvetica').fontSize(5.2).fillColor(PRETO)
    .text(legenda, xQr + 3, yIdIni + ladoQr + 6, { width: wQr - 6, align: 'center' });
  pdf.moveTo(M, y).lineTo(M + W, y).stroke();

  // ============================================================ prestador
  y = titulo(pdf, y, 'Prestador / Fornecedor');
  y = blocoPessoa(pdf, y, { ...emit, IM: emit.IM ?? prest.IM, end: emit.enderNac }, {
    comSimples: true, rotuloEmail: 'Email', regTrib: prest.regTrib,
    municipio: `${inf.xLocEmi ?? emit.enderNac?.cMun ?? traco}${emit.enderNac?.UF ? ` / ${emit.enderNac.UF}` : ''}`,
  });

  // ============================================================ tomador
  y = titulo(pdf, y, 'Tomador / Adquirente');
  y = toma ? blocoPessoa(pdf, y, toma) : frase(pdf, y, 'TOMADOR/ADQUIRENTE DA OPERAÇÃO NÃO IDENTIFICADO NA NFS-e');

  // ============================================================ destinatário
  const dest = ibsDps?.dest;
  y = titulo(pdf, y, 'Destinatário da Operação');
  if (dest) y = blocoPessoa(pdf, y, dest);
  else y = frase(pdf, y, toma ? 'O DESTINATÁRIO É O PRÓPRIO TOMADOR/ADQUIRENTE DA OPERAÇÃO' : 'DESTINATÁRIO DA OPERAÇÃO NÃO IDENTIFICADO NA NFS-e');

  // ============================================================ intermediário
  y = titulo(pdf, y, 'Intermediário da Operação');
  y = interm ? blocoPessoa(pdf, y, interm) : frase(pdf, y, 'INTERMEDIÁRIO DA OPERAÇÃO NÃO IDENTIFICADO NA NFS-e');

  // ============================================================ serviço prestado
  y = titulo(pdf, y, 'Serviço Prestado');
  y = linha(pdf, y, [
    { r: 'Código de Tributação Nacional / Municipal', v: `${cServ.cTribNac}${cServ.cTribMun ? ` / ${cServ.cTribMun}` : ''}`, w: 0.3 },
    { r: 'Código da NBS', v: cServ.cNBS ?? traco, w: 0.2 },
    { r: 'Local da Prestação / Sigla UF / País', v: inf.xLocPrestacao ?? dps.serv.locPrest?.cLocPrestacao ?? traco, w: 0.5 },
  ]);
  {
    const descTrib = inf.xTribMun ?? inf.xTribNac ?? traco; // sem rótulo (NT 008)
    const h = medir(pdf, descTrib, W - PAD * 2) + PAD * 2;
    pdf.fillColor(PRETO).font('Helvetica').fontSize(7).text(descTrib, M + PAD, y + PAD, { width: W - PAD * 2 });
    pdf.lineWidth(0.5).strokeColor(PRETO).moveTo(M, y + h).lineTo(M + W, y + h).stroke();
    y += h;
  }
  y = linha(pdf, y, [{ r: 'Descrição do Serviço', v: cServ.xDescServ, w: 1 }]);

  // ============================================================ tributação municipal
  y = titulo(pdf, y, 'Tributação Municipal (ISSQN)');
  if (vazio(tribMun.tribISSQN)) {
    y = frase(pdf, y, 'TRIBUTAÇÃO MUNICIPAL (ISSQN) - OPERAÇÃO NÃO SUJEITA AO ISSQN');
  } else {
    y = linha(pdf, y, [
      { r: 'Tipo de Tributação do ISSQN', v: desc(TRIB_ISSQN, tribMun.tribISSQN), w: 0.25 },
      { r: 'Município / Sigla UF / País da Incidência do ISSQN', v: inf.xLocIncid ?? traco, w: 0.3 },
      { r: 'Regime Especial de Tributação do ISSQN', v: desc(REG_ESP, prest.regTrib?.regEspTrib), w: 0.25 },
      { r: 'Tipo de Imunidade do ISSQN', v: tribMun.tpImunidade ?? traco, w: 0.2 },
    ]);
    y = linha(pdf, y, [
      { r: 'Suspensão da Exigibilidade do ISSQN', v: tribMun.exigSusp ? 'Sim' : 'Não', w: 0.25 },
      { r: 'Número Processo Suspensão', v: tribMun.exigSusp?.nProcesso ?? traco, w: 0.3 },
      { r: 'Benefício Municipal', v: tribMun.BM?.nBM ?? traco, w: 0.25 },
      { r: 'Cálculo do BM', v: moeda(v.vCalcBM ?? tribMun.BM?.vRedBCBM), w: 0.2 },
    ]);
    y = linha(pdf, y, [
      { r: 'Total Deduções/Reduções', v: moeda(v.vDR ?? v.vCalcDR), w: 0.17 },
      { r: 'Desconto Incondicionado', v: moeda(vDps.vDescCondIncond?.vDescIncond), w: 0.17 },
      { r: 'BC ISSQN', v: moeda(v.vBC), w: 0.16 },
      { r: 'Alíquota Aplicada', v: pct(v.pAliqAplic), w: 0.16 },
      { r: 'Retenção do ISSQN', v: desc(RET_ISSQN, tribMun.tpRetISSQN), w: 0.18 },
      { r: 'ISSQN Apurado', v: moeda(v.vISSQN), w: 0.16 },
    ]);
  }

  // ============================================================ tributação federal (exceto CBS)
  y = titulo(pdf, y, 'Tributação Federal (Exceto CBS)');
  const ate2026 = new Date(dps.dCompet).getUTCFullYear() <= 2026;
  const contribRet = piscofins.tpRetPisCofins === '1'
    ? Number(tribFed.vRetCSLL ?? 0) + Number(piscofins.vPis ?? 0) + Number(piscofins.vCofins ?? 0)
    : tribFed.vRetCSLL;
  const celsFed = [
    { r: 'IRRF', v: moeda(tribFed.vRetIRRF), w: 0.16 },
    { r: 'Contribuição Previdenciária - Retida', v: moeda(tribFed.vRetCP), w: 0.2 },
    { r: 'Contribuições Sociais - Retidas', v: moeda(contribRet), w: 0.2 },
  ];
  if (ate2026) {
    celsFed.push(
      { r: 'PIS - Débito Apuração Própria', v: moeda(piscofins.tpRetPisCofins === '1' ? 0 : piscofins.vPis), w: 0.14 },
      { r: 'COFINS - Débito Apuração Própria', v: moeda(piscofins.tpRetPisCofins === '1' ? 0 : piscofins.vCofins), w: 0.14 },
      { r: 'Descrição Contrib. Sociais - Retidas', v: desc(RET_PISCOFINS, piscofins.tpRetPisCofins), w: 0.16 },
    );
  } else {
    celsFed[celsFed.length - 1].w += 0.44;
  }
  y = linha(pdf, y, celsFed);

  // ============================================================ tributação IBS / CBS
  y = titulo(pdf, y, 'Tributação IBS / CBS');
  const iv = ibscbs?.valores ?? {};
  const g = ibsDps?.valores?.trib?.gIBSCBS ?? {};
  const tot = ibscbs?.totCIBS ?? {};
  y = linha(pdf, y, [
    { r: 'CST / cClassTrib', v: g.CST ? `${g.CST} / ${g.cClassTrib ?? traco}` : traco, w: 0.2 },
    { r: 'Indicador de Operação / Código IBGE Incidência / Município Incidência / Sigla UF', v: ibscbs ? [ibsDps?.cIndOp, ibscbs.cLocalidadeIncid, ibscbs.xLocalidadeIncid].filter(Boolean).join(' / ') || traco : traco, w: 0.5 },
    { r: 'Exclusões e Reduções da Base de Cálculo', v: moeda(iv.vCalcReeRepRes), w: 0.3 },
  ]);
  y = linha(pdf, y, [
    { r: 'Base de Cálculo após Exclusões e Reduções', v: moeda(iv.vBC), w: 0.25 },
    { r: 'Red. Alíquota IBS / Red. Alíquota CBS', v: iv.uf || iv.fed ? `${pct(iv.uf?.pRedAliqUF)} / ${pct(iv.mun?.pRedAliqMun)} / ${pct(iv.fed?.pRedAliqCBS)}` : traco, w: 0.25 },
    { r: 'Alíquota - IBS UF / IBS Mun', v: iv.uf || iv.mun ? `${pct(iv.uf?.pIBSUF)} / ${pct(iv.mun?.pIBSMun)}` : traco, w: 0.25 },
    { r: 'Alíquota - CBS', v: pct(iv.fed?.pCBS), w: 0.25 },
  ]);
  y = linha(pdf, y, [
    { r: 'Alíq. Efetiva Municipal - IBS', v: pct(iv.mun?.pAliqEfetMun), w: 0.17 },
    { r: 'Valor Apurado Municipal - IBS', v: moeda(tot.gIBS?.gIBSMunTot?.vIBSMun), w: 0.17 },
    { r: 'Alíq. Efetiva Estadual - IBS', v: pct(iv.uf?.pAliqEfetUF), w: 0.16 },
    { r: 'Valor Apurado Estadual - IBS', v: moeda(tot.gIBS?.gIBSUFTot?.vIBSUF), w: 0.17 },
    { r: 'Valor Total Apurado - IBS', v: moeda(tot.gIBS?.vIBSTot), w: 0.17 },
    { r: 'Alíquota Efetiva - CBS', v: pct(iv.fed?.pAliqEfetCBS), w: 0.16 },
  ]);
  y = linha(pdf, y, [{ r: 'Valor Total Apurado - CBS', v: moeda(tot.gCBS?.vCBS), w: 1 }]);

  // ============================================================ valor total
  y = titulo(pdf, y, 'Valor Total da NFS-e');
  const totIbsCbs = tot.gIBS || tot.gCBS ? Number(tot.gIBS?.vIBSTot ?? 0) + Number(tot.gCBS?.vCBS ?? 0) : undefined;
  y = linha(pdf, y, [
    { r: 'Valor da Operação / Serviço', v: moeda(vDps.vServPrest?.vServ), w: 0.2 },
    { r: 'Desconto Incondicionado', v: moeda(vDps.vDescCondIncond?.vDescIncond), w: 0.15 },
    { r: 'Desconto Condicionado', v: moeda(vDps.vDescCondIncond?.vDescCond), w: 0.15 },
    { r: 'Total das Retenções (ISSQN / Federais)', v: moeda(v.vTotalRet), w: 0.25 },
    { r: 'Valor Líquido da NFS-e', v: moeda(v.vLiq), w: 0.25, negrito: true, tam: 8 },
  ]);
  y = linha(pdf, y, [
    { r: 'Total do IBS/CBS', v: moeda(totIbsCbs), w: 0.5 },
    { r: 'Valor Líquido da NFS-e + IBS/CBS', v: moeda(tot.vTotNF ?? v.vLiq), w: 0.5, sombra: true, negrito: true, tam: 8 },
  ]);

  // ============================================================ informações complementares
  y = titulo(pdf, y, 'Informações Complementares');
  const infoCompl = dps.serv.infoCompl ?? {};
  const partesInfo = [
    infoCompl.xInfComp,
    dps.subst?.chSubstda ? `NFS-e Subst.: ${dps.subst.chSubstda}` : null,
    infoCompl.docRef,
    dps.serv.obra?.cObra ? `Cod. Obra: ${dps.serv.obra.cObra}` : null,
    dps.serv.obra?.inscImobFisc ? `Insc. Imob.: ${dps.serv.obra.inscImobFisc}` : null,
    dps.serv.atvEvento?.idAtvEvt ? `Cod. Evt.: ${dps.serv.atvEvento.idAtvEvt}` : null,
    infoCompl.idDocTec ? `Doc. Tec.: ${infoCompl.idDocTec}` : null,
    infoCompl.xPed ? `Núm. Ped.: ${infoCompl.xPed}` : null,
    infoCompl.gItemPed?.xItemPed ? `Item Ped.: ${[].concat(infoCompl.gItemPed.xItemPed).join(', ')}` : null,
    inf.xOutInf ? `Inf. A. T. Mun.: ${inf.xOutInf}` : null,
    opts.observacoes,
  ].filter(Boolean);
  let fed = traco; let est = traco; let mun = traco;
  if (totTrib.vTotTrib) { fed = moeda(totTrib.vTotTrib.vTotTribFed); est = moeda(totTrib.vTotTrib.vTotTribEst); mun = moeda(totTrib.vTotTrib.vTotTribMun); }
  else if (totTrib.pTotTrib) { fed = pct(totTrib.pTotTrib.pTotTribFed); est = pct(totTrib.pTotTrib.pTotTribEst); mun = pct(totTrib.pTotTrib.pTotTribMun); }
  else if (totTrib.pTotTribSN != null) { fed = `${pct(totTrib.pTotTribSN)} (Simples Nacional)`; }
  const linhaTot = `Totais Aproximados dos Tributos cfe. Lei nº 12.741/2012: Federais: ${fed}; Estaduais: ${est}; Municipais: ${mun}`;
  let texto = partesInfo.join(' | ');
  if (texto.length > 1997 - linhaTot.length) texto = `${texto.slice(0, 1994 - linhaTot.length)}...`; // a linha de totais nunca é truncada
  const textoFinal = texto ? `${texto} | ${linhaTot}` : linhaTot;
  {
    const espaco = PAG_H - M - 10 - y;
    const h = Math.max(medir(pdf, textoFinal, W - PAD * 2) + PAD * 2, Math.min(espaco, 70));
    pdf.fillColor(PRETO).font('Helvetica').fontSize(7).text(textoFinal, M + PAD, y + PAD, { width: W - PAD * 2 });
    y += h;
  }

  // borda da página (1 pt)
  pdf.lineWidth(1).strokeColor(PRETO).rect(M, M, W, y - M).stroke();
  pdf.page.margins.bottom = 0;
  pdf.font('Helvetica').fontSize(5.5).fillColor('#555555')
    .text(`Gerado pelo ES NFS-e em ${dataHora(new Date())} a partir do XML oficial da NFS-e.`, M, PAG_H - 9, { width: W, align: 'right', lineBreak: false });

  // marca d'água por cima de tudo, translúcida (NT 008, §2.5)
  if (opts.situacao === 'cancelada') marcaDagua(pdf, 'CANCELADA');
  if (opts.situacao === 'substituida') marcaDagua(pdf, 'SUBSTITUÍDA');

  pdf.end();
  return fim;
}
