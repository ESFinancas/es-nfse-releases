import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  ExpiredCertificateError,
  ForbiddenError,
  InvalidCepError,
  InvalidCertificateError,
  InvalidCertificatePasswordError,
  InvalidCnpjError,
  InvalidCpfError,
  NetworkError,
  RuleViolationError,
  TimeoutError,
  UnauthorizedError,
  XsdValidationError,
} from 'open-nfse';
import * as db from './db.js';
import { apagarCertificado, salvarCertificado } from './cofre.js';
import * as nfse from './nfse.js';
import { LEIAUTES, MODOS_IBSCBS, leiauteVigente } from './leiaute.js';
import { gerarRequerimentoPdf } from './requerimento.js';
import { promises as fsp } from 'node:fs';
import * as auth from './auth.js';
import { VERSAO } from './versao.js';

const app = express();
const PORTA = Number(process.env.PORTA ?? 3737);
const HOST = process.env.HOST ?? '127.0.0.1'; // só a própria máquina acessa
const PUBLIC = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

app.use(express.json({ limit: '16mb' }));
app.use(express.static(PUBLIC));
app.use(auth.exigirLogin);

const so = (s) => String(s ?? '').replace(/\D/g, '');
const rota = (fn) => (req, res, next) => Promise.resolve(fn(req, res)).catch(next);

async function empresaOu404(req, res) {
  const empresa = await db.obter('empresas', req.params.id);
  if (!empresa) res.status(404).json({ erro: 'Empresa não encontrada.' });
  return empresa;
}

const publica = ({ ...e }) => e; // a senha e o .pfx nunca ficam no registro

// ---------------------------------------------------------------- sistema
app.get('/api/sistema', rota(async (_req, res) => {
  const leiaute = await nfse.leiauteConfigurado();
  res.json({ versao: VERSAO, ambientes: nfse.AMBIENTES, leiautes: LEIAUTES, modosIbsCbs: MODOS_IBSCBS, leiaute, leiauteHoje: leiauteVigente(leiaute) });
}));

// ---------------------------------------------------------------- contas
app.get('/api/auth/estado', rota(async (req, res) => {
  const s = await auth.sessao(req);
  const { googleClientId } = await auth.config();
  res.json({ temUsuarios: await auth.haUsuarios(), googleClientId, usuario: s?.usuario ?? null });
}));

app.post('/api/auth/registrar', rota(async (req, res) => {
  if (await auth.haUsuarios()) throw auth.erro('Cadastro aberto só na primeira conta. Peça acesso ao administrador.', 403);
  await auth.criarUsuario(req.body);
  res.json(await auth.loginSenha(res, req.body));
}));

app.post('/api/auth/login', rota(async (req, res) => res.json(await auth.loginSenha(res, req.body))));
app.post('/api/auth/google', rota(async (req, res) => res.json(await auth.loginGoogle(res, req.body.credencial))));
app.post('/api/auth/sair', rota(async (req, res) => { await auth.sair(req, res); res.status(204).end(); }));

const soAdmin = (req) => { if (req.usuario?.papel !== 'admin') throw auth.erro('Somente o administrador pode fazer isso.', 403); };

app.get('/api/usuarios', rota(async (req, res) => { soAdmin(req); res.json(await auth.listarUsuarios()); }));
app.post('/api/usuarios', rota(async (req, res) => {
  soAdmin(req);
  const { nome, email, senha } = req.body;
  res.status(201).json(await auth.criarUsuario({ nome, email, senha, google: senha ? undefined : { sub: null } }, { criadoPor: req.usuario.id }));
}));
app.put('/api/usuarios/:id/ativo', rota(async (req, res) => {
  soAdmin(req);
  if (req.params.id === req.usuario.id) throw auth.erro('Você não pode desativar a própria conta.');
  await db.atualizar('usuarios', req.params.id, { inativo: req.body.ativo === false });
  res.status(204).end();
}));
app.put('/api/eu/senha', rota(async (req, res) => {
  await auth.alterarSenha(req.usuario.id, req.body.senhaAtual, req.body.novaSenha);
  res.status(204).end();
}));
app.put('/api/config/google', rota(async (req, res) => {
  soAdmin(req);
  const id = String(req.body.googleClientId ?? '').trim();
  if (id && !/\.apps\.googleusercontent\.com$/.test(id)) throw auth.erro('Client ID do Google inválido (termina em .apps.googleusercontent.com).');
  await auth.salvarConfig({ googleClientId: id });
  res.status(204).end();
}));

app.put('/api/config/leiaute', rota(async (req, res) => {
  soAdmin(req);
  const leiaute = await nfse.salvarLeiaute(String(req.body.leiaute ?? ''));
  res.json({ leiaute, leiauteHoje: leiauteVigente(leiaute) });
}));

// ---------------------------------------------------------------- empresas
const CAMPOS_EMPRESA = [
  'razaoSocial', 'cnpj', 'codMunicipio', 'municipio', 'inscricaoMunicipal', 'opSimpNac', 'regApTribSN',
  'regEspTrib', 'pTotTribSN', 'pTotTribFed', 'pTotTribEst', 'pTotTribMun', 'aliqIssPadrao', 'serie',
  'nDpsInicial', 'ambiente',
  // dados que entram na descrição da nota
  'banco', 'agencia', 'conta', 'tipoConta', 'pix', 'favorecido', 'incluirBanco', 'profissional', 'conselho',
  // IBS/CBS (Reforma Tributária): { modo, inicio, CST, cClassTrib, cIndOp, indFinal }
  'ibscbs',
];
const escolher = (obj, campos) => Object.fromEntries(campos.filter((c) => obj[c] !== undefined).map((c) => [c, obj[c]]));

async function gravarCertificadoSeVeio(empresaId, body) {
  if (!body.certificadoBase64) return {};
  if (!body.senhaCertificado) throw nfse.erroUsuario('Informe a senha do certificado.');
  const pfx = Buffer.from(body.certificadoBase64, 'base64');
  const info = await nfse.validarCertificado(pfx, body.senhaCertificado);
  await salvarCertificado(empresaId, pfx, body.senhaCertificado);
  return { certificado: info };
}

function validarEmpresa(e) {
  const erros = [];
  if (!e.razaoSocial?.trim()) erros.push('Razão social');
  if (so(e.cnpj).length !== 14) erros.push('CNPJ (14 dígitos)');
  if (so(e.codMunicipio).length !== 7) erros.push('Código IBGE do município (7 dígitos)');
  if (!['1', '2', '3'].includes(e.opSimpNac)) erros.push('Situação no Simples Nacional');
  const serie = Number(e.serie ?? 1);
  if (!(serie >= 1 && serie <= 49999)) erros.push('Série entre 1 e 49999 (faixa de aplicativo próprio)');
  if (!nfse.AMBIENTES[e.ambiente]) erros.push('Ambiente');
  if (erros.length) throw nfse.erroUsuario('Verifique os campos da empresa.', erros);
}

/** Lê o A1 sem gravar: devolve razão social e CNPJ do titular (CN "NOME:CNPJ"). */
app.post('/api/certificado/ler', rota(async (req, res) => {
  if (!req.body.certificadoBase64 || !req.body.senhaCertificado) throw nfse.erroUsuario('Envie o certificado e a senha.');
  const info = await nfse.validarCertificado(Buffer.from(req.body.certificadoBase64, 'base64'), req.body.senhaCertificado);
  const m = /^(.*?):(\d{11}|\d{14})$/.exec(info.titular.trim());
  res.json({ ...info, razaoSocial: m ? m[1].trim() : info.titular, cnpj: m ? m[2] : '' });
}));

app.get('/api/empresas', rota(async (_req, res) => {
  const empresas = await db.listar('empresas');
  res.json(await Promise.all(empresas.map(async (e) => ({ ...publica(e), proximoNDps: await nfse.proximoNDps(e) }))));
}));

app.post('/api/empresas', rota(async (req, res) => {
  const dados = { serie: '1', nDpsInicial: 1, ambiente: 'producao_restrita', regEspTrib: '0', ...escolher(req.body, CAMPOS_EMPRESA) };
  dados.cnpj = so(dados.cnpj);
  validarEmpresa(dados);
  if ((await db.listar('empresas', (e) => e.cnpj === dados.cnpj)).length) throw nfse.erroUsuario('Já existe empresa com este CNPJ.');
  const nova = await db.inserir('empresas', dados);
  try {
    const cert = await gravarCertificadoSeVeio(nova.id, req.body);
    res.status(201).json(publica(await db.atualizar('empresas', nova.id, cert)));
  } catch (err) {
    await db.remover('empresas', nova.id);
    throw err;
  }
}));

app.put('/api/empresas/:id', rota(async (req, res) => {
  const atual = await empresaOu404(req, res);
  if (!atual) return;
  const dados = { ...atual, ...escolher(req.body, CAMPOS_EMPRESA) };
  dados.cnpj = so(dados.cnpj);
  validarEmpresa(dados);
  if (dados.ambiente === 'producao' && atual.ambiente !== 'producao' && req.body.confirmarProducao !== true) {
    throw nfse.erroUsuario('Para ativar a Produção confirme que as notas passarão a ter valor fiscal.');
  }
  const cert = await gravarCertificadoSeVeio(atual.id, req.body);
  res.json(publica(await db.atualizar('empresas', atual.id, { ...dados, ...cert })));
}));

app.delete('/api/empresas/:id', rota(async (req, res) => {
  const atual = await empresaOu404(req, res);
  if (!atual) return;
  if ((await db.listar('notas', (n) => n.empresaId === atual.id && n.status === 'autorizada')).length) {
    throw nfse.erroUsuario('Esta empresa já tem notas autorizadas e não pode ser excluída (guarda fiscal dos documentos).');
  }
  await apagarCertificado(atual.id);
  await db.remover('empresas', atual.id);
  res.status(204).end();
}));

// ------------------------------------------------- tomadores e serviços
for (const colecao of ['tomadores', 'servicos', 'modelos']) {
  app.get(`/api/empresas/:id/${colecao}`, rota(async (req, res) => {
    const termo = String(req.query.q ?? '').toLowerCase();
    const itens = await db.listar(colecao, (t) => t.empresaId === req.params.id);
    res.json(itens.filter((t) => !termo || JSON.stringify(t).toLowerCase().includes(termo))
      .sort((a, b) => String(a.nome ?? a.apelido).localeCompare(String(b.nome ?? b.apelido))));
  }));
  app.post(`/api/empresas/:id/${colecao}`, rota(async (req, res) => {
    if (!(await empresaOu404(req, res))) return;
    const { id: _ignora, ...dados } = req.body;
    if (colecao === 'tomadores') {
      dados.documento = so(dados.documento);
      if (![11, 14].includes(dados.documento.length) || !dados.nome?.trim()) throw nfse.erroUsuario('Tomador precisa de CPF/CNPJ e nome.');
    } else if (colecao === 'modelos') {
      if (!dados.nome?.trim() || !dados.texto?.trim()) throw nfse.erroUsuario('Dê um nome ao modelo e escreva o texto.');
      if (dados.texto.length > 2000) throw nfse.erroUsuario('A descrição da NFS-e aceita no máximo 2.000 caracteres.');
    } else if (!dados.apelido?.trim() || !so(dados.cTribNac)) {
      throw nfse.erroUsuario('Serviço precisa de um apelido e do código de tributação nacional.');
    }
    res.status(201).json(await db.inserir(colecao, { ...dados, empresaId: req.params.id }));
  }));
  app.put(`/api/${colecao}/:itemId`, rota(async (req, res) => {
    const { id: _i, empresaId: _e, ...dados } = req.body;
    if (dados.documento) dados.documento = so(dados.documento);
    const r = await db.atualizar(colecao, req.params.itemId, dados);
    r ? res.json(r) : res.status(404).json({ erro: 'Registro não encontrado.' });
  }));
  app.delete(`/api/${colecao}/:itemId`, rota(async (req, res) => {
    await db.remover(colecao, req.params.itemId);
    res.status(204).end();
  }));
}

// ---------------------------------------------------------------- notas
app.get('/api/empresas/:id/notas', rota(async (req, res) => {
  const { de, ate, q, status } = req.query;
  const papel = req.query.papel ?? 'emitida';
  const termo = String(q ?? '').toLowerCase();
  const notas = await db.listar('notas', (n) => {
    if (n.empresaId !== req.params.id) return false;
    if (papel !== 'todas' && (n.papel ?? 'emitida') !== papel) return false;
    const data = (n.dhProc ?? n.criadoEm).slice(0, 10);
    if (de && data < de) return false;
    if (ate && data > ate) return false;
    if (status && n.status !== status) return false;
    if (termo && !`${n.tomadorNome} ${n.tomadorDoc} ${n.numero ?? ''} ${n.descricao}`.toLowerCase().includes(termo)) return false;
    return true;
  });
  const lista = notas
    .sort((a, b) => (b.dhProc ?? b.criadoEm).localeCompare(a.dhProc ?? a.criadoEm))
    .map(({ entrada: _e, ...n }) => n);
  const autorizadas = lista.filter((n) => n.status === 'autorizada');
  res.json({
    notas: lista,
    totais: {
      quantidade: autorizadas.length,
      vServ: autorizadas.reduce((s, n) => s + (n.vServ ?? 0), 0),
      vISSQN: autorizadas.reduce((s, n) => s + (n.vISSQN ?? 0), 0),
    },
  });
}));

/** Pré-preenchimento: última nota do tomador; se não houver, última da empresa. */
app.get('/api/empresas/:id/sugestao', rota(async (req, res) => {
  const doc = so(req.query.tomador);
  const autorizadas = (await db.listar('notas', (n) => n.empresaId === req.params.id && n.status === 'autorizada' && (n.papel ?? 'emitida') === 'emitida' && n.entrada))
    .sort((a, b) => b.dhProc.localeCompare(a.dhProc));
  const doTomador = doc ? autorizadas.find((n) => so(n.tomadorDoc) === doc) : undefined;
  const nota = doTomador ?? (req.query.somenteTomador ? undefined : autorizadas[0]);
  if (!nota) return res.json({ origem: null });
  res.json({
    origem: doTomador ? 'tomador' : 'ultima',
    nota: { id: nota.id, numero: nota.numero, dhProc: nota.dhProc, tomadorNome: nota.tomadorNome, vServ: nota.vServ },
    entrada: nota.entrada,
  });
}));

app.post('/api/empresas/:id/emitir', rota(async (req, res) => {
  const empresa = await empresaOu404(req, res);
  if (!empresa) return;
  if (empresa.ambiente === 'producao' && req.query.previa !== '1' && req.body.confirmar !== true) {
    throw nfse.erroUsuario('Confirmação obrigatória para emitir em Produção.');
  }
  res.json(await nfse.emitir(empresa, req.body, { previa: req.query.previa === '1' }));
}));

app.post('/api/notas/:id/substituir', rota(async (req, res) => {
  const original = await db.obter('notas', req.params.id);
  if (!original) return res.status(404).json({ erro: 'Nota não encontrada.' });
  const empresa = await db.obter('empresas', original.empresaId);
  if (empresa.ambiente !== original.ambiente) {
    throw nfse.erroUsuario('A nota original é de outro ambiente (homologação/produção) do que o atual da empresa.');
  }
  if (empresa.ambiente === 'producao' && req.body.confirmar !== true) {
    throw nfse.erroUsuario('Confirmação obrigatória para substituir em Produção.');
  }
  const { cMotivo, xMotivo, ...entrada } = req.body;
  res.json(await nfse.substituir(empresa, original, entrada, { cMotivo, xMotivo }));
}));

app.get('/api/sistema/motivos-substituicao', (_req, res) => res.json(nfse.MOTIVOS_SUBSTITUICAO));
app.get('/api/sistema/motivos-cancelamento', (_req, res) => res.json(nfse.MOTIVOS_CANCELAMENTO));

app.post('/api/notas/:id/analise-fiscal', rota(async (req, res) => {
  const nota = await db.obter('notas', req.params.id);
  if (!nota) return res.status(404).json({ erro: 'Nota não encontrada.' });
  const empresa = await db.obter('empresas', nota.empresaId);
  if (nota.ambiente === 'producao' && req.body.confirmar !== true) {
    throw nfse.erroUsuario('Confirmação obrigatória para pedir o cancelamento de uma nota de Produção.');
  }
  res.json(await nfse.solicitarAnaliseFiscal(empresa, nota, { cMotivo: req.body.cMotivo, xMotivo: req.body.xMotivo }));
}));

app.get('/api/notas/:id/requerimento', rota(async (req, res) => {
  const nota = await db.obter('notas', req.params.id);
  if (!nota) return res.status(404).json({ erro: 'Nota não encontrada.' });
  const empresa = await db.obter('empresas', nota.empresaId);
  let xmlNfse = '';
  try { xmlNfse = await fsp.readFile(path.join(db.DATA_DIR, 'xml', `${nota.chaveAcesso}.xml`), 'utf8'); } catch { /* sem XML */ }
  const pdf = gerarRequerimentoPdf({
    empresa, nota, xmlNfse,
    cMotivoTexto: nfse.MOTIVOS_CANCELAMENTO[req.query.cMotivo] ?? '',
    justificativa: String(req.query.xMotivo ?? '').slice(0, 255),
  });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `${req.query.baixar === '1' ? 'attachment' : 'inline'}; filename="Requerimento-cancelamento-NFSe-${nota.numero}.pdf"`);
  pdf.pipe(res);
}));

app.post('/api/notas/:id/anexos', rota(async (req, res) => {
  const nota = await db.obter('notas', req.params.id);
  if (!nota) return res.status(404).json({ erro: 'Nota não encontrada.' });
  res.json(await nfse.salvarAnexo(nota, req.body));
}));

app.get('/api/notas/:id/anexos/:anexo', rota(async (req, res) => {
  const nota = await db.obter('notas', req.params.id);
  const r = nota && (await nfse.lerAnexo(nota, req.params.anexo));
  if (!r) return res.status(404).json({ erro: 'Anexo não encontrado.' });
  res.setHeader('Content-Type', r.anexo.tipo);
  res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(r.anexo.nome)}"`);
  res.send(r.conteudo);
}));

app.delete('/api/notas/:id/anexos/:anexo', rota(async (req, res) => {
  const nota = await db.obter('notas', req.params.id);
  if (!nota || !(await nfse.removerAnexo(nota, req.params.anexo))) return res.status(404).json({ erro: 'Anexo não encontrado.' });
  res.json({ ok: true });
}));

app.post('/api/notas/:id/cancelar', rota(async (req, res) => {
  const nota = await db.obter('notas', req.params.id);
  if (!nota) return res.status(404).json({ erro: 'Nota não encontrada.' });
  const empresa = await db.obter('empresas', nota.empresaId);
  if (nota.ambiente === 'producao' && req.body.confirmar !== true) {
    throw nfse.erroUsuario('Confirmação obrigatória para cancelar uma nota de Produção.');
  }
  res.json(await nfse.cancelar(empresa, nota, { cMotivo: req.body.cMotivo, xMotivo: req.body.xMotivo }));
}));

app.get('/api/notas/:id', rota(async (req, res) => {
  const nota = await db.obter('notas', req.params.id);
  nota ? res.json(nota) : res.status(404).json({ erro: 'Nota não encontrada.' });
}));

app.get('/api/notas/:id/:formato(xml|pdf)', rota(async (req, res) => {
  const nota = await db.obter('notas', req.params.id);
  if (!nota?.chaveAcesso) return res.status(404).json({ erro: 'Nota sem documento autorizado.' });
  const nome = `NFSe-${nota.numero}-${nota.chaveAcesso}`;
  if (req.params.formato === 'xml') {
    res.type('application/xml').attachment(`${nome}.xml`).send(await nfse.lerXml(nota.chaveAcesso));
  } else {
    const pdf = await nfse.danfsePdf(nota);
    const modo = req.query.baixar === '1' ? 'attachment' : 'inline';
    res.type('application/pdf').setHeader('Content-Disposition', `${modo}; filename="${nome}.pdf"`);
    res.send(pdf);
  }
}));

app.post('/api/empresas/:id/sincronizar', rota(async (req, res) => {
  const empresa = await empresaOu404(req, res);
  if (!empresa) return;
  res.json(await nfse.sincronizarPortal(empresa));
}));

app.get('/api/empresas/:id/diagnostico-adn', rota(async (req, res) => {
  const empresa = await empresaOu404(req, res);
  if (!empresa) return;
  const nsus = String(req.query.nsu ?? '0,1').split(',').map(Number).filter((n) => n >= 0).slice(0, 5);
  // Só parâmetros conhecidos da API de distribuição (somente leitura).
  const consulta = new URLSearchParams();
  for (const k of ['lote', 'cnpjConsulta', 'cpfConsulta']) if (req.query[k] !== undefined) consulta.set(k, String(req.query[k]));
  res.json(await nfse.diagnosticoAdn(empresa, nsus, consulta.toString()));
}));

app.post('/api/pendentes/reprocessar', rota(async (_req, res) => {
  res.json(await nfse.reprocessarPendentes());
}));

// ---------------------------------------------------------------- erros
app.use((err, _req, res, _next) => {
  const r = traduzir(err);
  if (r.status >= 500) console.error(err);
  res.status(r.status).json({ erro: r.erro, detalhes: r.detalhes ?? [] });
});

function traduzir(err) {
  if (err.usuario) return { status: err.status ?? 400, erro: err.message, detalhes: err.detalhes };
  if (err instanceof InvalidCertificatePasswordError) return { status: 400, erro: 'Senha do certificado incorreta.' };
  if (err instanceof ExpiredCertificateError) return { status: 400, erro: 'Certificado A1 vencido.' };
  if (err instanceof InvalidCertificateError) return { status: 400, erro: 'Arquivo de certificado inválido (use o .pfx/.p12 do A1).' };
  if (err instanceof XsdValidationError) {
    return { status: 400, erro: 'A DPS não passou na validação do leiaute nacional.', detalhes: (err.violations ?? []).map((v) => v.message ?? String(v)) };
  }
  if (err instanceof RuleViolationError) return { status: 400, erro: `Regra da NFS-e violada: ${err.message}` };
  if (err instanceof InvalidCnpjError || err instanceof InvalidCpfError) return { status: 400, erro: `Documento inválido: ${err.message}` };
  if (err instanceof InvalidCepError) return { status: 400, erro: `CEP inválido: ${err.message}` };
  if (err instanceof UnauthorizedError) return { status: 502, erro: 'A Receita recusou o certificado (401). Confira se o A1 é do CNPJ emitente.' };
  if (err instanceof ForbiddenError) return { status: 502, erro: 'CNPJ sem permissão no Sistema Nacional (403). Verifique o cadastro/adesão no Emissor Nacional.' };
  if (err instanceof NetworkError || err instanceof TimeoutError) return { status: 502, erro: 'Sem comunicação com a Receita. Tente novamente.' };
  return { status: 500, erro: err.message || 'Erro interno.' };
}

// ---------------------------------------------------------------- início
const servidor = app.listen(PORTA, HOST, () => {
  console.log(`ES NFS-e v${VERSAO} em http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORTA}`);
});

// Na abertura, liga substitutas às originais (corrige notas importadas antes da v0.6.1).
(async () => {
  for (const empresa of await db.listar('empresas')) {
    try { await nfse.vincularSubstituicoes(empresa); } catch (err) { console.error('Vínculo de substituições:', err.message); }
  }
})();

// Reenvio automático das pendências a cada 3 minutos (um worker só).
let reprocessando = false;
const timer = setInterval(async () => {
  if (reprocessando) return;
  reprocessando = true;
  try {
    const r = await nfse.reprocessarPendentes();
    if (r.length) console.log('Pendências reprocessadas:', r);
  } catch (err) {
    console.error('Falha ao reprocessar pendências:', err.message);
  } finally {
    reprocessando = false;
  }
}, 180_000);

async function encerrar() {
  clearInterval(timer);
  await nfse.fecharClientes();
  servidor.close(() => process.exit(0));
}
process.on('SIGINT', encerrar);
process.on('SIGTERM', encerrar);
