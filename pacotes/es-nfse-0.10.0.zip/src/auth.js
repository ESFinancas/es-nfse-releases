// Contas e sessões. Senhas com scrypt; sessão em cookie HttpOnly.
// Login com Google: o navegador obtém um ID token (Google Identity Services)
// e o servidor confere no endpoint tokeninfo do Google (aud = nosso Client ID).
import crypto from 'node:crypto';
import { promisify } from 'node:util';
import * as db from './db.js';

const scrypt = promisify(crypto.scrypt);
const COOKIE = 'esnfse_sessao';
const DURACAO_MS = 12 * 60 * 60 * 1000; // 12 h

export function erro(msg, status = 400) {
  const e = new Error(msg);
  e.usuario = true;
  e.status = status;
  e.detalhes = [];
  return e;
}

async function hashSenha(senha) {
  const sal = crypto.randomBytes(16);
  const h = await scrypt(senha, sal, 64);
  return `scrypt$${sal.toString('hex')}$${h.toString('hex')}`;
}

async function confere(senha, guardado) {
  const [, salHex, hHex] = String(guardado ?? '').split('$');
  if (!salHex || !hHex) return false;
  const h = await scrypt(senha, Buffer.from(salHex, 'hex'), 64);
  return crypto.timingSafeEqual(h, Buffer.from(hHex, 'hex'));
}

const publico = ({ senhaHash: _s, ...u }) => u;
const normEmail = (e) => String(e ?? '').trim().toLowerCase();

export async function config() {
  const c = (await db.mapaObter('_config', 'auth')) ?? {};
  return { googleClientId: process.env.ES_NFSE_GOOGLE_CLIENT_ID || c.googleClientId || '' };
}

export async function salvarConfig(mudancas) {
  return db.mapaAtualizar('_config', 'auth', (atual = {}) => ({ ...atual, ...mudancas }));
}

export async function haUsuarios() {
  return (await db.listar('usuarios')).length > 0;
}

function validarSenha(senha) {
  if (String(senha ?? '').length < 8) throw erro('A senha precisa ter pelo menos 8 caracteres.');
}

/** Cria conta. A primeira conta da instalação é administradora. */
export async function criarUsuario({ nome, email, senha, google }, { criadoPor } = {}) {
  email = normEmail(email);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw erro('Informe um e-mail válido.');
  if (!String(nome ?? '').trim()) throw erro('Informe o nome.');
  if (!google) validarSenha(senha);
  if ((await db.listar('usuarios', (u) => u.email === email)).length) throw erro('Já existe uma conta com este e-mail.');
  const primeiro = !(await haUsuarios());
  const u = await db.inserir('usuarios', {
    nome: String(nome).trim(),
    email,
    papel: primeiro ? 'admin' : 'usuario',
    ...(senha ? { senhaHash: await hashSenha(senha) } : {}),
    ...(google ? { googleSub: google.sub } : {}),
    ...(criadoPor ? { criadoPor } : {}),
  });
  return publico(u);
}

async function abrirSessao(res, usuario) {
  const token = crypto.randomBytes(32).toString('hex');
  await db.transacao('_sessoes', (sessoes) => {
    const agora = Date.now();
    for (const [k, v] of Object.entries(sessoes)) if (!v || v.expira < agora) delete sessoes[k];
    sessoes[token] = { usuarioId: usuario.id, expira: agora + DURACAO_MS };
  });
  res.cookie(COOKIE, token, { httpOnly: true, sameSite: 'strict', maxAge: DURACAO_MS, path: '/' });
  await db.atualizar('usuarios', usuario.id, { ultimoAcesso: new Date().toISOString() });
}

export async function loginSenha(res, { email, senha }) {
  const u = (await db.listar('usuarios', (x) => x.email === normEmail(email)))[0];
  if (!u || !u.senhaHash || !(await confere(String(senha ?? ''), u.senhaHash))) {
    await new Promise((r) => setTimeout(r, 400)); // freia tentativa e erro
    throw erro('E-mail ou senha incorretos.', 401);
  }
  if (u.inativo) throw erro('Conta desativada.', 403);
  await abrirSessao(res, u);
  return publico(u);
}

async function verificarTokenGoogle(credencial) {
  const { googleClientId } = await config();
  if (!googleClientId) throw erro('Login com Google ainda não configurado nesta instalação.');
  const r = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credencial)}`);
  if (!r.ok) throw erro('Não foi possível validar o login do Google.', 401);
  const t = await r.json();
  const emissorOk = t.iss === 'accounts.google.com' || t.iss === 'https://accounts.google.com';
  if (t.aud !== googleClientId || !emissorOk || String(t.email_verified) !== 'true' || Number(t.exp) * 1000 < Date.now()) {
    throw erro('Login do Google inválido para este sistema.', 401);
  }
  return { sub: t.sub, email: normEmail(t.email), nome: t.name || t.email };
}

/** Entra com Google; se ainda não há nenhuma conta, cria a primeira (admin). */
export async function loginGoogle(res, credencial) {
  const g = await verificarTokenGoogle(credencial);
  let u = (await db.listar('usuarios', (x) => x.googleSub === g.sub || x.email === g.email))[0];
  if (!u) {
    if (await haUsuarios()) throw erro('Este e-mail do Google não tem acesso. Peça ao administrador para cadastrá-lo.', 403);
    const novo = await criarUsuario({ nome: g.nome, email: g.email, google: g });
    u = await db.obter('usuarios', novo.id);
  } else if (!u.googleSub) {
    u = await db.atualizar('usuarios', u.id, { googleSub: g.sub });
  }
  if (u.inativo) throw erro('Conta desativada.', 403);
  await abrirSessao(res, u);
  return publico(u);
}

function lerCookie(req) {
  const m = new RegExp(`(?:^|;\\s*)${COOKIE}=([a-f0-9]{64})`).exec(req.headers.cookie ?? '');
  return m?.[1];
}

export async function sessao(req) {
  const token = lerCookie(req);
  if (!token) return undefined;
  const s = await db.mapaObter('_sessoes', token);
  if (!s || s.expira < Date.now()) return undefined;
  const u = await db.obter('usuarios', s.usuarioId);
  return u && !u.inativo ? { token, usuario: publico(u) } : undefined;
}

export async function sair(req, res) {
  const token = lerCookie(req);
  if (token) await db.mapaAtualizar('_sessoes', token, () => undefined);
  res.clearCookie(COOKIE, { path: '/' });
}

/** Middleware: exige sessão em /api, exceto rotas de autenticação e info do sistema. */
export function exigirLogin(req, res, next) {
  if (!req.path.startsWith('/api/') || req.path.startsWith('/api/auth/') || req.path === '/api/sistema') return next();
  sessao(req)
    .then((s) => {
      if (!s) return res.status(401).json({ erro: 'Faça login para continuar.', detalhes: [] });
      req.usuario = s.usuario;
      next();
    })
    .catch(next);
}

export const listarUsuarios = async () => (await db.listar('usuarios')).map(publico);

export async function alterarSenha(usuarioId, senhaAtual, novaSenha) {
  const u = await db.obter('usuarios', usuarioId);
  if (u.senhaHash && !(await confere(String(senhaAtual ?? ''), u.senhaHash))) throw erro('Senha atual incorreta.');
  validarSenha(novaSenha);
  await db.atualizar('usuarios', usuarioId, { senhaHash: await hashSenha(novaSenha) });
}
