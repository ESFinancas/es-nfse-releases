// Guia de funcionalidades do ES NFS-e (tela Ajuda). Cada item: t = pergunta/título, c = resposta (HTML simples).
export const AJUDA = [
  {
    secao: 'Primeiros passos',
    itens: [
      { t: 'O que é o ES NFS-e', c: 'Emissor de NFS-e do <b>Padrão Nacional</b> (Sistema Nacional da NFS-e) do escritório Everton Sousa Contabilidade. Roda no seu computador, emite, substitui, cancela e importa as notas do Portal Nacional, gera o DANFSe em PDF e guarda o XML. Atende várias empresas na mesma instalação.' },
      { t: 'Como começar', c: '<ol><li>Crie sua conta (e-mail e senha) no primeiro acesso — a primeira conta é a administradora.</li><li>Vá em <b>Empresas → Nova empresa</b>, selecione o certificado A1 (.pfx/.p12) e digite a senha: razão social, CNPJ e endereço vêm sozinhos.</li><li>Confira regime do Simples, município e IBS/CBS.</li><li>A empresa começa em <b>Simulação</b>: emita uma nota de teste. Depois mude para <b>Produção</b> (o sistema pede confirmação).</li></ol>' },
      { t: 'Ambientes: Simulação, Homologação e Produção', c: '<b>Simulação</b>: nada vai à Receita, serve para treinar. <b>Produção restrita (homologação)</b>: vai ao ambiente de testes da Receita, notas sem valor fiscal. <b>Produção</b>: notas com valor fiscal. A faixa no topo da tela sempre mostra o ambiente da empresa escolhida.' },
      { t: 'Atualização automática', c: 'Sempre que você abre pelo atalho <b>ES NFS-e</b>, o sistema verifica se há versão nova, baixa e instala sozinho, sem mexer nos seus dados. A versão aparece embaixo da logo (ex.: v0.15.0).' },
      { t: 'Liberação de acesso', c: 'Cada empresa precisa estar liberada pelo escritório. Se aparecer <b>Acesso não liberado</b>, envie ao escritório o CNPJ mostrado na tela e depois clique em <b>Verificar agora</b>. Cinco dias antes de vencer aparece um aviso amarelo. Sem internet, a última liberação vale por até 7 dias.' },
    ],
  },
  {
    secao: 'Emitir nota',
    itens: [
      { t: 'Emitir uma NFS-e', c: '<ol><li>Escolha a empresa emitente no menu.</li><li>Preencha o <b>tomador</b> (CPF/CNPJ busca na Receita; CEP preenche o endereço) ou busque no cadastro.</li><li>Em <b>Serviço</b>, escolha um favorito ou informe código de tributação, NBS e descrição.</li><li>Informe <b>valor</b>, alíquota de ISS (quando aplicável) e retenção.</li><li>Clique em <b>Pré-visualizar DPS</b> para validar ou em <b>Emitir NFS-e</b>.</li></ol>' },
      { t: 'Repetir a última nota', c: 'Ao abrir a tela, o sistema já sugere os dados da última nota emitida pela empresa; ao informar o tomador, sugere a última nota daquele tomador. O botão <b>Repetir última nota</b> refaz o preenchimento; <b>Limpar</b> começa do zero.' },
      { t: 'Modelos de descrição', c: 'Botão <b>Modelos de descrição</b>: reaproveita o texto da última nota do tomador ou da empresa e modelos salvos. <b>Salvar como modelo</b> guarda a descrição atual com um nome. Mude só o que for diferente.' },
      { t: 'Assistente saúde (sessões e consultas)', c: 'Para psicologia, fisioterapia, fonoaudiologia, terapia ocupacional, nutrição, medicina e odontologia. Escolha a área e o mês, use <b>Adicionar todas do mês</b> (dia da semana + horário) e informe profissional e conselho. O texto sai no formato "Prestação de serviços de…, referente a N (extenso) sessões…" com a discriminação data a data. Com valor por sessão, calcula o valor da nota. No mês seguinte, já sugere as mesmas datas e horários.' },
      { t: 'Dados bancários na descrição', c: 'Cadastre banco, agência, conta e PIX em <b>Empresas → Editar</b>. Marque "incluir automaticamente" ou use o botão <b>Dados bancários</b>. O bloco "DADOS PARA PAGAMENTO" fica no fim da descrição e não duplica ao repetir notas.' },
      { t: 'Município da prestação', c: 'Digite o <b>nome da cidade</b> e escolha na lista — o código IBGE é preenchido. Vazio = município da empresa. Funciona sem internet (lista oficial dos 5.570 municípios).' },
      { t: 'IBS/CBS (Reforma Tributária)', c: 'O bloco <b>IBS/CBS</b> mostra se o grupo vai na nota: obrigatório a partir de 01/01/2027 (itens 1.03, 1.05, 1.09 e 16.01 a partir de 01/03/2027). Os códigos (CST, cClassTrib, cIndOp) vêm do cadastro da empresa (modelos <b>Simples puro</b> e <b>Simples híbrido</b>) ou do serviço favorito; pode alterar só para a nota. Sem os códigos depois da data, o sistema bloqueia a emissão com aviso.' },
      { t: 'Pré-visualizar a DPS', c: 'Monta o XML no leiaute vigente, valida contra o XSD oficial e assina, <b>sem enviar</b>. Mostra o leiaute (NT 004 ou NT 009) e se o IBS/CBS foi informado.' },
      { t: 'Leiaute NT 004 e NT 009', c: 'A Receita troca o leiaute da DPS em 01/12/2026 (NT 009). O sistema troca sozinho na data; se a Receita recusar por estrutura, tenta o outro leiaute uma vez. O administrador pode forçar o leiaute em <b>Usuários</b>.' },
    ],
  },
  {
    secao: 'Histórico',
    itens: [
      { t: 'Consultar notas', c: 'Filtre por período, tomador/CPF/CNPJ/nº/descrição, emitidas ou recebidas e situação. Os totais (notas autorizadas, faturamento e ISS) consideram o filtro.' },
      { t: 'Ícones de cada nota', c: 'Passe o mouse para ver o nome: <b>Ver DANFSe</b>, <b>Baixar PDF</b>, <b>Baixar XML</b>, <b>Usar como modelo</b>, <b>Cadastrar serviço favorito</b> (estrela), <b>Anexos</b> (clipe), <b>Substituir</b> e <b>Cancelar</b>.' },
      { t: 'Importar do Portal Nacional', c: 'Traz todas as notas emitidas e recebidas do CNPJ desde a adesão, inclusive as feitas no emissor web, com cancelamentos e substituições. Pode repetir quantas vezes quiser: não duplica.' },
      { t: 'Substituir uma nota', c: 'Ícone <b>Substituir</b>: abre a nota no formulário com o motivo da substituição; ao emitir, a nova nota substitui a anterior, que passa a "substituída pela nº X".' },
      { t: 'Cancelar uma nota', c: 'Ícone <b>Cancelar</b> (vermelho). <b>Cancelamento direto</b>: na hora, se o município permitir. <b>Análise fiscal à prefeitura</b>: para municípios que exigem requerimento (ex.: Campina Grande) ou prazo vencido — gere o <b>requerimento em PDF</b>, colha as assinaturas, anexe e envie; a nota fica "em análise" até o deferimento. Não pode ser desfeito: se a nota só tem um erro, prefira Substituir.' },
      { t: 'Anexos', c: 'Guarde com a nota o requerimento assinado, termo do tomador, comprovantes e protocolos (PDF, PNG ou JPG até 10 MB).' },
      { t: 'Notas pendentes', c: 'Se a Receita não responder, a nota fica <b>pendente</b> e é reenviada sozinha a cada 3 minutos (ou em <b>Reenviar pendentes</b>), sem duplicar.' },
      { t: 'DANFSe e QR Code', c: 'O DANFSe segue o modelo oficial da NT 008. O QR Code leva à Consulta Pública do Portal Nacional, onde qualquer pessoa confere a nota. Fora de Produção sai a marca "sem validade jurídica"; notas canceladas e substituídas saem com marca d\'água.' },
    ],
  },
  {
    secao: 'Cadastros',
    itens: [
      { t: 'Tomadores', c: 'Cadastro de clientes da empresa (CPF/CNPJ, endereço, contatos). O CNPJ busca os dados na Receita e o CEP o endereço. Na emissão, "Salvar/atualizar este tomador" mantém o cadastro em dia.' },
      { t: 'Serviços favoritos', c: 'Guarde código de tributação, NBS, descrição, valor, ISS, município e IBS/CBS de cada serviço. Crie também a partir de uma nota emitida (estrela no Histórico ou botão após emitir).' },
      { t: 'Empresas', c: 'Certificado A1 (fica cifrado no computador), regime do Simples, município (pelo nome), série e numeração, ambiente, dados bancários, profissional/conselho e IBS/CBS. A coluna <b>Liberação</b> mostra a situação de acesso de cada empresa.' },
      { t: 'Usuários (administrador)', c: 'Cadastre a equipe com senha provisória, desative acessos e <b>redefina a senha</b> de quem esquecer. Cada pessoa troca a própria senha em "Alterar senha".' },
    ],
  },
  {
    secao: 'Suporte e dúvidas frequentes',
    itens: [
      { t: 'Abrir chamado (erro ou melhoria)', c: 'Menu <b>Suporte</b>: escolha <b>Inconsistência</b> (algo não funciona) ou <b>Melhoria</b>, descreva e envie pelo WhatsApp ou e-mail do escritório. O sistema junta um diagnóstico (versão, tela, empresa e últimos erros) e dá um número de protocolo.' },
      { t: 'A Receita rejeitou a nota', c: 'A mensagem mostra o código (ex.: E0600) e o motivo. Corrija o campo indicado e emita de novo. Se não entender o erro, abra um chamado: a rejeição vai junto no diagnóstico.' },
      { t: 'Erro E0718 (assinatura deve ser do emitente)', c: 'O certificado usado não é do CNPJ emitente (ou falta procuração eletrônica). Confira o A1 cadastrado na empresa.' },
      { t: 'Sem internet', c: 'Sem internet não há emissão (a nota é autorizada pela Receita na hora). Consulta ao histórico, PDF e XML funcionam normalmente.' },
      { t: 'Onde ficam meus dados', c: 'No seu computador, na pasta <span class="mono">%LOCALAPPDATA%\\ESNFSe\\dados</span>: notas, XML, cadastros e o certificado cifrado. Faça cópia de segurança dessa pasta periodicamente.' },
      { t: 'Usar no celular ou tablet', c: 'A tela se adapta a qualquer tamanho (menu ☰ e tabelas em cartões), mas o sistema roda no computador onde foi instalado.' },
    ],
  },
];
