﻿# Janela do sistema na barra de tarefas: abre uma vez só, com nome e ícone do ES NFS-e.
# Tudo aqui é opcional: se algo falhar, o sistema abre do jeito antigo.
$script:AppId = 'EvertonSousa.ESNFSe'
$script:PerfilJanela = Join-Path $Base 'janela'
if (-not ('ESNFSe.Janela' -as [type])) {
  Add-Type -Language CSharp -TypeDefinition @'

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
namespace ESNFSe {
  [StructLayout(LayoutKind.Sequential, Pack = 4)]
  public struct PropertyKey { public Guid fmtid; public uint pid; public PropertyKey(Guid g, uint p) { fmtid = g; pid = p; } }
  [StructLayout(LayoutKind.Explicit, Size = 24)]
  public struct PropVariant { [FieldOffset(0)] public ushort vt; [FieldOffset(8)] public IntPtr p; }
  [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  public interface IPropertyStore {
    [PreserveSig] int GetCount(out uint c);
    [PreserveSig] int GetAt(uint i, out PropertyKey k);
    [PreserveSig] int GetValue(ref PropertyKey k, IntPtr v);
    [PreserveSig] int SetValue(ref PropertyKey k, ref PropVariant v);
    [PreserveSig] int Commit();
  }
  [ComImport, Guid("00021401-0000-0000-C000-000000000046")] public class CShellLink { }
  public static class Janela {
    static readonly Guid FMT = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3");
    delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f, IntPtr l);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowTextLength(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr h, int cmd);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
    [DllImport("shell32.dll")] static extern int SHGetPropertyStoreForWindow(IntPtr h, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out IPropertyStore ps);

    /// Janelas principais (visíveis, sem dono, com título) dos processos informados.
    public static IntPtr[] DosProcessos(int[] pids) {
      var set = new HashSet<uint>(); foreach (var p in pids) set.Add((uint)p);
      var r = new List<IntPtr>();
      EnumWindows((h, l) => {
        uint pid; GetWindowThreadProcessId(h, out pid);
        if (!set.Contains(pid) || !IsWindowVisible(h) || GetWindow(h, 4) != IntPtr.Zero || GetWindowTextLength(h) == 0) return true;
        var sb = new StringBuilder(64); GetClassName(h, sb, 64);
        if (sb.ToString().StartsWith("Chrome_WidgetWin")) r.Add(h);
        return true;
      }, IntPtr.Zero);
      return r.ToArray();
    }
    public static void Focar(IntPtr h) {
      if (IsIconic(h)) ShowWindowAsync(h, 9);
      keybd_event(0x12, 0, 0, UIntPtr.Zero); keybd_event(0x12, 0, 2, UIntPtr.Zero); // Alt: libera a troca de foco
      SetForegroundWindow(h);
    }
    static void Gravar(IPropertyStore ps, uint pid, string valor) {
      var k = new PropertyKey(FMT, pid);
      var v = new PropVariant(); v.vt = 31; v.p = Marshal.StringToCoTaskMemUni(valor);
      try { Marshal.ThrowExceptionForHR(ps.SetValue(ref k, ref v)); } finally { Marshal.FreeCoTaskMem(v.p); }
    }
    /// Faz a janela aparecer na barra de tarefas como o aplicativo (nome, ícone e "fixar" abrem o atalho).
    public static void MarcarJanela(IntPtr h, string appId, string comando, string nome, string icone) {
      var iid = typeof(IPropertyStore).GUID; IPropertyStore ps;
      Marshal.ThrowExceptionForHR(SHGetPropertyStoreForWindow(h, ref iid, out ps));
      try {
        Gravar(ps, 2, comando); Gravar(ps, 3, icone); Gravar(ps, 4, nome); Gravar(ps, 5, appId);
        ps.Commit();
      } finally { Marshal.ReleaseComObject(ps); }
    }
    public static void MarcarAtalho(string lnk, string appId) {
      var o = new CShellLink();
      try {
        var pf = (IPersistFile)o; pf.Load(lnk, 2);
        var ps = (IPropertyStore)o; Gravar(ps, 5, appId); Marshal.ThrowExceptionForHR(ps.Commit());
        pf.Save(lnk, true);
      } finally { Marshal.ReleaseComObject(o); }
    }
  }
}

'@
}

function script:Processos-Da-Janela {
  # Processo principal do navegador aberto com o perfil exclusivo do ES NFS-e.
  $perfil = $script:PerfilJanela.ToLower()
  @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine.ToLower().Contains($perfil) -and ($_.CommandLine -notmatch '--type=') } |
    ForEach-Object { [int]$_.ProcessId })
}

function script:Janela-Aberta {
  $pids = Processos-Da-Janela
  if (-not $pids.Count) { return [IntPtr]::Zero }
  $j = [ESNFSe.Janela]::DosProcessos([int[]]$pids)
  if ($j.Count) { return $j[0] }
  return [IntPtr]::Zero
}

function script:Focar-Janela([IntPtr]$h) { [ESNFSe.Janela]::Focar($h) }

function script:Marcar-Janela-Nova {
  # Espera a janela aparecer (até ~15 s) e põe nome, ícone e o comando de "fixar na barra".
  $vbs = Join-Path $App 'instalador\iniciar-oculto.vbs'
  $cmd = "`"$(Join-Path $env:WINDIR 'System32\wscript.exe')`" `"$vbs`""
  $ico = Join-Path $App 'public\icone.ico'
  for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Milliseconds 250
    $h = Janela-Aberta
    if ($h -ne [IntPtr]::Zero) {
      [ESNFSe.Janela]::MarcarJanela($h, $script:AppId, $cmd, 'ES NFS-e', "$ico,0")
      return
    }
  }
  Registrar 'Janela do sistema não encontrada para marcar na barra de tarefas'
}

function script:Marcar-Atalho([string]$lnk) { [ESNFSe.Janela]::MarcarAtalho($lnk, $script:AppId) }
