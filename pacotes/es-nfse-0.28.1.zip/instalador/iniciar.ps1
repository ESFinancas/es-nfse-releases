﻿# Iniciador do ES NFS-e: verifica e instala a atualização ANTES de abrir, mostrando o progresso,
# sobe o servidor e abre a janela.
. (Join-Path $PSScriptRoot 'comum.ps1')
Set-Location $Base

# Uma execução por vez: um segundo clique enquanto o sistema abre ou atualiza não faz nada.
$script:Trava = New-Object System.Threading.Mutex($false, 'Local\ESNFSe-Iniciador')
$temTrava = $false
# Trava abandonada (iniciador anterior terminou sem liberar) chega como exceção: vale como obtida.
try { $temTrava = $script:Trava.WaitOne(0) } catch { $temTrava = $true }
if (-not $temTrava) { Registrar 'Iniciador já em execução: segundo clique ignorado'; exit }

# Atalhos com o ícone novo e a identidade de app (refeitos uma vez por versão do atalho).
$marca = Join-Path $Base 'atalhos-v2'
if (-not (Test-Path $marca)) {
  try { Criar-Atalhos; Set-Content -Path $marca -Value (Get-Date -Format s) } catch { Registrar "Atalhos não atualizados: $($_.Exception.Message)" }
}

# Sistema já aberto: traz a janela para a frente em vez de abrir outra.
if ((Carregar-Janela) -and (Servidor-Ativo)) {
  try {
    $h = Janela-Aberta
    if ($h -ne [IntPtr]::Zero) { Focar-Janela $h; Registrar 'Janela já aberta: trazida para a frente'; exit }
  } catch { Registrar "Não foi possível verificar a janela aberta: $($_.Exception.Message)" }
}

# Janela de progresso (se não puder ser exibida, o sistema segue sem ela).
$script:ComTela = $false
try {
  . (Join-Path $PSScriptRoot 'tela.ps1')
  Tela-Abrir 'Verificando atualizações…'
  $script:ComTela = $true
} catch {
  Registrar "Janela de progresso indisponível: $($_.Exception.Message)"
}
function Mostrar([string]$texto, [int]$pct = -1) {
  if ($script:ComTela) { try { Tela-Texto $texto $pct } catch { } }
}
function Esconder-Tela {
  if ($script:ComTela) { try { Tela-Fechar } catch { }; $script:ComTela = $false }
}

try {
  $rel = $null
  try { $rel = Ultima-Release } catch { Registrar "Sem verificação de atualização: $($_.Exception.Message)" }
  $atual = Versao-Instalada
  if ($rel -and (Versao-Maior $rel.Versao $atual)) {
    $versaoNova = $rel.Versao
    while ($true) {
      try {
        Mostrar "Atualizando para a versão $versaoNova…" 0
        Baixar-E-Instalar-App $rel {
          param($pct)
          if ($pct -ge 0) { Mostrar "Baixando a versão $versaoNova… $pct%" $pct }
          else { Mostrar "Instalando a versão $versaoNova… não feche esta janela." }
        }
        Criar-Atalhos
        Mostrar "Versão $versaoNova instalada."
        break
      } catch {
        $motivo = $_.Exception.Message
        Registrar "Falha ao atualizar para $($versaoNova): $motivo"
        Esconder-Tela
        Add-Type -AssemblyName PresentationFramework
        $msg = "Não foi possível instalar a versão $versaoNova do ES NFS-e.`n`nMotivo: $motivo`n`nDica: feche outras janelas do ES NFS-e antes de tentar de novo.`n`nSim = tentar de novo`nNão = abrir a versão instalada ($atual)"
        $r = [System.Windows.MessageBox]::Show($msg, 'ES NFS-e — Atualização', 'YesNo', 'Warning')
        if ($r -ne 'Yes') { break }
        try { Tela-Abrir "Tentando atualizar de novo…"; $script:ComTela = $true } catch { }
      }
    }
  }
  Mostrar 'Iniciando o sistema…'
  $node = Node-Exe
  if (-not $node) { Mostrar 'Preparando o ambiente (primeira vez)…'; $node = Instalar-Node }
  Iniciar-Servidor $node
  Esconder-Tela
  Abrir-Janela
} catch {
  Esconder-Tela
  Registrar "ERRO: $($_.Exception.Message)"
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show("Não foi possível iniciar o ES NFS-e.`n`n$($_.Exception.Message)`n`nDetalhes em $Log", 'ES NFS-e') | Out-Null
}
