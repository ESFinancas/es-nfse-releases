// Versionamento semântico do ES NFS-e (MAJOR.MINOR.PATCH).
// Lido do package.json para nunca divergir da versão instalada.
import { readFileSync } from 'node:fs';
export const VERSAO = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version;
