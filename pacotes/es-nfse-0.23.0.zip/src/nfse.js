// Integração com a biblioteca open-nfse: um cliente por empresa/ambiente,
// contador de DPS e fila de pendentes persistidos em disco.
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { gunzipSync, gzipSync } from 'node:zlib';
import {
  Ambiente,
  NfseClient,
  OpcaoSimplesNacional,
  ReceitaRejectionError,
  TipoAmbienteDps,
  buildCancelamentoXml,
  buildDps,
  buildDpsXml,
  buildEventoPedidoId,
  defaultIsTransient,
  parseNfseXml,
  pendingEmissionId,
  postEvento,
  receitaRejectionFromPostError,
  signDpsXml,
  validatePedRegEventoXml,
  parsePfx,
} from 'open-nfse';
import { NfseClientFake } from 'open-nfse/testing';
import * as db from './db.js';
import { lerCertificado } from './cofre.js';
import { reciboPdf as gerarReciboPdf } from './recibo.js';
import { VERSAO } from './versao.js';
import { gerarDanfsePdf } from './danfse.js';
import { situacao as situacaoLicenca } from './licenca.js';
import {
  ibscbsDeXml, ibscbsNt004, leiauteVigente, lerNfse, outroLeiaute, paraNt009, resolverIbsCbs, validarDps,
} from './leiaute.js';

export const AMBIENTES = {
  simulacao: 'Simulação (sem envio)',
  producao_restrita: 'Produção Restrita (homologação)',
  producao: 'Produção (nota com valor fiscal)',
};

const VER_APLIC = `ES-NFSe-${VERSAO}`; // máx. 20 caracteres (TSVerAplic)
const DIR_XML = () => path.join(db.DATA_DIR, 'xml');
const escopo = (empresa) => `${empresa.id}:${empresa.ambiente}`;

// ---------------------------------------------------------------------------
// Contador de DPS (série 00001–49999 = aplicativo próprio; o Emissor Web usa
// 70000+, então não há colisão com notas emitidas pelo portal).
// ---------------------------------------------------------------------------
const chaveContador = (empresa) => `${escopo(empresa)}:${empresa.serie}`;

export async function proximoNDps(empresa) {
  return (await db.mapaObter('_contadores', chaveContador(empresa))) ?? Number(empresa.nDpsInicial ?? 1);
}

function consumirNDps(empresa) {
  let usado;
  return db
    .mapaAtualizar('_contadores', chaveContador(empresa), (atual) => {
      usado = atual ?? Number(empresa.nDpsInicial ?? 1);
      return usado + 1;
    })
    .then(() => String(usado));
}

const contadorPara = (empresa) => ({ next: () => consumirNDps(empresa) });

// ---------------------------------------------------------------------------
// RetryStore persistente (datas voltam como Date, exigência da lib).
// ---------------------------------------------------------------------------
const DATAS = ['firstAttemptAt', 'lastAttemptAt', 'notBefore'];

function storePara(empresa) {
  const k = escopo(empresa);
  return {
    async save(entrada) {
      await db.mapaAtualizar('_pendentes', k, (lista = []) => [...lista.filter((e) => e.id !== entrada.id), entrada]);
    },
    async list() {
      const lista = (await db.mapaObter('_pendentes', k)) ?? [];
      return lista.map((e) => {
        const r = { ...e };
        for (const d of DATAS) if (r[d]) r[d] = new Date(r[d]);
        return r;
      });
    },
    async delete(id) {
      await db.mapaAtualizar('_pendentes', k, (lista = []) => lista.filter((e) => e.id !== id));
    },
  };
}

// ---------------------------------------------------------------------------
// Clientes
// ---------------------------------------------------------------------------
const clientes = new Map();

export async function validarCertificado(pfx, senha) {
  const cert = parsePfx(pfx, senha); // lança senha errada / vencido / inválido
  return { titular: cert.subject, validade: cert.expiresOn.toISOString() };
}

const versaoCliente = (empresa, procurador) => `${empresa.ambiente}|${empresa.atualizadoEm ?? empresa.criadoEm}|${procurador?.id ?? empresa.id}|${procurador?.atualizadoEm ?? ''}`;

async function clientePara(empresa) {
  // Procuração eletrônica: conecta e assina com o certificado do escritório (procurador);
  // o emitente da DPS continua sendo o CNPJ do cliente.
  const procurador = empresa.acesso === 'procuracao' && empresa.procuradorId ? await db.obter('empresas', empresa.procuradorId) : null;
  if (empresa.acesso === 'procuracao' && empresa.ambiente !== 'simulacao' && !procurador) throw erroUsuario('A empresa procuradora desta procuração não foi encontrada. Revise o cadastro (Empresas → Editar → Acesso).');
  const fonteCert = procurador?.id ?? empresa.id;
  const versao = versaoCliente(empresa, procurador);
  const cache = clientes.get(empresa.id);
  if (cache?.versao === versao) return cache.cliente;
  if (cache) await cache.cliente.close?.();

  let cliente;
  if (empresa.ambiente === 'simulacao') {
    cliente = new NfseClientFake();
  } else {
    const certificado = await lerCertificado(fonteCert);
    if (!certificado) throw erroUsuario(procurador ? `A empresa procuradora (${procurador.razaoSocial}) não tem certificado A1 cadastrado.` : 'Esta empresa não tem certificado A1 cadastrado.');
    cliente = new NfseClient({
      ambiente: empresa.ambiente === 'producao' ? Ambiente.Producao : Ambiente.ProducaoRestrita,
      certificado,
      dpsCounter: contadorPara(empresa),
      retryStore: storePara(empresa),
    });
  }
  clientes.set(empresa.id, { versao, cliente });
  return cliente;
}

export async function fecharClientes() {
  for (const { cliente } of clientes.values()) await cliente.close?.();
  clientes.clear();
}

// ---------------------------------------------------------------------------
// Montagem dos parâmetros
// ---------------------------------------------------------------------------
const so = (s) => String(s ?? '').replace(/\D/g, '');
const num = (v) => (v === '' || v === null || v === undefined ? undefined : Number(String(v).replace(',', '.')));

export function erroUsuario(msg, detalhes = []) {
  const e = new Error(msg);
  e.usuario = true;
  e.detalhes = detalhes;
  return e;
}

function regimeDe(empresa) {
  const r = { opSimpNac: empresa.opSimpNac, regEspTrib: empresa.regEspTrib ?? '0' };
  if (empresa.opSimpNac === OpcaoSimplesNacional.MeEpp) r.regApTribSN = empresa.regApTribSN ?? '1';
  return r;
}

function totTribDe(empresa) {
  if (empresa.opSimpNac === OpcaoSimplesNacional.MeEpp) {
    const p = num(empresa.pTotTribSN);
    if (p === undefined) throw erroUsuario('Informe no cadastro da empresa o % aproximado de tributos do Simples (pTotTribSN).');
    return { pTotTribSN: p };
  }
  if (empresa.opSimpNac === OpcaoSimplesNacional.NaoOptante) {
    return {
      pTotTrib: {
        pTotTribFed: num(empresa.pTotTribFed) ?? 0,
        pTotTribEst: num(empresa.pTotTribEst) ?? 0,
        pTotTribMun: num(empresa.pTotTribMun) ?? 0,
      },
    };
  }
  return {}; // MEI: indTotTrib='0' (default da lib)
}

export function montarParams(empresa, entrada) {
  const { servico = {}, valores = {}, tomador } = entrada;
  const vServ = num(valores.vServ);
  if (!vServ || vServ <= 0) throw erroUsuario('Informe o valor do serviço.');
  if (!servico.cTribNac) throw erroUsuario('Informe o código de tributação nacional do serviço.');
  if (!servico.descricao?.trim()) throw erroUsuario('Descreva o serviço prestado.');

  const params = {
    emitente: {
      cnpj: so(empresa.cnpj),
      codMunicipio: so(empresa.codMunicipio),
      ...(empresa.inscricaoMunicipal ? { inscricaoMunicipal: empresa.inscricaoMunicipal } : {}),
      regime: regimeDe(empresa),
    },
    serie: String(empresa.serie ?? '1'),
    tpAmb: empresa.ambiente === 'producao' ? TipoAmbienteDps.Producao : TipoAmbienteDps.Homologacao,
    dCompet: entrada.dataCompetencia ? new Date(`${entrada.dataCompetencia}T12:00:00-03:00`) : new Date(),
    verAplic: VER_APLIC,
    servico: {
      cTribNac: so(servico.cTribNac),
      descricao: servico.descricao.trim(),
      ...(so(servico.cNBS) ? { cNBS: so(servico.cNBS) } : {}),
      ...(servico.cTribMun ? { cTribMun: String(servico.cTribMun) } : {}),
      ...(so(servico.codMunicipioPrestacao) ? { codMunicipioPrestacao: so(servico.codMunicipioPrestacao) } : {}),
    },
    valores: {
      vServ,
      // MEI não informa alíquota de ISS (regra E0600).
      ...(num(valores.aliqIss) !== undefined && empresa.opSimpNac !== OpcaoSimplesNacional.Mei
        ? { aliqIss: num(valores.aliqIss) }
        : {}),
      tpRetISSQN: valores.tpRetISSQN ?? '1',
      ...totTribDe(empresa),
    },
  };

  if (tomador && so(tomador.documento)) {
    const doc = so(tomador.documento);
    const end = tomador.endereco;
    params.tomador = {
      documento: doc.length === 11 ? { CPF: doc } : { CNPJ: doc },
      nome: String(tomador.nome ?? '').trim(),
      ...(tomador.email ? { email: tomador.email.trim() } : {}),
      ...(so(tomador.fone) ? { fone: so(tomador.fone) } : {}),
      ...(tomador.inscricaoMunicipal ? { inscricaoMunicipal: tomador.inscricaoMunicipal } : {}),
      ...(end && so(end.cep)
        ? {
            endereco: {
              codMunicipio: so(end.codMunicipio),
              cep: so(end.cep),
              logradouro: end.logradouro,
              numero: end.numero || 'S/N',
              bairro: end.bairro,
              ...(end.complemento ? { complemento: end.complemento } : {}),
            },
          }
        : {}),
    };
    if (!params.tomador.nome) throw erroUsuario('Informe o nome do tomador.');
  }
  return params;
}

// ---------------------------------------------------------------------------
// Registro das notas
// ---------------------------------------------------------------------------
async function salvarXml(chave, xml) {
  await fs.mkdir(DIR_XML(), { recursive: true });
  await fs.writeFile(path.join(DIR_XML(), `${chave}.xml`), xml);
}

export async function lerXml(chave) {
  return fs.readFile(path.join(DIR_XML(), `${path.basename(chave)}.xml`), 'utf8');
}

function resumo(nfse) {
  const inf = nfse.infNFSe;
  const dps = inf.DPS.infDPS;
  const toma = dps.toma;
  return {
    chaveAcesso: inf.chaveAcesso,
    numero: inf.nNFSe,
    dhProc: new Date(inf.dhProc).toISOString(),
    serie: dps.serie,
    nDPS: dps.nDPS,
    competencia: new Date(dps.dCompet).toISOString().slice(0, 10),
    tomadorDoc: toma ? (toma.identificador.CNPJ ?? toma.identificador.CPF ?? '') : '',
    tomadorNome: toma?.xNome ?? 'Tomador não identificado',
    descricao: dps.serv.cServ.xDescServ,
    cTribNac: dps.serv.cServ.cTribNac,
    vServ: dps.valores.vServPrest.vServ,
    vLiq: inf.valores.vLiq,
    vISSQN: inf.valores.vISSQN ?? null,
    pAliq: inf.valores.pAliqAplic ?? dps.valores.trib?.tribMun?.pAliq ?? null,
  };
}

async function registrarAutorizada(empresa, emissao, entrada, extra = {}) {
  await salvarXml(emissao.chaveAcesso, emissao.xmlNfse);
  if (empresa.ambiente === 'simulacao') {
    // XML do simulador é sintético; guarda o objeto para gerar o DANFSe de teste.
    await fs.writeFile(path.join(DIR_XML(), `${emissao.chaveAcesso}.json`), JSON.stringify(emissao.nfse));
  }
  const dados = {
    empresaId: empresa.id,
    ambiente: empresa.ambiente,
    status: 'autorizada',
    origem: 'sistema',
    papel: 'emitida',
    idDps: emissao.idDps,
    alertas: (emissao.alertas ?? []).map((a) => `[${a.codigo}] ${a.descricao}`),
    entrada,
    ...extra,
    ...resumo(emissao.nfse),
  };
  const pendente = (await db.listar('notas', (n) => n.idDps === emissao.idDps && n.status === 'pendente'))[0];
  return pendente ? db.atualizar('notas', pendente.id, dados) : db.inserir('notas', dados);
}

async function salvarTomadorSeNovo(empresa, tomador) {
  const doc = so(tomador?.documento);
  if (!doc) return;
  const existe = await db.listar('tomadores', (t) => t.empresaId === empresa.id && so(t.documento) === doc);
  const dados = { empresaId: empresa.id, ...tomador, documento: doc };
  if (existe.length) await db.atualizar('tomadores', existe[0].id, dados);
  else await db.inserir('tomadores', dados);
}

// ---------------------------------------------------------------------------
// Fluxo próprio de envio da DPS: monta, ajusta ao leiaute vigente (NT 004 ou
// NT 009), põe o grupo IBS/CBS quando for o caso, valida no XSD, assina e envia.
// ---------------------------------------------------------------------------
export async function leiauteConfigurado() {
  return (await db.mapaObter('_config', 'leiauteDps')) ?? 'auto';
}
export async function salvarLeiaute(valor) {
  if (!['auto', 'nt004', 'nt009'].includes(valor)) throw erroUsuario('Leiaute inválido.');
  await db.mapaAtualizar('_config', 'leiauteDps', () => valor);
  return valor;
}

/** XML da DPS (sem assinatura) no leiaute pedido, com o grupo IBS/CBS quando houver. */
export function montarXmlDps(dps, leiaute, ibscbs) {
  const d = leiaute === 'nt004' && ibscbs ? { ...dps, infDPS: { ...dps.infDPS, IBSCBS: ibscbsNt004(ibscbs) } } : dps;
  const xml = buildDpsXml(d);
  return leiaute === 'nt009' ? paraNt009(xml, ibscbs) : xml;
}

function respostaEmissao(body) {
  if (typeof body?.chaveAcesso === 'string' && typeof body?.nfseXmlGZipB64 === 'string') {
    const xmlNfse = gunzipSync(Buffer.from(body.nfseXmlGZipB64, 'base64')).toString('utf8');
    return {
      chaveAcesso: body.chaveAcesso,
      idDps: body.idDps,
      xmlNfse,
      nfse: lerNfse(parseNfseXml, xmlNfse),
      alertas: (body.alertas ?? []).map((a) => ({ codigo: a.codigo ?? a.Codigo ?? '', descricao: a.descricao ?? a.Descricao ?? '' })),
    };
  }
  const rej = receitaRejectionFromPostError(body);
  if (rej) throw rej;
  throw new ReceitaRejectionError({ mensagens: [{ codigo: 'UNKNOWN', descricao: `Resposta sem mensagens reconhecíveis: ${JSON.stringify(body)}` }] });
}

/** Rejeição que indica leiaute trocado (estrutura/schema), e não erro de dados. */
const ehErroDeLeiaute = (err) => err instanceof ReceitaRejectionError
  && err.mensagens.some((m) => /schema|xsd|leiaute|estrutura|finNFSe|n[ãa]o esperado|not expected|E1235|E0001/i.test(`${m.codigo} ${m.descricao} ${m.complemento ?? ''}`));

/**
 * Envia uma DPS já construída (buildDps). Em "automático", se a Receita
 * recusar por estrutura, tenta uma vez o outro leiaute com o mesmo nDPS (a DPS
 * recusada não é registrada, então não há duplicidade).
 */
async function enviarDps(empresa, cliente, dps, entrada, { dryRun = false } = {}) {
  const config = await leiauteConfigurado();
  const tentativas = config === 'auto' ? [leiauteVigente('auto'), outroLeiaute(leiauteVigente('auto'))] : [config];
  let ultimoErro;
  for (const [n, leiaute] of tentativas.entries()) {
    const ibscbs = resolverIbsCbs(empresa, entrada, leiaute);
    const xml = montarXmlDps(dps, leiaute, ibscbs);
    await validarDps(xml, leiaute);
    if (empresa.ambiente === 'simulacao') return { simulacao: true, xml, leiaute, ibscbs };
    const estado = await cliente.ensureState();
    const assinado = signDpsXml(xml, estado.certificate);
    if (dryRun) return { dryRun: true, xmlDpsAssinado: assinado, leiaute, ibscbs };
    try {
      const body = await estado.sefin.post('/nfse', { dpsXmlGZipB64: gzipSync(assinado).toString('base64') }, { acceptedStatuses: [400] });
      return { status: 'ok', nfse: respostaEmissao(body), leiaute, ibscbs };
    } catch (err) {
      if (err instanceof ReceitaRejectionError) {
        if (n + 1 < tentativas.length && ehErroDeLeiaute(err)) { ultimoErro = err; continue; }
        throw err;
      }
      if (!defaultIsTransient(err)) throw err;
      const agora = new Date();
      const pending = {
        id: pendingEmissionId(dps.infDPS.Id), kind: 'emission', idDps: dps.infDPS.Id, emitenteCnpj: so(empresa.cnpj),
        serie: dps.infDPS.serie, nDPS: dps.infDPS.nDPS, xmlAssinado: assinado,
        firstAttemptAt: agora, lastAttemptAt: agora, attempts: 1,
        lastError: { message: err.message, errorName: err.name, transient: true },
      };
      await storePara(empresa).save(pending);
      return { status: 'retry_pending', pending, error: err, leiaute, ibscbs };
    }
  }
  throw ultimoErro;
}

export const dicaE0718 = (empresa) => (empresa.acesso === 'procuracao'
  ? 'Dica: o certificado do escritório não foi aceito para este CNPJ. Confira se a procuração eletrônica (serviço NFS-e) está vigente e se o escritório a confirmou em Controle de Acesso → Recebidas, no portal da Receita.'
  : 'Dica: o certificado A1 usado não é do CNPJ emitente. Confira o certificado cadastrado na empresa ou use procuração eletrônica.');

// ---------------------------------------------------------------------------
// Emissão
// ---------------------------------------------------------------------------
export async function emitir(empresa, entrada, { previa = false } = {}) {
  const params = montarParams(empresa, entrada);
  const cliente = await clientePara(empresa);

  if (previa) {
    const dps = buildDps({ ...params, nDPS: String(await proximoNDps(empresa)) });
    const r = await enviarDps(empresa, cliente, dps, entrada, { dryRun: true });
    return { previa: true, xmlDps: r.xmlDpsAssinado ?? r.xml, leiaute: r.leiaute, ibscbs: r.ibscbs ?? null, semAssinatura: Boolean(r.simulacao) };
  }

  const comum = () => ({
    empresaId: empresa.id, ambiente: empresa.ambiente, tomadorNome: params.tomador?.nome ?? 'Tomador não identificado',
    tomadorDoc: so(entrada.tomador?.documento), descricao: params.servico.descricao, vServ: params.valores.vServ, entrada,
  });
  let nDPS;
  try {
    let r;
    if (empresa.ambiente === 'simulacao') {
      // Valida a DPS real (leiaute + IBS/CBS) e usa o simulador para "autorizar".
      nDPS = await consumirNDps(empresa);
      const v = await enviarDps(empresa, cliente, buildDps({ ...params, nDPS }), entrada);
      const f = await cliente.emitir({ ...params, nDPS });
      r = { status: 'ok', nfse: f.nfse, leiaute: v.leiaute, ibscbs: v.ibscbs };
    } else {
      nDPS = await consumirNDps(empresa);
      r = await enviarDps(empresa, cliente, buildDps({ ...params, nDPS }), entrada);
    }

    if (entrada.salvarTomador) await salvarTomadorSeNovo(empresa, entrada.tomador);
    const extra = { leiaute: r.leiaute, ...(r.ibscbs ? { ibscbs: r.ibscbs } : {}) };

    if (r.status === 'retry_pending') {
      const nota = await db.inserir('notas', {
        ...comum(), ...extra, status: 'pendente', idDps: r.pending.idDps, nDPS: r.pending.nDPS, serie: r.pending.serie, erro: r.error.message,
      });
      return { status: 'pendente', nota };
    }
    return { status: 'autorizada', nota: await registrarAutorizada(empresa, r.nfse, entrada, extra) };
  } catch (err) {
    if (err instanceof ReceitaRejectionError) {
      const mensagens = err.mensagens.map((m) => `[${m.codigo}] ${m.descricao}${m.complemento ? ` — ${m.complemento}` : ''}`);
      if (err.mensagens.some((m) => m.codigo === 'E0718')) mensagens.push(dicaE0718(empresa));
      const nota = await db.inserir('notas', {
        ...comum(), status: 'rejeitada', idDps: err.idDps ?? null, nDPS, erro: mensagens.join(' | '),
      });
      return { status: 'rejeitada', nota, mensagens };
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Importação do Portal Nacional (distribuição por NSU no ADN)
// ---------------------------------------------------------------------------
const EVENTOS_CANCELAM = new Set([
  'CANCELAMENTO',
  'CANCELAMENTO_POR_SUBSTITUICAO',
  'CANCELAMENTO_DEFERIDO_ANALISE_FISCAL',
  'CANCELAMENTO_POR_OFICIO',
]);

const docDe = (ident = {}) => ident.CNPJ ?? ident.CPF ?? '';

/** Reconstrói os dados de preenchimento a partir de uma NFS-e (para "usar como modelo"). */
function entradaDeNfse(nfse) {
  const dps = nfse.infNFSe.DPS.infDPS;
  const toma = dps.toma;
  const end = toma?.end;
  const endNac = end?.localidade?.endNac;
  const trib = dps.valores.trib?.tribMun ?? {};
  return {
    dataCompetencia: new Date(dps.dCompet).toISOString().slice(0, 10),
    tomador: toma ? {
      documento: docDe(toma.identificador),
      nome: toma.xNome,
      email: toma.email ?? '',
      fone: toma.fone ?? '',
      inscricaoMunicipal: toma.IM ?? '',
      ...(endNac ? { endereco: {
        cep: endNac.CEP, codMunicipio: endNac.cMun, logradouro: end.xLgr, numero: end.nro,
        bairro: end.xBairro, complemento: end.xCpl ?? '',
      } } : {}),
    } : null,
    servico: {
      cTribNac: dps.serv.cServ.cTribNac,
      cNBS: dps.serv.cServ.cNBS ?? '',
      cTribMun: dps.serv.cServ.cTribMun ?? '',
      descricao: dps.serv.cServ.xDescServ,
      codMunicipioPrestacao: dps.serv.locPrest?.cLocPrestacao ?? '',
    },
    valores: {
      vServ: dps.valores.vServPrest.vServ,
      aliqIss: trib.pAliq ?? '',
      tpRetISSQN: trib.tpRetISSQN ?? '1',
    },
  };
}

async function importarNfse(empresa, doc, placar) {
  const nfse = lerNfse(parseNfseXml, doc.xmlDocumento);
  const inf = nfse.infNFSe;
  const chave = inf.chaveAcesso;
  const existentes = await db.listar('notas', (n) => n.chaveAcesso === chave && n.empresaId === empresa.id);
  if (existentes.length) { placar.jaExistiam++; return; }

  const emitida = docDe(inf.emit.identificador) === empresa.cnpj;
  const canceladas = (await db.mapaObter('_canceladas', escopo(empresa))) ?? [];
  await salvarXml(chave, doc.xmlDocumento);
  await db.inserir('notas', {
    empresaId: empresa.id,
    ambiente: empresa.ambiente,
    origem: 'portal',
    papel: emitida ? 'emitida' : 'recebida',
    status: canceladas.includes(chave) ? 'cancelada' : 'autorizada',
    idDps: inf.DPS.infDPS.Id,
    nsu: doc.nsu,
    alertas: [],
    ...(emitida ? { entrada: entradaDeNfse(nfse) } : {}),
    ...resumo(nfse),
    // Em nota recebida, a contraparte exibida é o prestador.
    ...(emitida ? {} : { tomadorNome: inf.emit.xNome, tomadorDoc: docDe(inf.emit.identificador) }),
  });
  if (emitida) placar.emitidas++; else placar.recebidas++;
}

async function registrarCancelamento(empresa, chave, placar) {
  await db.mapaAtualizar('_canceladas', escopo(empresa), (lista = []) => (lista.includes(chave) ? lista : [...lista, chave]));
  const nota = (await db.listar('notas', (n) => n.chaveAcesso === chave && n.empresaId === empresa.id))[0];
  if (nota && !['cancelada', 'substituida'].includes(nota.status)) {
    await db.atualizar('notas', nota.id, { status: 'cancelada' });
    placar.canceladas++;
  }
}

/**
 * Busca no Ambiente de Dados Nacional todas as NFS-e em que a empresa é
 * prestadora ou tomadora, a partir do último NSU lido (0 na primeira vez).
 * Processa até `maxPaginas` lotes por chamada; `concluido` indica se zerou a fila.
 */
export async function sincronizarPortal(empresa, { maxPaginas = 25 } = {}) {
  if (empresa.ambiente === 'simulacao') throw erroUsuario('No modo Simulação não há portal para consultar. Use Produção ou Produção Restrita.');
  const cliente = await clientePara(empresa);
  const k = escopo(empresa);
  let ultimoNsu = Number((await db.mapaObter('_nsu', k)) ?? 0);
  const placar = { emitidas: 0, recebidas: 0, canceladas: 0, jaExistiam: 0, ignorados: 0, concluido: false };

  for (let pagina = 0; pagina < maxPaginas; pagina++) {
    // Desde a v1.1 da API do ADN (nov/2026), a consulta sem `cnpjConsulta` volta
    // REJEICAO sem mensagem; informando o próprio CNPJ ela funciona (TipoConsulta=CnpjBase).
    const r = await cliente.fetchByNsu({ ultimoNsu, ...(empresa.cnpj.length === 14 ? { cnpjConsulta: empresa.cnpj } : { }) });
    if (r.status === 'REJEICAO') {
      const msgs = [...r.erros, ...r.alertas].map((e) => `[${e.codigo}] ${e.descricao}${e.complemento ? ` — ${e.complemento}` : ''}`);
      throw erroUsuario('O Portal Nacional recusou a consulta.', msgs.length ? msgs : [`NSU ${ultimoNsu}: rejeição sem mensagem — use o diagnóstico do Portal (Empresas → Diagnóstico).`]);
    }
    for (const doc of r.documentos) {
      try {
        if (doc.tipoDocumento === 'NFSE') await importarNfse(empresa, doc, placar);
        else if (doc.tipoDocumento === 'EVENTO' && EVENTOS_CANCELAM.has(doc.tipoEvento)) {
          await registrarCancelamento(empresa, doc.chaveAcesso, placar);
          if (doc.tipoEvento === 'CANCELAMENTO_DEFERIDO_ANALISE_FISCAL') await registrarAnaliseFiscal(empresa, doc.chaveAcesso, 'deferida');
        } else if (doc.tipoDocumento === 'EVENTO' && doc.tipoEvento === 'SOLICITACAO_CANCELAMENTO_ANALISE_FISCAL') await registrarAnaliseFiscal(empresa, doc.chaveAcesso, 'solicitada');
        else if (doc.tipoDocumento === 'EVENTO' && doc.tipoEvento === 'CANCELAMENTO_INDEFERIDO_ANALISE_FISCAL') await registrarAnaliseFiscal(empresa, doc.chaveAcesso, 'indeferida');
        else placar.ignorados++;
      } catch (err) {
        placar.ignorados++;
        console.error(`NSU ${doc.nsu} não importado:`, err.message);
      }
    }
    await db.mapaAtualizar('_nsu', k, () => r.ultimoNsu);
    if (r.status === 'NENHUM_DOCUMENTO_LOCALIZADO' || r.ultimoNsu === ultimoNsu) { placar.concluido = true; break; }
    ultimoNsu = r.ultimoNsu;
  }
  placar.ultimoNsu = Number((await db.mapaObter('_nsu', k)) ?? 0);
  placar.substituicoes = await vincularSubstituicoes(empresa);
  return placar;
}

/**
 * Liga cada NFS-e substituta à original: a substituta traz, na DPS, o grupo
 * <subst><chSubstda>chave da original</chSubstda>. A original passa de
 * "cancelada" para "substituida" e as duas mostram o número uma da outra.
 * Lê os XML já guardados, então também corrige notas importadas antes.
 */
export async function vincularSubstituicoes(empresa) {
  const notas = await db.listar('notas', (n) => n.empresaId === empresa.id && n.chaveAcesso && (n.papel ?? 'emitida') === 'emitida');
  const porChave = new Map(notas.map((n) => [n.chaveAcesso, n]));
  let ligadas = 0;
  for (const nova of notas) {
    if (nova.substituiChave && porChave.get(nova.substituiChave)?.status === 'substituida') continue;
    let xml;
    try { xml = await fs.readFile(path.join(DIR_XML(), `${nova.chaveAcesso}.xml`), 'utf8'); } catch { continue; }
    const m = xml.match(/<chSubstda>(\d{50})<\/chSubstda>/);
    if (!m) continue;
    const original = porChave.get(m[1]);
    const motivo = xml.match(/<subst>[\s\S]*?<xMotivo>([^<]*)<\/xMotivo>/)?.[1];
    await db.atualizar('notas', nova.id, {
      substituiChave: m[1], substituiNumero: original?.numero ?? nova.substituiNumero,
      ...(motivo && !nova.motivoSubstituicao ? { motivoSubstituicao: motivo } : {}),
    });
    if (original && original.status !== 'substituida') {
      await db.atualizar('notas', original.id, { status: 'substituida', substituidaPor: nova.chaveAcesso, substituidaPorNumero: nova.numero });
      ligadas++;
    }
  }
  return ligadas;
}

// ---------------------------------------------------------------------------
// Substituição (nova DPS com <subst>; o Sistema Nacional cancela a original
// com o evento 105102 de forma atômica)
// ---------------------------------------------------------------------------
export const MOTIVOS_SUBSTITUICAO = {
  '01': 'Desenquadramento do Simples Nacional',
  '02': 'Enquadramento no Simples Nacional',
  '03': 'Inclusão retroativa de imunidade/isenção',
  '04': 'Exclusão retroativa de imunidade/isenção',
  '05': 'Rejeição pelo tomador/intermediário',
  '99': 'Outros',
};

export async function substituir(empresa, original, entrada, { cMotivo, xMotivo }) {
  if (!original?.chaveAcesso || original.status !== 'autorizada' || (original.papel ?? 'emitida') !== 'emitida') {
    throw erroUsuario('Só é possível substituir uma NFS-e emitida e autorizada.');
  }
  if (!MOTIVOS_SUBSTITUICAO[cMotivo]) throw erroUsuario('Escolha o motivo da substituição.');
  const motivo = String(xMotivo ?? '').trim();
  if (cMotivo === '99' && motivo.length < 15) throw erroUsuario('Descreva o motivo da substituição (mínimo de 15 caracteres).');

  const params = montarParams(empresa, entrada);
  const cliente = await clientePara(empresa);
  const nDPS = await consumirNDps(empresa);
  const base = buildDps({ ...params, nDPS });
  const novaDps = { ...base, infDPS: { ...base.infDPS, subst: { chSubstda: original.chaveAcesso, cMotivo, ...(motivo ? { xMotivo: motivo } : {}) } } };
  const vinculo = { substituiChave: original.chaveAcesso, substituiNumero: original.numero, motivoSubstituicao: `${MOTIVOS_SUBSTITUICAO[cMotivo]}${motivo ? ` — ${motivo}` : ''}` };

  try {
    let r;
    if (empresa.ambiente === 'simulacao') {
      const v = await enviarDps(empresa, cliente, novaDps, entrada);
      const f = await cliente.substituir({ chaveOriginal: original.chaveAcesso, novaDps: base, cMotivo, ...(motivo ? { xMotivo: motivo } : {}) });
      r = { status: 'ok', nfse: f.novaNfse, leiaute: v.leiaute, ibscbs: v.ibscbs };
    } else {
      r = await enviarDps(empresa, cliente, novaDps, entrada);
    }
    Object.assign(vinculo, { leiaute: r.leiaute, ...(r.ibscbs ? { ibscbs: r.ibscbs } : {}) });
    if (r.status === 'retry_pending') {
      const nota = await db.inserir('notas', {
        empresaId: empresa.id, ambiente: empresa.ambiente, status: 'pendente', origem: 'sistema', papel: 'emitida',
        idDps: r.pending.idDps, nDPS, serie: params.serie,
        tomadorNome: params.tomador?.nome ?? 'Tomador não identificado', tomadorDoc: so(entrada.tomador?.documento),
        descricao: params.servico.descricao, vServ: params.valores.vServ, erro: r.error.message, entrada, ...vinculo,
      });
      return { status: 'pendente', nota };
    }
    const nova = await registrarAutorizada(empresa, r.nfse, entrada, vinculo);
    await db.atualizar('notas', original.id, { status: 'substituida', substituidaPor: nova.chaveAcesso, substituidaPorNumero: nova.numero });
    return { status: 'autorizada', nota: nova, substituida: original.numero };
  } catch (err) {
    if (err instanceof ReceitaRejectionError) {
      const mensagens = err.mensagens.map((m) => `[${m.codigo}] ${m.descricao}${m.complemento ? ` — ${m.complemento}` : ''}`);
      return { status: 'rejeitada', mensagens, nota: { erro: mensagens.join(' | ') } };
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Cancelamento simples (evento 101101)
// ---------------------------------------------------------------------------
export const MOTIVOS_CANCELAMENTO = {
  '1': 'Erro na emissão',
  '2': 'Serviço não prestado',
  '9': 'Outros',
};

export async function cancelar(empresa, nota, { cMotivo, xMotivo }) {
  const motivo = validarPedidoCancelamento(empresa, nota, cMotivo, xMotivo);
  const cliente = await clientePara(empresa);
  try {
    const r = await cliente.cancelar({
      chaveAcesso: nota.chaveAcesso, autor: { CNPJ: empresa.cnpj }, cMotivo, xMotivo: motivo,
      tpAmb: empresa.ambiente === 'producao' ? TipoAmbienteDps.Producao : TipoAmbienteDps.Homologacao, verAplic: VER_APLIC,
    });
    const dados = { motivoCancelamento: `${MOTIVOS_CANCELAMENTO[cMotivo]} — ${motivo}` };
    if (r.status === 'retry_pending') {
      await db.atualizar('notas', nota.id, { ...dados, cancelamentoPendente: true });
      return { status: 'pendente', mensagem: 'A Receita não respondeu. O pedido ficou guardado e será reenviado automaticamente.' };
    }
    await marcarCancelada(empresa, nota, dados, r.evento);
    return { status: 'cancelada', numero: nota.numero };
  } catch (err) {
    if (err instanceof ReceitaRejectionError) {
      const mensagens = err.mensagens.map((m) => `[${m.codigo}] ${m.descricao}${m.complemento ? ` — ${m.complemento}` : ''}`);
      return { status: 'rejeitada', mensagens };
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Solicitação de Análise Fiscal para Cancelamento (evento 101103). Usada quando
// a regra do município não permite o cancelamento direto (prazo vencido, ou
// prefeituras que exigem requerimento/termo assinado). O Sistema Nacional só
// recebe motivo e justificativa em texto; o requerimento assinado e demais
// anexos ficam guardados com a nota para o processo na prefeitura.
// ---------------------------------------------------------------------------
function validarPedidoCancelamento(empresa, nota, cMotivo, xMotivo) {
  if (!nota?.chaveAcesso || nota.status !== 'autorizada' || (nota.papel ?? 'emitida') !== 'emitida') {
    throw erroUsuario('Só é possível cancelar uma NFS-e emitida e autorizada.');
  }
  if (nota.ambiente !== empresa.ambiente) throw erroUsuario('Esta nota é de outro ambiente que não o atual da empresa.');
  if (!MOTIVOS_CANCELAMENTO[cMotivo]) throw erroUsuario('Escolha o motivo do cancelamento.');
  const motivo = String(xMotivo ?? '').trim();
  if (motivo.length < 15) throw erroUsuario('Descreva o motivo do cancelamento (mínimo de 15 caracteres).');
  if (motivo.length > 255) throw erroUsuario('A justificativa pode ter no máximo 255 caracteres.');
  return motivo;
}

/** Monta o pedRegEvento 101103 a partir do leiaute do 101101 (mesma sequência de campos). */
export function xmlAnaliseFiscal(empresa, chaveAcesso, cMotivo, xMotivo, dhEvento = new Date()) {
  const base = buildCancelamentoXml({
    chaveAcesso, autor: { CNPJ: empresa.cnpj }, cMotivo, xMotivo, dhEvento, verAplic: VER_APLIC,
    tpAmb: empresa.ambiente === 'producao' ? TipoAmbienteDps.Producao : TipoAmbienteDps.Homologacao,
  });
  const id = buildEventoPedidoId({ chaveAcesso, tipoEvento: '101103' });
  const xml = base
    .replace(/Id="[^"]+"/, `Id="${id}"`)
    .replace('<e101101><xDesc>Cancelamento de NFS-e</xDesc>', '<e101103><xDesc>Solicitação de Análise Fiscal para Cancelamento de NFS-e</xDesc>')
    .replace('</e101101>', '</e101103>');
  if (!xml.includes('<e101103>')) throw new Error('Falha ao montar o evento 101103.');
  return xml;
}

export async function solicitarAnaliseFiscal(empresa, nota, { cMotivo, xMotivo }) {
  const motivo = validarPedidoCancelamento(empresa, nota, cMotivo, xMotivo);
  if (nota.analiseFiscal?.status === 'solicitada') throw erroUsuario('Já existe uma solicitação de análise fiscal para esta nota aguardando a prefeitura.');
  const xml = xmlAnaliseFiscal(empresa, nota.chaveAcesso, cMotivo, motivo);
  await validatePedRegEventoXml(xml);
  let xmlEvento = '';
  if (empresa.ambiente !== 'simulacao') {
    const cliente = await clientePara(empresa);
    const estado = await cliente.ensureState();
    try {
      const r = await postEvento(estado.sefin, estado.certificate, nota.chaveAcesso, xml);
      xmlEvento = r.xmlEvento;
    } catch (err) {
      if (err instanceof ReceitaRejectionError) {
        return { status: 'rejeitada', mensagens: err.mensagens.map((m) => `[${m.codigo}] ${m.descricao}${m.complemento ? ` — ${m.complemento}` : ''}`) };
      }
      throw err;
    }
  }
  if (xmlEvento) {
    await fs.mkdir(DIR_XML(), { recursive: true });
    await fs.writeFile(path.join(DIR_XML(), `${nota.chaveAcesso}-analise-fiscal.xml`), xmlEvento);
  }
  const analiseFiscal = { status: 'solicitada', solicitadaEm: new Date().toISOString(), motivo: `${MOTIVOS_CANCELAMENTO[cMotivo]} — ${motivo}` };
  await db.atualizar('notas', nota.id, { analiseFiscal });
  return { status: 'analise_solicitada', numero: nota.numero };
}

async function registrarAnaliseFiscal(empresa, chave, situacao) {
  const nota = (await db.listar('notas', (n) => n.chaveAcesso === chave && n.empresaId === empresa.id))[0];
  if (!nota) return;
  await db.atualizar('notas', nota.id, { analiseFiscal: { ...(nota.analiseFiscal ?? {}), status: situacao, atualizadaEm: new Date().toISOString() } });
}

// ---------------------------------------------------------------------------
// Anexos da nota (requerimento assinado, termo do tomador, comprovantes…)
// ---------------------------------------------------------------------------
const DIR_ANEXOS = (notaId) => path.join(db.DATA_DIR, 'anexos', notaId);
const TIPOS_ANEXO = { 'application/pdf': '.pdf', 'image/png': '.png', 'image/jpeg': '.jpg' };

export async function salvarAnexo(nota, { nome, tipo, base64, descricao }) {
  if (!TIPOS_ANEXO[tipo]) throw erroUsuario('Anexe um arquivo PDF, PNG ou JPG.');
  const conteudo = Buffer.from(String(base64 ?? ''), 'base64');
  if (!conteudo.length) throw erroUsuario('Arquivo vazio.');
  if (conteudo.length > 10 * 1024 * 1024) throw erroUsuario('O anexo pode ter no máximo 10 MB.');
  const id = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  const limpo = String(nome ?? 'anexo').replace(/[^\w.\- ]+/g, '_').slice(0, 80);
  await fs.mkdir(DIR_ANEXOS(nota.id), { recursive: true });
  await fs.writeFile(path.join(DIR_ANEXOS(nota.id), id + TIPOS_ANEXO[tipo]), conteudo);
  const anexo = { id, nome: limpo, tipo, tamanho: conteudo.length, descricao: String(descricao ?? '').slice(0, 120), criadoEm: new Date().toISOString() };
  await db.atualizar('notas', nota.id, { anexos: [...(nota.anexos ?? []), anexo] });
  return anexo;
}

export async function lerAnexo(nota, anexoId) {
  const anexo = (nota.anexos ?? []).find((a) => a.id === anexoId);
  if (!anexo) return null;
  return { anexo, conteudo: await fs.readFile(path.join(DIR_ANEXOS(nota.id), anexo.id + TIPOS_ANEXO[anexo.tipo])) };
}

export async function removerAnexo(nota, anexoId) {
  const anexo = (nota.anexos ?? []).find((a) => a.id === anexoId);
  if (!anexo) return false;
  await fs.rm(path.join(DIR_ANEXOS(nota.id), anexo.id + TIPOS_ANEXO[anexo.tipo]), { force: true });
  await db.atualizar('notas', nota.id, { anexos: nota.anexos.filter((a) => a.id !== anexoId) });
  return true;
}

async function marcarCancelada(empresa, nota, dados = {}, evento) {
  if (evento?.xmlEvento) {
    await fs.mkdir(path.join(db.DATA_DIR, 'xml'), { recursive: true });
    await fs.writeFile(path.join(db.DATA_DIR, 'xml', `${nota.chaveAcesso}-cancelamento.xml`), evento.xmlEvento);
  }
  await db.mapaAtualizar('_canceladas', escopo(empresa), (lista = []) => (lista.includes(nota.chaveAcesso) ? lista : [...lista, nota.chaveAcesso]));
  await db.atualizar('notas', nota.id, { ...dados, status: 'cancelada', cancelamentoPendente: false, canceladaEm: new Date().toISOString() });
}

/** Reenvia emissões pendentes (falha de rede/instabilidade da Receita). */
export async function reprocessarPendentes() {
  const empresas = await db.listar('empresas', (e) => e.ambiente !== 'simulacao' && !e.excluidaEm);
  const resultado = [];
  for (const empresa of empresas) {
    const pend = (await db.mapaObter('_pendentes', escopo(empresa))) ?? [];
    if (!pend.length) continue;
    if ((await situacaoLicenca(empresa.cnpj)).bloqueia) continue;
    const cliente = await clientePara(empresa);
    // Emissões pendentes: reenviadas pelo nosso fluxo (lê NFS-e de qualquer leiaute).
    const store = storePara(empresa);
    for (const p of (await store.list()).filter((e) => e.kind === 'emission' && e.xmlAssinado)) {
      const nota = (await db.listar('notas', (n) => n.idDps === p.idDps && n.status === 'pendente'))[0];
      try {
        const estado = await cliente.ensureState();
        const body = await estado.sefin.post('/nfse', { dpsXmlGZipB64: gzipSync(p.xmlAssinado).toString('base64') }, { acceptedStatuses: [400] });
        const emissao = respostaEmissao(body);
        await store.delete(p.id);
        const nova = await registrarAutorizada(empresa, emissao, nota?.entrada, nota ? { leiaute: nota.leiaute, ...(nota.ibscbs ? { ibscbs: nota.ibscbs } : {}) } : {});
        if (nota?.substituiChave) {
          const original = (await db.listar('notas', (n) => n.chaveAcesso === nota.substituiChave))[0];
          if (original) await db.atualizar('notas', original.id, { status: 'substituida', substituidaPor: nova.chaveAcesso, substituidaPorNumero: nova.numero });
        }
        resultado.push({ empresa: empresa.razaoSocial, status: 'success_emission' });
      } catch (err) {
        if (err instanceof ReceitaRejectionError) {
          await store.delete(p.id);
          const msg = err.mensagens.map((m) => `[${m.codigo}] ${m.descricao}`).join(' | ');
          if (nota) await db.atualizar('notas', nota.id, { status: 'rejeitada', erro: msg });
          resultado.push({ empresa: empresa.razaoSocial, status: 'failed_permanent' });
        } else {
          await store.save({ ...p, attempts: (p.attempts ?? 1) + 1, lastAttemptAt: new Date(), lastError: { message: err.message, errorName: err.name, transient: true } });
          resultado.push({ empresa: empresa.razaoSocial, status: 'still_pending' });
        }
      }
    }
    for (const item of await cliente.replayPendingEvents()) {
      if (item.status === 'success') {
        const nota = (await db.listar('notas', (n) => n.cancelamentoPendente && n.chaveAcesso && item.id.includes(n.chaveAcesso)))[0];
        if (nota) await marcarCancelada(empresa, nota, {}, item.evento);
      } else if (item.status === 'success_emission') {
        const nota = (await db.listar('notas', (n) => n.idDps === item.emission.idDps))[0];
        const nova = await registrarAutorizada(empresa, item.emission, nota?.entrada);
        if (nota?.substituiChave) {
          const original = (await db.listar('notas', (n) => n.chaveAcesso === nota.substituiChave))[0];
          if (original) await db.atualizar('notas', original.id, { status: 'substituida', substituidaPor: nova.chaveAcesso, substituidaPorNumero: nova.numero });
        }
      } else if (item.status === 'failed_permanent') {
        const nota = (await db.listar('notas', (n) => n.status === 'pendente' && item.id.endsWith(n.idDps)))[0];
        if (nota) await db.atualizar('notas', nota.id, { status: 'rejeitada', erro: item.error.message });
      }
      resultado.push({ empresa: empresa.razaoSocial, status: item.status });
    }
  }
  return resultado;
}

export async function danfsePdf(nota) {
  let nfse;
  let xml = '';
  if (nota.ambiente === 'simulacao') {
    const data = (_k, v) => (typeof v === 'string' && /^\d{4}-\d\d-\d\dT/.test(v) ? new Date(v) : v);
    nfse = JSON.parse(await fs.readFile(path.join(DIR_XML(), `${path.basename(nota.chaveAcesso)}.json`), 'utf8'), data);
  } else {
    xml = await lerXml(nota.chaveAcesso);
    nfse = lerNfse(parseNfseXml, xml);
  }
  return gerarDanfsePdf(nfse, {
    ibs: { ...(nota.ibscbs ?? {}), ...(ibscbsDeXml(xml) ?? {}) },
    ambiente: nota.ambiente,
    situacao: ['cancelada', 'substituida'].includes(nota.status) ? nota.status : undefined,
    ...(nota.ambiente === 'simulacao' ? { observacoes: 'DOCUMENTO DE SIMULAÇÃO — SEM VALOR FISCAL' } : {}),
  });
}

/** Uso exclusivo dos testes: injeta um cliente (ex.: NfseClientFake) para a empresa. */
export function _injetarCliente(empresa, cliente) {
  clientes.set(empresa.id, { versao: versaoCliente(empresa, null), cliente });
}

/**
 * Diagnóstico: chama o ADN direto (mTLS com o A1 da empresa) e devolve a
 * resposta crua de GET /DFe/{nsu}, para entender rejeições sem mensagem.
 */
export async function diagnosticoAdn(empresa, nsus = [0, 1], consulta = '') {
  const { Agent, request } = await import('undici');
  const cert = await lerCertificado(empresa.id);
  if (!cert) throw erroUsuario('Empresa sem certificado A1.');
  const a1 = parsePfx(cert.pfx, cert.password);
  const agente = new Agent({ allowH2: false, connect: { key: a1.keyPem, cert: a1.certPem, ALPNProtocols: ['http/1.1'] } });
  const base = empresa.ambiente === 'producao' ? 'https://adn.nfse.gov.br/contribuintes' : 'https://adn.producaorestrita.nfse.gov.br/contribuintes';
  const saida = { ambiente: empresa.ambiente, base, certificado: a1.subject, respostas: [] };
  try {
    for (const nsu of nsus) {
      try {
        const r = await request(`${base}/DFe/${nsu}${consulta ? `?${consulta}` : ''}`, { dispatcher: agente, headers: { accept: 'application/json' } });
        const texto = await r.body.text();
        saida.respostas.push({ nsu, http: r.statusCode, corpo: texto.slice(0, 4000) });
      } catch (err) {
        saida.respostas.push({ nsu, falha: `${err.name}: ${err.message}` });
      }
    }
  } finally {
    await agente.close();
  }
  return saida;
}

// ---------------------------------------------------------------------------
// Recibo de pagamento vinculado à nota, assinado com o A1 da própria empresa.
// ---------------------------------------------------------------------------
const hojeBr = () => new Intl.DateTimeFormat('sv-SE', { timeZone: 'America/Sao_Paulo' }).format(new Date());
async function certificadoDoRecibo(empresa) {
  const c = await lerCertificado(empresa.id);
  if (!c) return null;
  try {
    const a1 = parsePfx(c.pfx, c.password);
    return { pfx: c.pfx, password: c.password, keyPem: a1.keyPem, certPem: a1.certPem, titular: a1.subject || empresa.razaoSocial, venceEm: a1.expiresOn };
  } catch (err) {
    throw erroUsuario(`O certificado A1 da empresa não pode assinar o recibo: ${err.message}`);
  }
}
/** Endereço do prestador (emitente) lido do XML da própria NFS-e. */
async function enderecoDoEmitente(nota) {
  if (!nota.chaveAcesso || nota.ambiente === 'simulacao') return '';
  try {
    const xml = await lerXml(nota.chaveAcesso);
    const emit = /<emit>([\s\S]*?)<\/emit>/.exec(xml)?.[1] ?? '';
    const t = (tag) => new RegExp(`<${tag}>([^<]*)</${tag}>`).exec(emit)?.[1]?.trim() ?? '';
    const cep = t('CEP');
    return [[t('xLgr'), t('nro')].filter(Boolean).join(', '), t('xCpl'), t('xBairro'), cep && `CEP ${cep.replace(/^(\d{5})(\d{3})$/, '$1-$2')}`].filter(Boolean).join(' - ');
  } catch { return ''; }
}
export async function padraoRecibo(nota) {
  const empresa = await db.obter('empresas', nota.empresaId);
  const pref = (await db.mapaObter('_config', `recibo:${nota.empresaId}`)) ?? {};
  const cert = await lerCertificado(empresa.id);
  let titular = null;
  if (cert) { try { titular = parsePfx(cert.pfx, cert.password).subject; } catch { titular = null; } }
  return {
    valor: Number(nota.recibo?.valor ?? nota.vLiq ?? nota.vServ),
    referente: nota.recibo?.referente ?? String(nota.descricao ?? '').split(/\n\s*\n/)[0].slice(0, 600),
    dataPagamento: nota.recibo?.dataPagamento ?? (nota.dhProc ? nota.dhProc.slice(0, 10) : hojeBr()),
    dataEmissao: hojeBr(),
    forma: nota.recibo?.forma ?? pref.forma ?? 'PIX',
    cidade: pref.cidade ?? (empresa.municipio ?? '').replace(/\/.*$/, '').trim(),
    registro: pref.registro ?? '',
    assinante: pref.assinante ?? empresa.razaoSocial,
    endereco: pref.endereco || (await enderecoDoEmitente(nota)),
    representante: pref.representante ?? '', cpfRepresentante: pref.cpfRepresentante ?? '', cpfCompleto: Boolean(pref.cpfCompleto),
    obs: nota.recibo?.obs ?? '',
    temCertificado: Boolean(cert), titular,
  };
}
export async function gerarRecibo(nota, entrada) {
  if (nota.status !== 'autorizada') throw erroUsuario('Só é possível gerar recibo de nota autorizada (não cancelada nem substituída).');
  const empresa = await db.obter('empresas', nota.empresaId);
  const txt = (v, max) => String(v ?? '').trim().slice(0, max);
  const valor = Number(String(entrada.valor ?? '').replace(/\./g, '').replace(',', '.')) || Number(entrada.valor);
  if (!(valor > 0)) throw erroUsuario('Informe o valor recebido.');
  if (valor > Number(nota.vServ) + 0.001) throw erroUsuario('O valor do recibo não pode ser maior que o valor da nota.');
  const dados = {
    valor: Math.round(valor * 100) / 100, referente: txt(entrada.referente, 600) || txt(nota.descricao, 600),
    dataPagamento: /^\d{4}-\d{2}-\d{2}$/.test(entrada.dataPagamento) ? entrada.dataPagamento : hojeBr(),
    dataEmissao: /^\d{4}-\d{2}-\d{2}$/.test(entrada.dataEmissao) ? entrada.dataEmissao : hojeBr(),
    forma: txt(entrada.forma, 40) || 'PIX', cidade: txt(entrada.cidade, 60) || 'Campina Grande',
    registro: txt(entrada.registro, 80), assinante: txt(entrada.assinante, 120) || empresa.razaoSocial, obs: txt(entrada.obs, 300),
    endereco: txt(entrada.endereco, 200), representante: txt(entrada.representante, 120),
    cpfRepresentante: String(entrada.cpfRepresentante ?? '').replace(/\D/g, '').slice(0, 11), cpfCompleto: Boolean(entrada.cpfCompleto),
  };
  if (!dados.endereco) throw erroUsuario('Informe o endereço da empresa: a Receita exige nome, endereço e CPF/CNPJ de quem recebeu para aceitar o recibo como despesa médica no IR.');
  if (dados.cpfRepresentante && dados.cpfRepresentante.length !== 11) throw erroUsuario('CPF do sócio administrador incompleto.');
  if (dados.cpfRepresentante && !dados.representante) throw erroUsuario('Informe o nome do sócio administrador junto com o CPF.');
  const cert = entrada.semAssinatura ? null : await certificadoDoRecibo(empresa);
  const { pdf, assinado } = await gerarReciboPdf(nota, empresa, dados, cert);
  await db.mapaAtualizar('_config', `recibo:${nota.empresaId}`, () => ({
    cidade: dados.cidade, registro: dados.registro, assinante: dados.assinante, forma: dados.forma, endereco: dados.endereco,
    representante: dados.representante, cpfRepresentante: dados.cpfRepresentante, cpfCompleto: dados.cpfCompleto,
  }));
  await db.atualizar('notas', nota.id, { recibo: { ...dados, assinado, geradoEm: new Date().toISOString() } });
  return { pdf, assinado };
}
