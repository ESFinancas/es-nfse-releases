// Recibo de pagamento vinculado à NFS-e, assinado digitalmente (PAdES/PKCS#7)
// com o certificado A1 ICP-Brasil da empresa emitente.
import PDFDocument from 'pdfkit';
import QRCode from 'qrcode';
import forge from 'node-forge';
import { SignPdf } from '@signpdf/signpdf';
import { plainAddPlaceholder } from '@signpdf/placeholder-plain';
import { P12Signer } from '@signpdf/signer-p12';

const URL_CONSULTA = 'https://www.nfse.gov.br/ConsultaPublica/?tpc=1&chave=';
export const FORMAS = ['PIX', 'Dinheiro', 'Transferência bancária', 'Cartão de crédito', 'Cartão de débito', 'Boleto', 'Cheque'];

// ------------------------------------------------------------ valor por extenso
const UN = ['', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez', 'onze', 'doze', 'treze', 'quatorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'];
const DEZ = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
const CEM = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
function ate999(n) {
  if (n === 0) return '';
  if (n === 100) return 'cem';
  const c = Math.floor(n / 100); const r = n % 100;
  const partes = [];
  if (c) partes.push(CEM[c]);
  if (r) partes.push(r < 20 ? UN[r] : [DEZ[Math.floor(r / 10)], UN[r % 10]].filter(Boolean).join(' e '));
  return partes.join(' e ');
}
function inteiroExtenso(n) {
  if (n === 0) return 'zero';
  const grupos = [];
  let x = n;
  while (x > 0) { grupos.push(x % 1000); x = Math.floor(x / 1000); }
  const nomes = [['', ''], ['mil', 'mil'], ['milhão', 'milhões'], ['bilhão', 'bilhões']];
  const partes = [];
  for (let i = grupos.length - 1; i >= 0; i--) {
    const g = grupos[i];
    if (!g) continue;
    let t = i === 1 && g === 1 ? 'mil' : `${ate999(g)}${nomes[i][0] ? ` ${g === 1 ? nomes[i][0] : nomes[i][1]}` : ''}`;
    partes.push({ t, g, i });
  }
  return partes.map((p, k) => {
    if (k === 0) return p.t;
    // "e" antes do último grupo quando ele é < 100 ou centena redonda
    const ultimo = k === partes.length - 1 && p.i === 0;
    return `${ultimo && (p.g < 100 || p.g % 100 === 0) ? ' e ' : ', '}${p.t}`;
  }).join('').replace(/^, /, '');
}
export function valorPorExtenso(valor) {
  const centavos = Math.round(Number(valor) * 100);
  const reais = Math.floor(centavos / 100); const cent = centavos % 100;
  const de = reais >= 1e6 && reais % 1e6 === 0 ? ' de' : '';
  const r = reais ? `${inteiroExtenso(reais)}${de} ${reais === 1 ? 'real' : 'reais'}` : '';
  const c = cent ? `${inteiroExtenso(cent)} ${cent === 1 ? 'centavo' : 'centavos'}` : '';
  return [r, c].filter(Boolean).join(' e ') || 'zero real';
}

// ------------------------------------------------------------ PDF
const moeda = (v) => Number(v ?? 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const fmtDoc = (d = '') => (d.length === 14
  ? d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5')
  : d.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4'));
const dataBr = (iso) => (iso ? iso.slice(0, 10).split('-').reverse().join('/') : '');
const extensoData = (iso) => new Date(`${iso.slice(0, 10)}T12:00:00Z`).toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
const dataHora = (iso) => new Date(iso).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', dateStyle: 'short', timeStyle: 'short' });

async function montarPdf(nota, empresa, d, titular) {
  const M = 56;
  const pdf = new PDFDocument({ size: 'A4', margins: { top: 56, bottom: 56, left: M, right: M }, compress: false, info: { Title: `Recibo — NFS-e ${nota.numero}`, Author: empresa.razaoSocial, Producer: 'ES NFS-e' } });
  const partes = [];
  pdf.on('data', (b) => partes.push(b));
  const fim = new Promise((ok) => pdf.on('end', () => ok(Buffer.concat(partes))));
  const L = pdf.page.width - 2 * M;
  const azul = '#0f2a44'; const cinza = '#555';

  // cabeçalho
  pdf.font('Helvetica-Bold').fontSize(13).fillColor(azul).text(empresa.razaoSocial, M, M, { width: L - 190 });
  pdf.font('Helvetica').fontSize(9).fillColor(cinza)
    .text(`${empresa.cnpj?.length === 11 ? 'CPF' : 'CNPJ'} ${fmtDoc(empresa.cnpj)}${empresa.municipio ? ` · ${empresa.municipio}` : ''}`, { width: L - 190 });
  if (d.registro) pdf.text(d.registro, { width: L - 190 });
  const yCab = pdf.y;
  pdf.roundedRect(M + L - 175, M - 4, 175, 58, 6).lineWidth(1.2).stroke(azul);
  pdf.font('Helvetica-Bold').fontSize(18).fillColor(azul).text('RECIBO', M + L - 175, M + 4, { width: 175, align: 'center' });
  pdf.fontSize(14).text(moeda(d.valor), M + L - 175, M + 28, { width: 175, align: 'center' });
  pdf.y = Math.max(yCab, M + 62) + 18;
  pdf.moveTo(M, pdf.y).lineTo(M + L, pdf.y).lineWidth(0.6).stroke('#c9d3de');
  pdf.moveDown(1.2);

  const tomDoc = nota.tomadorDoc ? `, inscrito(a) no ${nota.tomadorDoc.length === 14 ? 'CNPJ' : 'CPF'} sob o nº ${fmtDoc(nota.tomadorDoc)}` : '';
  const j = { align: 'justify', width: L, lineGap: 3 };
  pdf.font('Helvetica').fontSize(11.5).fillColor('#111');
  pdf.text(`Recebi(emos) de ${nota.tomadorNome}${tomDoc}, a importância de ${moeda(d.valor)} (${valorPorExtenso(d.valor)}), referente a ${d.referente.replace(/\s+/g, ' ').replace(/[.\s]+$/, '').replace(/^([A-ZÀ-Ú])(?=[a-zà-ú])/, (c) => c.toLowerCase())}.`, M, pdf.y, j);
  pdf.moveDown(0.8);
  pdf.text(`Este recibo está vinculado à Nota Fiscal de Serviço Eletrônica nº ${nota.numero}, emitida em ${dataHora(nota.dhProc)}, no valor de ${moeda(nota.vServ)}${Number(nota.vLiq) && Number(nota.vLiq) !== Number(nota.vServ) ? ` (valor líquido ${moeda(nota.vLiq)})` : ''}, com a chave de acesso:`, j);
  pdf.moveDown(0.2).font('Courier').fontSize(10.5).text(nota.chaveAcesso.replace(/(\d{4})(?=\d)/g, '$1 '), { width: L, align: 'center' });
  pdf.font('Helvetica').fontSize(11.5);
  pdf.moveDown(0.8);
  pdf.text(`Pagamento: ${d.forma}, em ${dataBr(d.dataPagamento)}.${d.obs ? ` ${d.obs.replace(/[.\s]+$/, '')}.` : ''}`, j);
  pdf.moveDown(0.8);
  pdf.text('Para clareza, firmo(amos) o presente recibo, dando plena e geral quitação do valor acima.', j);
  pdf.moveDown(1.6);
  pdf.text(`${d.cidade}, ${extensoData(d.dataEmissao)}.`, { width: L, align: 'right' });

  // assinatura
  pdf.moveDown(2.6);
  const yAss = pdf.y;
  const wAss = 280; const xAss = M + (L - wAss) / 2;
  pdf.moveTo(xAss, yAss).lineTo(xAss + wAss, yAss).lineWidth(0.8).stroke('#333');
  pdf.font('Helvetica-Bold').fontSize(10.5).fillColor('#111').text(d.assinante || empresa.razaoSocial, xAss, yAss + 6, { width: wAss, align: 'center' });
  pdf.font('Helvetica').fontSize(9).fillColor(cinza).text(`${empresa.cnpj?.length === 11 ? 'CPF' : 'CNPJ'} ${fmtDoc(empresa.cnpj)}${d.registro ? ` · ${d.registro}` : ''}`, { width: wAss, align: 'center' });
  pdf.moveDown(1.2);

  // selo da assinatura digital + QR da NFS-e
  const ySelo = pdf.y + 6;
  const qr = await QRCode.toBuffer(`${URL_CONSULTA}${nota.chaveAcesso}`, { margin: 0, width: 220 });
  pdf.roundedRect(M, ySelo, L, 96, 6).lineWidth(0.8).stroke('#c9d3de');
  pdf.image(qr, M + 12, ySelo + 12, { width: 72 });
  const xt = M + 98; const wt = L - 110;
  pdf.font('Helvetica-Bold').fontSize(9.5).fillColor(azul)
    .text(titular ? 'DOCUMENTO ASSINADO DIGITALMENTE' : 'DOCUMENTO NÃO ASSINADO DIGITALMENTE', xt, ySelo + 12, { width: wt });
  pdf.font('Helvetica').fontSize(8.5).fillColor('#333');
  if (titular) {
    pdf.text(`Assinado com certificado digital ICP-Brasil de ${titular}. Nos termos do art. 10, § 1º, da Medida Provisória nº 2.200-2/2001, as declarações deste documento presumem-se verdadeiras em relação ao signatário. Confira a assinatura em validar.iti.gov.br.`, xt, pdf.y + 2, { width: wt, align: 'justify' });
  } else {
    pdf.text('A empresa não tem certificado A1 próprio cadastrado; o recibo não contém assinatura digital.', xt, pdf.y + 2, { width: wt, align: 'justify' });
  }
  pdf.text(`Consulte a NFS-e pelo QR Code ou em nfse.gov.br/ConsultaPublica (chave ${nota.chaveAcesso}).`, xt, pdf.y + 2, { width: wt });

  if (nota.ambiente !== 'producao') {
    pdf.save().rotate(-30, { origin: [pdf.page.width / 2, pdf.page.height / 2] })
      .font('Helvetica-Bold').fontSize(46).fillColor('#c0392b').opacity(0.12)
      .text(nota.ambiente === 'simulacao' ? 'SIMULAÇÃO — SEM VALOR' : 'HOMOLOGAÇÃO — SEM VALOR', 0, pdf.page.height / 2 - 30, { width: pdf.page.width, align: 'center' })
      .restore();
  }
  pdf.end();
  return fim;
}

/** Converte o A1 para um .p12 que o assinador lê (algoritmos antigos/novos variam entre certificadoras). */
function p12Compativel(pfx, senha) {
  try {
    const asn = forge.asn1.fromDer(forge.util.createBuffer(pfx.toString('binary')));
    forge.pkcs12.pkcs12FromAsn1(asn, senha);
    return pfx;
  } catch {
    return null;
  }
}
function p12DePem(keyPem, certPem, senha) {
  const key = forge.pki.privateKeyFromPem(keyPem);
  const certs = String(certPem).match(/-----BEGIN CERTIFICATE-----[\s\S]+?-----END CERTIFICATE-----/g).map((c) => forge.pki.certificateFromPem(c));
  const asn = forge.pkcs12.toPkcs12Asn1(key, certs, senha, { algorithm: '3des' });
  return Buffer.from(forge.asn1.toDer(asn).getBytes(), 'binary');
}

/**
 * Gera o recibo e, se houver certificado, assina (PKCS#7 destacado, SHA-256).
 * cert: { pfx, password, keyPem?, certPem?, titular }
 */
export async function reciboPdf(nota, empresa, dados, cert) {
  if (nota.status !== 'autorizada') throw Object.assign(new Error('Só é possível gerar recibo de nota autorizada.'), { usuario: true });
  const pdf = await montarPdf(nota, empresa, dados, cert?.titular ?? null);
  if (!cert) return { pdf, assinado: false };
  const comMarca = plainAddPlaceholder({
    pdfBuffer: pdf, reason: `Recibo vinculado à NFS-e nº ${nota.numero}`, contactInfo: empresa.email ?? '', name: cert.titular,
    location: dados.cidade ?? '', signatureLength: 16384,
  });
  let p12 = p12Compativel(cert.pfx, cert.password);
  if (!p12) {
    if (!cert.keyPem || !cert.certPem) throw Object.assign(new Error('Não foi possível ler o certificado A1 para assinar o recibo.'), { usuario: true });
    p12 = p12DePem(cert.keyPem, cert.certPem, cert.password ?? '');
  }
  const assinado = await new SignPdf().sign(comMarca, new P12Signer(p12, { passphrase: cert.password ?? '' }));
  return { pdf: Buffer.from(assinado), assinado: true };
}
