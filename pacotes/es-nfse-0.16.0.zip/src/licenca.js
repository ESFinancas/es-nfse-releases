// Liberação de acesso por CNPJ emitente.
//
// O administrador (só o computador que tem a chave privada em dados/.licenca-admin.key)
// mantém a lista e publica `licencas.json`, assinado com Ed25519, no repositório
// público de releases. Cada instalação baixa a lista ao abrir e a cada 6 horas,
// confere a assinatura com a chave pública abaixo e libera ou trava cada empresa.
// Os CNPJs vão embaralhados (hash), para a lista de clientes não ficar legível.
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { existsSync, promises as fs, readdirSync } from 'node:fs';
import path from 'node:path';
import * as db from './db.js';

export const CHAVE_PUBLICA = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAGFXbBV4gKlYvWjvGqXz56QbVZJtUk0hnGb+SnUFlzjI=
-----END PUBLIC KEY-----`;
export const REPO_RELEASES = 'ESFinancas/es-nfse-releases';
const URL_LICENCAS = () => process.env.ES_NFSE_URL_LICENCAS ?? `https://raw.githubusercontent.com/${REPO_RELEASES}/main/licencas.json`;
const TOLERANCIA_OFFLINE_MS = 7 * 24 * 60 * 60 * 1000;
export const DIAS_AVISO = 5;

const so = (s) => String(s ?? '').replace(/\D/g, '');
export const hashCnpj = (cnpj) => crypto.createHash('sha256').update(`es-nfse:licenca:${so(cnpj)}`).digest('hex');

/** JSON com chaves em ordem: é exatamente o que se assina e o que se confere. */
export function canonico(v) {
  if (Array.isArray(v)) return `[${v.map(canonico).join(',')}]`;
  if (v && typeof v === 'object') return `{${Object.keys(v).sort().map((k) => `${JSON.stringify(k)}:${canonico(v[k])}`).join(',')}}`;
  return JSON.stringify(v);
}

export function assinaturaValida(arquivo, chavePublica = CHAVE_PUBLICA) {
  try {
    if (!arquivo?.conteudo || typeof arquivo.assinatura !== 'string') return false;
    return crypto.verify(null, Buffer.from(canonico(arquivo.conteudo)), chavePublica, Buffer.from(arquivo.assinatura, 'base64'));
  } catch { return false; }
}

export const hojeBrasil = (d = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo' }).format(d);
const diasEntre = (de, ate) => Math.round((new Date(`${ate}T12:00:00Z`) - new Date(`${de}T12:00:00Z`)) / 86400000);

// ---------------------------------------------------------------------------
// Administrador
// ---------------------------------------------------------------------------
const arqChave = () => path.join(db.DATA_DIR, '.licenca-admin.key');
export const ehAdmin = () => existsSync(arqChave());

// ---------------------------------------------------------------------------
// Instalações (clientes): baixar, conferir e decidir
// ---------------------------------------------------------------------------
export async function atualizarLista({ buscar = fetch } = {}) {
  try {
    const ctrl = AbortSignal.timeout(15000);
    const r = await buscar(`${URL_LICENCAS()}?t=${Date.now()}`, { signal: ctrl, headers: { 'Cache-Control': 'no-cache' } });
    if (r.status === 404) {
      await db.mapaAtualizar('_config', 'licencas', () => ({ naoPublicado: true, baixadoEm: Date.now() }));
      return { ok: true, naoPublicado: true };
    }
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const arquivo = await r.json();
    if (!assinaturaValida(arquivo)) throw new Error('assinatura inválida');
    const atual = await db.mapaObter('_config', 'licencas');
    // nunca volta para uma lista mais antiga que a guardada
    if (atual?.arquivo && atual.arquivo.conteudo.emitidoEm > arquivo.conteudo.emitidoEm) {
      await db.mapaAtualizar('_config', 'licencas', (a) => ({ ...a, baixadoEm: Date.now() }));
      return { ok: true };
    }
    await db.mapaAtualizar('_config', 'licencas', () => ({ arquivo, baixadoEm: Date.now() }));
    return { ok: true };
  } catch (err) {
    return { ok: false, erro: err.message };
  }
}

function statusDe(e, agora) {
  if (e.bloqueado) return { status: 'bloqueado', bloqueia: true, mensagem: 'O acesso desta empresa está suspenso.' };
  const hoje = hojeBrasil(agora);
  const dias = diasEntre(hoje, e.ate);
  const br = e.ate.split('-').reverse().join('/');
  if (dias < 0) return { status: 'vencido', bloqueia: true, ate: e.ate, mensagem: `A liberação desta empresa venceu em ${br}.` };
  if (dias <= DIAS_AVISO) return { status: 'vencendo', bloqueia: false, ate: e.ate, dias, mensagem: `A liberação desta empresa vence ${dias === 0 ? 'hoje' : `em ${dias} dia${dias > 1 ? 's' : ''}`} (${br}).` };
  return { status: 'liberado', bloqueia: false, ate: e.ate };
}
const NAO_LIBERADO = { status: 'nao_liberado', bloqueia: true, mensagem: 'Esta empresa ainda não foi liberada para usar o ES NFS-e.' };

/**
 * Avalia a instalação inteira. A versão sai da lista publicada:
 *  - admin: computador com a chave do administrador (tudo liberado);
 *  - contador: alguma empresa cadastrada é um CNPJ liberado como "contador"; ela é a titular e
 *    as demais empresas (clientes do contador) seguem a liberação dela até o limite contratado;
 *  - cliente: cada empresa precisa da própria liberação ("cliente").
 *  - livre: nenhuma lista publicada ainda (nada é travado).
 */
export async function avaliar(empresas, agora = new Date()) {
  const ordenadas = [...empresas].sort((a, b) => String(a.criadoEm ?? '').localeCompare(String(b.criadoEm ?? '')));
  const por = new Map();
  const todas = (s) => { for (const e of ordenadas) por.set(e.id, s); };
  if (ehAdmin()) { todas({ status: 'liberado', admin: true, bloqueia: false }); return { edicao: 'admin', porEmpresa: por }; }
  const c = await db.mapaObter('_config', 'licencas');
  if (c?.naoPublicado) { todas({ status: 'liberado', bloqueia: false }); return { edicao: 'livre', porEmpresa: por }; }
  if (!c?.arquivo || agora.getTime() - (c.baixadoEm ?? 0) > TOLERANCIA_OFFLINE_MS) {
    todas({ status: 'sem_verificacao', bloqueia: true, mensagem: 'Não foi possível confirmar a liberação de acesso. Conecte o computador à internet e abra o sistema de novo.' });
    return { edicao: 'sem_verificacao', porEmpresa: por };
  }
  const lista = c.arquivo.conteudo.cnpjs ?? {};
  const ent = (cnpj) => lista[hashCnpj(cnpj)];
  const titular = ordenadas.find((e) => ent(e.cnpj)?.perfil === 'contador');
  if (titular) {
    const et = ent(titular.cnpj);
    const base = statusDe(et, agora);
    const limite = Number(et.limite ?? 0);
    let usados = 0;
    for (const e of ordenadas) {
      if (e.id === titular.id) { por.set(e.id, { ...base, titular: true }); continue; }
      const proprio = ent(e.cnpj);
      if (proprio) { por.set(e.id, statusDe(proprio, agora)); continue; }
      usados += 1;
      por.set(e.id, usados <= limite ? { ...base, viaContador: true }
        : { status: 'limite', bloqueia: true, mensagem: `Limite de ${limite} empresa(s) da licença do escritório atingido.` });
    }
    return { edicao: 'contador', titular: titular.cnpj, limite, usados, porEmpresa: por };
  }
  for (const e of ordenadas) por.set(e.id, ent(e.cnpj) ? statusDe(ent(e.cnpj), agora) : NAO_LIBERADO);
  return { edicao: 'cliente', porEmpresa: por };
}

/** Situação de um CNPJ considerando as empresas desta instalação. */
export async function situacao(cnpj, agora = new Date()) {
  const empresas = await db.listar('empresas');
  let alvo = empresas.find((e) => so(e.cnpj) === so(cnpj));
  const lista = alvo ? empresas : [...empresas, (alvo = { id: '__consulta__', cnpj: so(cnpj), criadoEm: '9999' })];
  return (await avaliar(lista, agora)).porEmpresa.get(alvo.id);
}

/** Resumo da versão desta instalação (para a interface). */
export async function instalacao() {
  const empresas = await db.listar('empresas');
  const r = await avaliar(empresas);
  return { edicao: r.edicao, titular: r.titular ?? null, limite: r.limite ?? null, usados: r.usados ?? null, total: empresas.length };
}

/** Regra de cadastro de nova empresa conforme a versão. */
export async function podeCadastrar(cnpjNovo) {
  const empresas = await db.listar('empresas');
  const r = await avaliar(empresas);
  if (['admin', 'livre', 'sem_verificacao'].includes(r.edicao) || !empresas.length) return;
  const c = await db.mapaObter('_config', 'licencas');
  const propria = c?.arquivo?.conteudo?.cnpjs?.[hashCnpj(cnpjNovo)];
  if (propria) return;
  if (r.edicao === 'contador') {
    if (r.usados >= r.limite) {
      throw Object.assign(new Error(`A licença do escritório permite até ${r.limite} empresa(s) cliente(s) e todas já estão em uso. Fale com o escritório para ampliar o limite.`), { usuario: true, status: 403 });
    }
    return;
  }
  throw Object.assign(new Error('Esta instalação é da versão Cliente: emite somente para o CNPJ liberado. Para emitir para outras empresas, fale com o escritório sobre a versão Contador.'), { usuario: true, status: 403 });
}

export async function exigirLiberada(empresa) {
  const s = await situacao(empresa?.cnpj);
  if (s.bloqueia) {
    const e = new Error(`${s.mensagem} Fale com o escritório Everton Sousa Contabilidade.`);
    e.status = 403; e.usuario = true; e.licenca = s;
    throw e;
  }
  return s;
}

// ---------------------------------------------------------------------------
// Painel do administrador: cadastro, montagem, assinatura e publicação
// ---------------------------------------------------------------------------
export async function listarAdmin() {
  return (await db.mapaObter('_config', 'licencasAdmin'))?.lista ?? [];
}

export async function salvarAdmin(item) {
  const cnpj = so(item.cnpj);
  if (cnpj.length !== 14 && cnpj.length !== 11) throw Object.assign(new Error('Informe um CNPJ (ou CPF) válido.'), { usuario: true });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(item.ate ?? ''))) throw Object.assign(new Error('Informe a data de vencimento.'), { usuario: true });
  const registro = {
    cnpj, nome: String(item.nome ?? '').trim().slice(0, 120), ate: item.ate, bloqueado: Boolean(item.bloqueado),
    perfil: item.perfil === 'contador' ? 'contador' : 'cliente',
    ...(item.perfil === 'contador' ? { limite: Math.max(0, Math.min(9999, Number.parseInt(item.limite, 10) || 0)) } : {}),
    obs: String(item.obs ?? '').trim().slice(0, 300), alteradoEm: new Date().toISOString(),
  };
  await db.mapaAtualizar('_config', 'licencasAdmin', (atual = {}) => {
    const lista = (atual.lista ?? []).filter((x) => x.cnpj !== cnpj);
    return { ...atual, lista: [...lista, registro].sort((a, b) => a.nome.localeCompare(b.nome)), pendente: true };
  });
  return registro;
}

export async function removerAdmin(cnpj) {
  await db.mapaAtualizar('_config', 'licencasAdmin', (atual = {}) => ({ ...atual, lista: (atual.lista ?? []).filter((x) => x.cnpj !== so(cnpj)), pendente: true }));
}

/** Contato do suporte definido pelo administrador (vai na lista publicada). */
export async function contatoAdmin() {
  return (await db.mapaObter('_config', 'licencasAdmin'))?.contato ?? null;
}
export async function salvarContato({ whatsapp, email, nome }) {
  const c = { whatsapp: so(whatsapp), email: String(email ?? '').trim().toLowerCase(), nome: String(nome ?? '').trim().slice(0, 80) };
  if (c.whatsapp && (c.whatsapp.length < 12 || c.whatsapp.length > 13)) throw Object.assign(new Error('WhatsApp com DDI e DDD, ex.: 55 83 99999-9999.'), { usuario: true });
  if (c.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(c.email)) throw Object.assign(new Error('E-mail inválido.'), { usuario: true });
  await db.mapaAtualizar('_config', 'licencasAdmin', (a = {}) => ({ ...a, contato: c, pendente: true }));
  return c;
}
/** Contato do suporte nesta instalação: o do administrador ou o da última lista válida. */
export async function contatoSuporte() {
  if (ehAdmin()) { const c = await contatoAdmin(); if (c) return c; }
  return (await db.mapaObter('_config', 'licencas'))?.arquivo?.conteudo?.contato ?? null;
}

export async function estadoPublicacao() {
  const a = (await db.mapaObter('_config', 'licencasAdmin')) ?? {};
  return { pendente: Boolean(a.pendente), publicadoEm: a.publicadoEm ?? null, ultimoErro: a.ultimoErro ?? null };
}

/** Monta e assina o arquivo público a partir do cadastro do administrador. */
export async function montarArquivo(lista, chavePrivadaPem, contato) {
  const conteudo = {
    versao: 1,
    emitidoEm: new Date().toISOString(),
    ...(contato && (contato.whatsapp || contato.email) ? { contato: { whatsapp: contato.whatsapp ?? '', email: contato.email ?? '', nome: contato.nome ?? '' } } : {}),
    cnpjs: Object.fromEntries(lista.map((x) => [hashCnpj(x.cnpj), {
      ate: x.ate, ...(x.bloqueado ? { bloqueado: true } : {}),
      ...(x.perfil === 'contador' ? { perfil: 'contador', limite: Number(x.limite ?? 0) } : {}),
    }])),
  };
  const assinatura = crypto.sign(null, Buffer.from(canonico(conteudo)), chavePrivadaPem).toString('base64');
  return { conteudo, assinatura };
}

function acharGit() {
  const candidatos = ['git'];
  if (process.platform === 'win32') {
    const pf = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Programs')].filter(Boolean);
    for (const base of pf) candidatos.push(path.join(base, 'Git', 'cmd', 'git.exe'));
    const gd = process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'GitHubDesktop');
    if (gd && existsSync(gd)) {
      for (const d of readdirSync(gd).filter((n) => n.startsWith('app-')).sort().reverse()) {
        candidatos.push(path.join(gd, d, 'resources', 'app', 'git', 'cmd', 'git.exe'));
      }
    }
  }
  return candidatos;
}

const rodar = (exe, args, cwd) => new Promise((ok, erro) => {
  execFile(exe, args, { cwd, timeout: 120000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
    if (err) { err.saida = `${stdout}\n${stderr}`.trim(); erro(err); } else ok(stdout);
  });
});

async function gitDisponivel() {
  for (const exe of acharGit()) {
    if (exe !== 'git' && !existsSync(exe)) continue;
    try { await rodar(exe, ['--version']); return exe; } catch { /* tenta o próximo */ }
  }
  return null;
}

/**
 * Publica a lista no repositório de releases usando o Git do computador do
 * administrador (com o login do GitHub já salvo nele).
 */
export async function publicar({ repoUrl = `https://github.com/${REPO_RELEASES}.git`, pasta } = {}) {
  if (!ehAdmin()) throw Object.assign(new Error('Somente o computador do administrador publica liberações.'), { status: 403, usuario: true });
  const git = await gitDisponivel();
  if (!git) throw Object.assign(new Error('Git não encontrado neste computador. Instale o Git for Windows (git-scm.com) e tente de novo.'), { usuario: true });
  const destino = pasta ?? path.join(path.dirname(db.DATA_DIR), 'admin', 'releases');
  const chave = await fs.readFile(arqChave(), 'utf8');
  const lista = await listarAdmin();
  const arquivo = await montarArquivo(lista, chave, await contatoAdmin());
  if (!assinaturaValida(arquivo, crypto.createPublicKey(chave))) throw new Error('Falha ao assinar a lista.');
  try {
    if (!existsSync(path.join(destino, '.git'))) {
      await fs.mkdir(path.dirname(destino), { recursive: true });
      await rodar(git, ['clone', '--depth', '20', repoUrl, destino]);
    } else {
      await rodar(git, ['fetch', 'origin', 'main'], destino);
      await rodar(git, ['reset', '--hard', 'origin/main'], destino);
    }
    await fs.writeFile(path.join(destino, 'licencas.json'), `${JSON.stringify(arquivo, null, 2)}\n`);
    await rodar(git, ['add', 'licencas.json'], destino);
    const status = await rodar(git, ['status', '--porcelain'], destino);
    if (status.trim()) {
      await rodar(git, ['-c', 'user.name=ES NFS-e Admin', '-c', 'user.email=admin@es-nfse.local', 'commit', '-m', `Liberações: ${lista.length} CNPJ(s)`], destino);
      await rodar(git, ['push', 'origin', 'HEAD:main'], destino);
    }
    await db.mapaAtualizar('_config', 'licencasAdmin', (a = {}) => ({ ...a, pendente: false, publicadoEm: new Date().toISOString(), ultimoErro: null }));
    return { ok: true, total: lista.length };
  } catch (err) {
    const msg = /Authentication|could not read Username|403|denied/i.test(err.saida ?? '')
      ? 'O GitHub recusou o envio: entre com sua conta do GitHub no Git deste computador (o Git pede o login na primeira vez) e tente de novo.'
      : `Falha ao publicar: ${(err.saida || err.message).split('\n').slice(-3).join(' ')}`;
    await db.mapaAtualizar('_config', 'licencasAdmin', (a = {}) => ({ ...a, ultimoErro: msg }));
    throw Object.assign(new Error(msg), { usuario: true });
  }
}
